/* Google Maps API */

// var map;
// var directions;
// var mapOptions = {
//   zoom: 15,
//   center: "東京駅",
//   mapTypeId: google.maps.MapTypeId.ROADMAP,
// }
// //表示用option
// var rendererOptions = {
//   draggable: true,
//   preserveViewport: false,
//   suppressMarkers: true,
// };



////////////////











// function initialize() {
//   // Geolocation APIに対応している
//   if (!navigator.geolocation) {
//     alert("この端末では位置情報が取得できません");
//   }

//   //  if (GBrowserIsCompatible()) {
//   map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
//   map.setCenter(new google.maps.LatLng(35.6813585, 139.7673893), 17);
//   //道順表示用オブジェクト
//   directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);
//   //道順表示サービス
//   directionsService = new google.maps.DirectionsService();

//   stepDisplay = new google.maps.InfoWindow;
//   directions = new GDirections(map, document.getElementById('route'));
//   //  }
// }

// function dispRoute(flg = 'a') {
//   var from = document.getElementById("from").value;
//   if (flg == 'a') {
//     var to = document.getElementById("toa").value;
//   } else {
//     var to = document.getElementById("tob").value;
//   }
//   directions.clear();

//   str = 'from: ' + from + ' to: ' + to;
//   directions.load(str, { locale: 'ja_JP' });
// }

// function clearRoute() {
//   directions.clear();
// }

// initialize();

