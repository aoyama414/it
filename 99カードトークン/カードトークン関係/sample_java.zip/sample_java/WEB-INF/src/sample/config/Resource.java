package sample.config;

import java.util.Map;


public class Resource {
	private Map<String,String> mission_code;
	private Map<String,String> process_code;
	private Map<String,String> conveni_item;
	private Map<String,String> select_st_code;
	private Map<String,Map<String,Object>> goods;
	private Map<String,String> payment_code;
	private Map<String,String> conveni_description;
	private Map<String,String> pref_list;

	public Map<String, String> getMission_code() {
		return mission_code;
	}
	public void setMission_code(Map<String, String> mission_code) {
		this.mission_code = mission_code;
	}
	public Map<String, String> getProcess_code() {
		return process_code;
	}
	public void setProcess_code(Map<String, String> process_code) {
		this.process_code = process_code;
	}
	public Map<String, String> getConveni_item() {
		return conveni_item;
	}
	public void setConveni_item(Map<String, String> conveni_item) {
		this.conveni_item = conveni_item;
	}
	public Map<String, String> getSelect_st_code() {
		return select_st_code;
	}
	public void setSelect_st_code(Map<String, String> select_st_code) {
		this.select_st_code = select_st_code;
	}
	public Map<String, Map<String, Object>> getGoods() {
		return goods;
	}
	public void setGoods(Map<String, Map<String, Object>> goods) {
		this.goods = goods;
	}
	public Map<String, String> getPayment_code() {
		return payment_code;
	}
	public void setPayment_code(Map<String, String> payment_code) {
		this.payment_code = payment_code;
	}
	public Map<String, String> getConveni_description() {
		return conveni_description;
	}
	public void setConveni_description(Map<String, String> conveni_description) {
		this.conveni_description = conveni_description;
	}
	public Map<String,String> getPref_list() {
		return pref_list;
	}
	public void setPref_list(Map<String,String> pref_list) {
		this.pref_list = pref_list;
	}

}
