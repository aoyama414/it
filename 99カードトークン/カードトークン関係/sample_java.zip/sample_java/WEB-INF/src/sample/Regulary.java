package sample;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.config.Config;
import sample.connection.EpsilonRegulary;
import sample.connection.data.RegularyResultInfo;
import sample.connection.data.RegularySendInfo;
public class Regulary extends HttpServlet {

	// GET時の処理
	// 画面出力はJSPで行っているが処理実装はServlet側のため
	// GET時にはJSPを出力処理
	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/regularyInput.jsp");
		dispatcher.forward(request, response);
	}

	// POST時の処理
	// 画面からPOSTされてきた場合に値の処理を行う
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		String come_from = (String)request.getParameter("come_from");
		Config config = (Config) request.getAttribute("ep_config");
		String mode = request.getParameter("mode").isEmpty() ? "change" : request.getParameter("mode");
		String userId = request.getParameter("user_id").isEmpty() ? "":request.getParameter("user_id");
		String itemCode = request.getParameter("item_code").isEmpty() ? "":request.getParameter("item_code");
		String itemPrice = request.getParameter("item_price") == null ? "":request.getParameter("item_price");

		String errMsg = "";

		// hear→INPUTからの遷移
		if( "here".equals(come_from)){
			// 入力チェック
			if ( itemCode.isEmpty() ){
				errMsg = "商品コードを入力してください";
			}
			if ( userId.isEmpty() ) {
				errMsg = "ユーザIDを入力してください";
			}
			if ( "change".equals(mode) && ( itemPrice.isEmpty() || !itemPrice.matches("^[0-9]+$"))){
				errMsg = "金額変更の場合変更後金額を入力してください";
			}
			if( errMsg.isEmpty() ){

				ServletContext context = this.getServletContext();
				RequestDispatcher dispatcher
				= context.getRequestDispatcher("/jsp/regularyConfirm.jsp");
				dispatcher.forward(request, response);
				return;
			}else{
				request.setAttribute("err_msg", errMsg);
			}
		}else if( "kakunin".equals(come_from)){
			RegularySendInfo regularySendInfo = new RegularySendInfo();
			regularySendInfo.setItemCode(itemCode);
			if( "change".equals(mode)){
				regularySendInfo.setItemPrice(Integer.parseInt(itemPrice));
			}
			regularySendInfo.setUserId(userId);
			EpsilonRegulary regulary = new EpsilonRegulary(regularySendInfo,config);
			RegularyResultInfo regularyResultInfo = regulary.execute(mode);
			if( regularyResultInfo != null ){
				request.setAttribute("resultInfo", regularyResultInfo);
				ServletContext context = this.getServletContext();
				RequestDispatcher dispatcher
				= context.getRequestDispatcher("/jsp/regularyComp.jsp");
				dispatcher.forward(request, response);
				return;
			}else{
				request.setAttribute("err_msg", "データの送信に失敗しました");
			}
		}
		// 異常だった場合、戻るが押下された場合は以下から入力画面に戻す
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
		= context.getRequestDispatcher("/jsp/regularyInput.jsp");
		dispatcher.forward(request, response);
	}


}


