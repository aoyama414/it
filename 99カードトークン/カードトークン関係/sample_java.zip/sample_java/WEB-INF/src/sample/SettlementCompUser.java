package sample;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class SettlementCompUser extends HttpServlet {

	// 通常EPからの登録/変更完了はリダイレクト
	// そのためdoGetで処理を行う
	public void doGet(HttpServletRequest request,
						HttpServletResponse response)
					throws ServletException, IOException {
		// 表示のみ
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/userComp.jsp");
		dispatcher.forward(request, response);

	}
	// 通常EPからの戻りの場合は、リダイレクトであるためGET
	// POSTの場合は通常の入力ページを表示しておく
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			  throws IOException, ServletException {
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/settleInput.jsp");
		dispatcher.forward(request, response);
	}
}