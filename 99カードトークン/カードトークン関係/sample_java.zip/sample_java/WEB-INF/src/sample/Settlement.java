package sample;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.config.Config;
import sample.config.Resource;
import sample.connection.EpsilonSettlement;
import sample.connection.data.SettlementResultInfo;
import sample.connection.data.SettlementSendInfo;
public class Settlement extends HttpServlet {

	// GET時の処理
	public void doGet(HttpServletRequest request,
			HttpServletResponse response)
					throws ServletException, IOException {
		ServletContext context = this.getServletContext();
		// 決済/ユーザ変更入力画面を表示
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/settleInput.jsp");
		dispatcher.forward(request, response);
	}

	// POST時の処理
	// 画面からPOSTされてきた場合に値の処理を行う
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		Config config = (Config) request.getAttribute("ep_config");
		Resource resource = (Resource)request.getAttribute("ep_resource");
		// リクエストパラメータの取得
		String comeFrom = request.getParameter("come_from");
		String processCode = request.getParameter("process_code");
		String missionCode = request.getParameter("mission_code");
		String conveniCode = request.getParameter("conveni_code");
		String userId = request.getParameter("user_id");
		String userName = request.getParameter("user_name");
		String userMailAdd = request.getParameter("user_mail_add");
		String userTel = request.getParameter("user_tel");
		String userNameKana = request.getParameter("user_name_kana");
		String item = request.getParameter("item");
		String st = request.getParameter("st");

		String consigneePostal = request.getParameter("consignee_postal");
		String consigneeName = request.getParameter("consignee_name");
		String consigneePref = request.getParameter("consignee_pref");
		String consigneeAddress = request.getParameter("consignee_address");
		String consigneeTel = request.getParameter("consignee_tel");
		String ordererPostal = request.getParameter("orderer_postal");
		String ordererName = request.getParameter("orderer_name");
		String ordererPref = request.getParameter("orderer_pref");
		String ordererAddress = request.getParameter("orderer_address");
		String ordererTel = request.getParameter("orderer_tel");
		String errMsg = "";


		// コンビニ/後払いの場合には決済区分等を無効にしているため送られてこない
		// コンビニ/後払いの場合には固定で設定
		if( "conveni".equals(st) || "atobarai".equals(st)){
			missionCode = "1"; // 一回課金
			processCode = "1"; // 初回課金
		}
		// hear→INPUTからの遷移
		if( "here".equals(comeFrom)){
			// 初回課金又は登録済み課金
			if( "1".equals(processCode) || "2".equals(processCode) ){
				// 値の必死チェック
				if( item == null){
					errMsg = "購入する商品を選択してください";
				}else if(userId.isEmpty()){
					errMsg = "ユーザーIDを入力してください";
				}else if( userName.isEmpty()){
					errMsg = "氏名を入力してください";
				}else if( userMailAdd.isEmpty()){
					errMsg = "メールアドレスを入力してください";
				}
				// コンビニ決済選択時のみのチェック
				if( "conveni".equals(st)){
					processCode = "1";
					missionCode = "1";
					// コンビニ決済のみかつコンビニコードが選択されている場合
					if( 0 < Integer.parseInt(conveniCode) ){
						if( userTel.isEmpty() ){
							errMsg = "ユーザ電話番号が未指定です";
						}else if ( userNameKana.isEmpty() ){
							errMsg = "ユーザ名(カナ)が未指定です";
						}
					}
				}else if( ( "normal".equals(st) || "atobarai".equals(st) ) &&
							(	consigneePostal.length() != 0 ||
								consigneeName.length() != 0 ||
								consigneeAddress.length() != 0 ||
								consigneeTel.length() != 0 ||
								ordererPostal.length() != 0 ||
								ordererName.length() != 0 ||
								ordererAddress.length() != 0 ||
								ordererTel.length() != 0 )
							){
					System.err.println(consigneePostal);
					// 後払い用パラメータのいずれかが入力されていた場合のみ処理
					if ( !consigneePostal.matches("^\\d+$") ) {
						errMsg = "送り先郵便番号の入力が異常です";
					}
					if ( consigneeName.isEmpty() ) {
						errMsg = "送り先名が未入力です";
					}
					if ( !resource.getPref_list().containsKey(consigneePref) ){
						errMsg = "送り先住所(都道府県)が異常です";
					}
					if ( consigneeAddress.isEmpty() ) {
						errMsg = "送り先住所が未入力です";
					}
					if ( !consigneeTel.matches("^\\d+$" )) {
						errMsg = "送り先電話番号が異常です";
					}
					if ( !ordererPostal.matches("^\\d+$") ) {
						errMsg = "注文主郵便番号の入力が異常です";
					}
					if ( ordererName.isEmpty() ) {
						errMsg = "注文主名が未入力です";
					}
					if ( !resource.getPref_list().containsKey(ordererPref) ){
						errMsg = "注文主住所(都道府県)が異常です";
					}
					if ( ordererAddress.isEmpty() ) {
						errMsg = "注文主住所が未入力です";
					}
					if ( !ordererTel.matches("^\\d+$" )) {
						errMsg = "注文主電話番号が異常です";
					}
				}
			}else if( "3".equals(processCode) || "4".equals(processCode) ){ // ユーザ登録/変更
				// ユーザIDチェック
				if ( !userId.matches("^[a-zA-Z0-9\\.\\-\\+\\/\\@]+$") ){
					errMsg = "ユーザIDにご利用できない文字が含まれています。";
				}
				// ユーザ名が入っていない
				if( userName.isEmpty() ){
					errMsg = "氏名を入力してください。";
				}
				// ユーザメールアドレスチェック
				if( !userMailAdd.matches("^[a-zA-Z0-9\\.\\-\\_\\@]+$") ){
					errMsg = "ユーザメールアドレスにご利用できない文字が含まれています。";
				}
			}else if( "7".equals(processCode) || "9".equals(processCode)){
				if ( !userId.matches("^[a-zA-Z0-9\\.\\-\\+\\/\\@]+$") ){
					errMsg = "ユーザIDにご利用できない文字が含まれています。";
				}
			}else{
				processCode = "1";
				errMsg = "処理区分の指定が異常です。";
			}
			// 正常だった場合は確認画面へ
			if( errMsg.isEmpty() ){
				ServletContext context = this.getServletContext();
				RequestDispatcher dispatcher
					= context.getRequestDispatcher("/jsp/settleConfirm.jsp");
				dispatcher.forward(request, response);
				return;
			}else{
				// err_msgを設定しておく
				request.setAttribute("err_msg", errMsg);
			}
		}else if( "kakunin".equals(comeFrom)){
			// 送信処理を行う
			// パラメータの設定
			SettlementSendInfo ssi = new SettlementSendInfo();
			ssi.setUserId(userId);
			ssi.setUserName(userName);
			ssi.setUserNameKana(userNameKana);
			ssi.setUserMailAdd(userMailAdd);
			ssi.setItemCode(config.getItem_code());
			// 商品の指定がある場合のみ入れておく
			if( !item.isEmpty() ){
				ssi.setItemName((String)resource.getGoods().get(item).get("name"));
				ssi.setItemPrice((Integer)resource.getGoods().get(item).get("price"));
			}
			ssi.setStCode((String)resource.getSelect_st_code().get(st));
			ssi.setMissionCode(Integer.parseInt(missionCode));
			ssi.setProcessCode(Integer.parseInt(processCode));
			ssi.setUserTel(userTel);
			ssi.setConveniCode(Integer.parseInt(conveniCode));
			// オーダーNoを設定→ここでは「年月日時分秒ミリ」
			ssi.setOrderNumber( new SimpleDateFormat("yyyyMMddHHmmssSSS").format(Calendar.getInstance().getTime())	);
			ssi.setMemo1(config.getMemo1());
			ssi.setMemo2(config.getMemo2());
			if ( consigneePostal != null && !consigneePostal.isEmpty()){
				ssi.setConsigneePostal(consigneePostal);
				ssi.setConsigneeName(consigneeName);
				ssi.setConsigneeAddress(String.format("%s%s", resource.getPref_list().get(consigneePref),
														consigneeAddress ) );
				ssi.setConsigneeTel(consigneeTel);
				ssi.setOrdererPostal(ordererPostal);
				ssi.setOrdererName(ordererName);
				ssi.setOrdererAddress(String.format("%s%s", resource.getPref_list().get(ordererPref),
														ordererAddress ) );
				ssi.setOrdererTel(ordererTel);
			}
			EpsilonSettlement epsilonSettlement = new EpsilonSettlement(ssi,config);
			SettlementResultInfo settlementResultInfo = epsilonSettlement.execSettlement();
			if( settlementResultInfo != null ){
				if( "0".equals(settlementResultInfo.getResult())){
					request.setAttribute("err_msg",settlementResultInfo.getErrCode()+" "+ settlementResultInfo.getErrDetail());
				}else if( settlementResultInfo.getRedirect() != null){
					// EPSILONにリダイレクト
					response.sendRedirect(settlementResultInfo.getRedirect());
					return;
				}else if( settlementResultInfo.getTransCode() != null ){
					String redirect = String.format("/sample_java/settlement_comp?trans_code=%s",settlementResultInfo.getTransCode());
					response.sendRedirect(redirect);
					return;
				}else{
					ServletContext context = this.getServletContext();
					request.setAttribute("result", settlementResultInfo.getResult());
					RequestDispatcher dispatcher
					= context.getRequestDispatcher("/jsp/userResult.jsp");
					dispatcher.forward(request, response);
					return;
				}
			}else{
				request.setAttribute("err_msg", "データの送信に失敗しました");
			}
		}
		// 異常だった場合、戻るが押下された場合は以下から入力画面に戻す
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
		= context.getRequestDispatcher("/jsp/settleInput.jsp");
		dispatcher.forward(request, response);
	}


}


