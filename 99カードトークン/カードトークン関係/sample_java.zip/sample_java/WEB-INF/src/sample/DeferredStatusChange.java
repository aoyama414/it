package sample;


import java.io.FileWriter;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.config.Config;
public class DeferredStatusChange extends HttpServlet {

	// EPからの入金通知はPOST処理
	// Getのコールには対応しない
	public void doGet(HttpServletRequest request,
						HttpServletResponse response)
					throws ServletException, IOException {
		// サーバ間用I/FでPOSTで送られてくるものなのでGETでは何も行わない
	}

	// POSTの場合は受信処理を行う
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			  throws IOException, ServletException {
		// 応答はtext/plain
		response.setContentType("text/plain");

		Config config = (Config)request.getAttribute("ep_config");
		// パラメータを取得
		StringBuffer paramBuf = new StringBuffer();
		// 受信時刻を設定
		paramBuf.append(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss ").format(Calendar.getInstance().getTime()));
		//paramBuf.append(" ");
		for( String name: Collections.list(request.getParameterNames())) {
			paramBuf.append(String.format("%s=%s,", name,new String(URLDecoder.decode(request.getParameter(name),"UTF-8").getBytes("UTF-8"),"UTF-8" )));
		}
		// 末尾のカンマを削除
		paramBuf.deleteCharAt(paramBuf.length() - 1);
		// 改行を追加
		paramBuf.append("\n");
		// ファイルオープン
		try{
			// ファイルに受信内容を保存
			java.io.File notify_text = new java.io.File(config.getDeferred_file());
			notify_text.createNewFile();
			FileWriter fw = new FileWriter(notify_text,true);
			fw.write(paramBuf.toString());
			fw.close();
		}catch(Exception e){
			// 見せる場所がない
			e.printStackTrace();
		}
		// 応答を返す 0:異常 1:正常
		response.getWriter().write(config.getNotify_responce());
	}
}


