package sample.connection;

import java.io.InputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import sample.config.Config;
import sample.connection.data.GetSalesResultInfo;

public class EpsilonGetSales {
	private Config config;
	public Config getConfig() {
		return this.config;
	}
	public void setConfig(Config config) {
		this.config = config;
	}
	public EpsilonGetSales(){
	}
	public EpsilonGetSales(Config config){
		this.setConfig(config);
	}

	public GetSalesResultInfo execute(String trans_code){
		// 決済情報の取得処理
		// Configが未設定の場合は処理しない
		// 何もしないでNULL返却
		if( getConfig() == null){
			return null;
		}
		URI uri = null;
		try{
			uri = new URI(this.getConfig().getGetsales_url().get((String)this.getConfig().getGetsales_type()));
		}catch( Exception e){
			e.printStackTrace();
			return null;
		}
		// 決済情報送信
		// 送信用の設定を作成
		RequestConfig rc = RequestConfig.custom().setConnectTimeout(2000)
				.setSocketTimeout(2000)
				.setMaxRedirects(0)
				.build();
		CredentialsProvider credentialsProvider = null;
		List<NameValuePair> param = new ArrayList<NameValuePair>();
		param.add(new BasicNameValuePair("trans_code",trans_code));

		// Type1:ベーシック認証ありの場合のみ処理
		if( "1".equals(this.getConfig().getGetsales_type())){
			credentialsProvider = new BasicCredentialsProvider();
			Credentials credentials = new UsernamePasswordCredentials(this.getConfig().getContract_code(),
					this.getConfig().getPassword());
			credentialsProvider.setCredentials(new AuthScope(uri.getHost(),uri.getPort()), credentials);
		}else{
			param.add( new BasicNameValuePair("contract_code", this.getConfig().getContract_code()));
		}
		// Header定義
		List<Header> header = new ArrayList<Header>();
		header.add( new BasicHeader("Accept-Charset","UTF-8" ))	;
		header.add( new BasicHeader("User-Agent","EPSILON SAMPLE PROGRAM JAVA" ));
		HttpClient client = HttpClientBuilder.create()
				.setDefaultRequestConfig(rc)
				.setDefaultHeaders(header)
				.setDefaultCredentialsProvider(credentialsProvider)
				.build();
		HttpPost post = new HttpPost();
		HttpResponse res = null;
		// EPSILONにデータ送信
		try {
			post.setEntity(new UrlEncodedFormEntity(param,"UTF-8"));
			post.setURI(uri);
			res = client.execute(post);
		}catch( Exception e){
			e.printStackTrace();
			return null;
		}
		GetSalesResultInfo salesResultInfo = new GetSalesResultInfo();
		// XMLのパース処理
		if( res.getStatusLine().getStatusCode() == HttpStatus.SC_OK ){
			// BODYを取得してXMLパーサー呼び出し
			try{
				String xml = EntityUtils.toString(res.getEntity());

				xml = xml.replace("x-sjis-cp932", "MS932");
				InputStream body = new java.io.ByteArrayInputStream(xml.getBytes());
				Document xmlDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(body);
				NodeList resultList = xmlDoc.getElementsByTagName("result");
				for( int i = 0; i < resultList.getLength(); i++) {
					Node node = resultList.item(i);
					NamedNodeMap namedNodeMap = node.getAttributes();
					for( int j =0; j < namedNodeMap.getLength(); j++ ){
						Node attr = namedNodeMap.item(j);
						switch (attr.getNodeName()) {
						case "trans_code":
							salesResultInfo.setTransCode( attr.getNodeValue() );
							break;
						case "order_number":
							salesResultInfo.setOrderNumber( attr.getNodeValue() );
							break;
						case "state":
							salesResultInfo.setState( attr.getNodeValue() );
							break;
						case "user_id":
							salesResultInfo.setUserId( attr.getNodeValue() );
							break;
						case "user_name":
							salesResultInfo.setUserName( attr.getNodeValue() );
							break;
						case "process_code":
							salesResultInfo.setProcessCode( attr.getNodeValue() );
							break;
						case "last_updte":
							salesResultInfo.setLastUpdte( attr.getNodeValue() );
							break;
						case "item_price":
							salesResultInfo.setItemPrice( attr.getNodeValue() );
							break;
						case "memo1":
							salesResultInfo.setMemo1( attr.getNodeValue() );
							break;
						case "memo2":
							salesResultInfo.setMemo2( attr.getNodeValue() );
							break;
						case "mission_code":
							salesResultInfo.setMissionCode( attr.getNodeValue() );
							break;
						case "st_code":
							salesResultInfo.setStCode( attr.getNodeValue() );
							break;
						case "contract_code":
							salesResultInfo.setContractCode( attr.getNodeValue() );
							break;
						case "item_name":
							salesResultInfo.setItemName( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "payment_code":
							salesResultInfo.setPaymentCode( attr.getNodeValue() );
							break;
						case "user_mail_add":
							salesResultInfo.setUserMailAdd( attr.getNodeValue() );
							break;
						case "item_code":
							salesResultInfo.setItemCode( attr.getNodeValue() );
							break;
						case "due_date":
							salesResultInfo.setDueDate( attr.getNodeValue() );
							break;
						case "add_info":
							salesResultInfo.setAddInfo( attr.getNodeValue() );
							break;
						case "currencyid":
							salesResultInfo.setCurrencyId( attr.getNodeValue() );
							break;
						case "credit_flag":
							salesResultInfo.setCreditFlag( attr.getNodeValue() );
							break;
						case "credit_time":
							salesResultInfo.setCreditTime( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "card_st_code":
							salesResultInfo.setCardStCode( attr.getNodeValue() );
							break;
						case "pay_time":
							salesResultInfo.setPayTime( attr.getNodeValue() );
							break;
						case "conveni_code":
							salesResultInfo.setConveniCode( attr.getNodeValue() );
							break;
						case "receipt_no":
							salesResultInfo.setReceiptNo( attr.getNodeValue() );
							break;
						case "kigyou_code":
							salesResultInfo.setKigyouCode( attr.getNodeValue() );
							break;
						case "haraikomi_url":
							salesResultInfo.setHaraikomiUrl( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "paid":
							salesResultInfo.setPaid( attr.getNodeValue() );
							break;
						case "receipt_date":
							salesResultInfo.setReceiptDate( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "conveni_limit":
							salesResultInfo.setConveniLimit( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "conveni_time":
							salesResultInfo.setConveniTime( new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ) );
							break;
						case "carrier_code":
							salesResultInfo.setCarrierCode( attr.getNodeValue() );
							break;
						case "charge_date":
							salesResultInfo.setChargeDate( attr.getNodeValue() );
							break;
						case "rate_amount":
							salesResultInfo.setRateAmount( attr.getNodeValue() );
							break;
						case "cancel_date":
							salesResultInfo.setCancelDate( attr.getNodeValue() );
							break;
						case "rate_cancel_amount":
							salesResultInfo.setRateCancelAmount( attr.getNodeValue() );
							break;
						}
					}
				}
			}catch ( Exception e){
				e.printStackTrace();
				return null;
			}
		}else{
			// 応答が200以外の場合は不明
			return null;
		}
		return salesResultInfo;
	}
}
