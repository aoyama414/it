package sample.connection;

import java.io.InputStream;
import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import sample.config.Config;
import sample.connection.data.RegularyResultInfo;
import sample.connection.data.RegularySendInfo;


// EPSILON定期課金API呼び出しクラス
public class EpsilonRegulary {
	private RegularySendInfo regularySendInfo;
	private Config config;
	public RegularySendInfo getRegularySendInfo() {
		return regularySendInfo;
	}

	public void setRegularySendInfo(RegularySendInfo regularySendInfo) {
		this.regularySendInfo = regularySendInfo;
	}
	public Config getConfig() {
		return this.config;
	}
	public void setConfig(Config config) {
		this.config = config;
	}
	public EpsilonRegulary(){
		this.setRegularySendInfo(new RegularySendInfo());
	}
	public EpsilonRegulary( RegularySendInfo regularySendInfo,Config config){
		this.setConfig(config);
		this.setRegularySendInfo(regularySendInfo);
	}

	// 決済情報送信処理
	public RegularyResultInfo execute(String mode){
		if( getConfig() == null){
			return null;
		}
		// 決済情報送信
		// 送信用の設定を作成
		RequestConfig rc = RequestConfig.custom().setConnectTimeout(2000)
												 .setSocketTimeout(2000)
												 .setMaxRedirects(0)
												 .build();
		// Header定義
		List<Header> header = new ArrayList<Header>();
		header.add( new BasicHeader("Accept-Charset","UTF-8" ))	;
		header.add( new BasicHeader("User-Agent","EPSILON SAMPLE PROGRAM JAVA" ));

		HttpClient client = HttpClientBuilder.create()
										.setDefaultRequestConfig(rc)
										.setDefaultHeaders(header)
										.build();


		List<NameValuePair> param = this.makeSendParam(mode);
		HttpPost post = new HttpPost();
		HttpResponse res = null;

		try {
			post.setEntity(new UrlEncodedFormEntity(param,"UTF-8"));
			//URI
			URI uri = new URI(getConfig().getRegulary_url().get(mode));
			post.setURI(uri);
			res = client.execute(post);
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		RegularyResultInfo regularyResultInfo = new RegularyResultInfo();
		if( res.getStatusLine().getStatusCode() == HttpStatus.SC_OK ){
			// BODYを取得してXMLパーサー呼び出し
			try{
				String xml = EntityUtils.toString(res.getEntity());
				System.out.println(xml);
				InputStream body = new java.io.ByteArrayInputStream(xml.getBytes());
				Document xmlDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(body);

				NodeList resultList = xmlDoc.getElementsByTagName("result");
				for( int i = 0; i < resultList.getLength(); i++) {
					Node node = resultList.item(i);
					NamedNodeMap namesNodeMap = node.getAttributes();
					for( int j =0; j < namesNodeMap.getLength(); j++ ){
						Node attr = namesNodeMap.item(j);
						switch (attr.getNodeName()) {
						case "result":
							regularyResultInfo.setResult(attr.getNodeValue());
							break;
						case "item_code":
							regularyResultInfo.setItemCode(attr.getNodeValue());
							break;
						case "item_price":
							regularyResultInfo.setItemPrice(attr.getNodeValue());
							break;
						case "mission_code":
							regularyResultInfo.setMissionCode(attr.getNodeValue());
							break;
						case "err_code":
							regularyResultInfo.setErrCode(attr.getNodeValue());
							break;
						case "err_detail":
							regularyResultInfo.setErrDetail(new String(URLDecoder.decode(attr.getNodeValue(),"UTF-8").getBytes("UTF-8"),"UTF-8" ));
							break;
						case "user_id":
							regularyResultInfo.setUserId(attr.getNodeValue());
						}
					}
				}
			}catch ( Exception e){
				e.printStackTrace();
				return null;
			}
		}else{
			// 応答が200以外の場合は不明
			return null;
		}
		return regularyResultInfo;
	}
	// 決済情報送信処理
	public RegularyResultInfo execSettlement(String mode,RegularySendInfo regularySendInfo ){
		this.setRegularySendInfo(regularySendInfo);
		return this.execute(mode);
	}

	public List<NameValuePair> makeSendParam(String mode) {
		RegularySendInfo rsi = this.getRegularySendInfo();
		List<NameValuePair> param = new ArrayList<NameValuePair>();
		param.add( new BasicNameValuePair("contract_code", this.getConfig().getContract_code() ));
		param.add( new BasicNameValuePair("item_code", rsi.getItemCode() ));
		param.add( new BasicNameValuePair("user_id", rsi.getUserId() ));
		if( "change".equals(mode)){
			param.add( new BasicNameValuePair("item_price", rsi.getItemPrice().toString()));
		}
		return param;
	}
}
