package sample.connection.data;

public class GetSalesResultInfo {
	private String transCode;
	private String orderNumber;
	private String state;
	private String userId;
	private String userName;
	private String processCode;
	private String lastUpdte;
	private String itemPrice;
	private String memo1;
	private String memo2;
	private String missionCode;
	private String stCode;
	private String contractCode;
	private String itemName;
	private String paymentCode;
	private String userMailAdd;
	private String itemCode;
	private String dueDate;
	private String addInfo;
	private String currencyId;
	private String creditFlag;
	private String creditTime;
	private String cardStCode;
	private String payTime;
	private String conveniCode;
	private String receiptNo;
	private String kigyouCode;
	private String haraikomiUrl;
	private String paid;
	private String receiptDate;
	private String conveniLimit;
	private String conveniTime;
	private String carrierCode;
	private String chargeDate;
	private String rateAmount;
	private String cancelDate;
	private String rateCancelAmount;
	public String getTransCode() {
		return transCode;
	}
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getProcessCode() {
		return processCode;
	}
	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}
	public String getLastUpdte() {
		return lastUpdte;
	}
	public void setLastUpdte(String lastUpdte) {
		this.lastUpdte = lastUpdte;
	}
	public String getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(String itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getMemo1() {
		return memo1;
	}
	public void setMemo1(String memo1) {
		this.memo1 = memo1;
	}
	public String getMemo2() {
		return memo2;
	}
	public void setMemo2(String memo2) {
		this.memo2 = memo2;
	}
	public String getMissionCode() {
		return missionCode;
	}
	public void setMissionCode(String missionCode) {
		this.missionCode = missionCode;
	}
	public String getStCode() {
		return stCode;
	}
	public void setStCode(String stCode) {
		this.stCode = stCode;
	}
	public String getContractCode() {
		return contractCode;
	}
	public void setContractCode(String contractCode) {
		this.contractCode = contractCode;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getPaymentCode() {
		return paymentCode;
	}
	public void setPaymentCode(String paymentCode) {
		this.paymentCode = paymentCode;
	}
	public String getUserMailAdd() {
		return userMailAdd;
	}
	public void setUserMailAdd(String userMailAdd) {
		this.userMailAdd = userMailAdd;
	}
	public String getItemCode() {
		return itemCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	public String getAddInfo() {
		return addInfo;
	}
	public void setAddInfo(String addInfo) {
		this.addInfo = addInfo;
	}
	public String getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}
	public String getCreditFlag() {
		return creditFlag;
	}
	public void setCreditFlag(String creditFlag) {
		this.creditFlag = creditFlag;
	}
	public String getCreditTime() {
		return creditTime;
	}
	public void setCreditTime(String creditTime) {
		this.creditTime = creditTime;
	}
	public String getCardStCode() {
		return cardStCode;
	}
	public void setCardStCode(String cardStCode) {
		this.cardStCode = cardStCode;
	}
	public String getPayTime() {
		return payTime;
	}
	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}
	public String getConveniCode() {
		return conveniCode;
	}
	public void setConveniCode(String conveniCode) {
		this.conveniCode = conveniCode;
	}
	public String getReceiptNo() {
		return receiptNo;
	}
	public void setReceiptNo(String receiptNo) {
		this.receiptNo = receiptNo;
	}
	public String getKigyouCode() {
		return kigyouCode;
	}
	public void setKigyouCode(String kigyouCode) {
		this.kigyouCode = kigyouCode;
	}
	public String getHaraikomiUrl() {
		return haraikomiUrl;
	}
	public void setHaraikomiUrl(String haraikomiUrl) {
		this.haraikomiUrl = haraikomiUrl;
	}
	public String getPaid() {
		return paid;
	}
	public void setPaid(String paid) {
		this.paid = paid;
	}
	public String getReceiptDate() {
		return receiptDate;
	}
	public void setReceiptDate(String receiptDate) {
		this.receiptDate = receiptDate;
	}
	public String getConveniLimit() {
		return conveniLimit;
	}
	public void setConveniLimit(String conveniLimit) {
		this.conveniLimit = conveniLimit;
	}
	public String getConveniTime() {
		return conveniTime;
	}
	public void setConveniTime(String conveniTime) {
		this.conveniTime = conveniTime;
	}
	public String getCarrierCode() {
		return carrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		this.carrierCode = carrierCode;
	}
	public String getChargeDate() {
		return chargeDate;
	}
	public void setChargeDate(String chargeDate) {
		this.chargeDate = chargeDate;
	}
	public String getRateAmount() {
		return rateAmount;
	}
	public void setRateAmount(String rateAmount) {
		this.rateAmount = rateAmount;
	}
	public String getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(String cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getRateCancelAmount() {
		return rateCancelAmount;
	}
	public void setRateCancelAmount(String rateCancelAmount) {
		this.rateCancelAmount = rateCancelAmount;
	}


}
