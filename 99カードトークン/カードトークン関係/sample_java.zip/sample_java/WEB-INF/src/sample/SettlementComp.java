package sample;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sample.config.Config;
import sample.connection.EpsilonGetSales;
import sample.connection.data.GetSalesResultInfo;
public class SettlementComp extends HttpServlet {

	// 通常EPからの決済完了はリダイレクト
	// そのためGetで処理を行う
	public void doGet(HttpServletRequest request,
						HttpServletResponse response)
					throws ServletException, IOException {
		Config config = (Config)request.getAttribute("ep_config");
		// パラメータを取得
		String transCode = request.getParameter("trans_code");
		// trans_codeが未設定の場合は異常な遷移として入力画面に戻しておく
		if( transCode == null || transCode.isEmpty() ){
			request.setAttribute("err_msg", "異常な遷移が検出されました。trans_codeの設定がありません。");
			ServletContext context = this.getServletContext();
			RequestDispatcher dispatcher
				= context.getRequestDispatcher("/jsp/settleInput.jsp");
			dispatcher.forward(request, response);
			return;
		}
		// 決済結果を取得する
		EpsilonGetSales epsilonGetSales = new EpsilonGetSales(config);
		GetSalesResultInfo salesReulstInfo = epsilonGetSales.execute(transCode);
		// 結果に関しては表示部で行うためそのまま属性に設定
		if( salesReulstInfo == null ){
			request.setAttribute("err_msg", "決済結果取得接続処理でエラーが発生しました");
		}else{
			request.setAttribute("resultInfo", salesReulstInfo);
		}
		ServletContext context = this.getServletContext();
		try{
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/getSalesResult.jsp");
		dispatcher.forward(request, response);
		}catch( Exception e){
			System.err.println(e.getMessage());
		}


	}
	// 通常EPからの戻りの場合は、リダイレクトであるためGET
	// POSTの場合は通常の入力ページを表示しておく
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			  throws IOException, ServletException {
		ServletContext context = this.getServletContext();
		RequestDispatcher dispatcher
			= context.getRequestDispatcher("/jsp/settleInput.jsp");
		dispatcher.forward(request, response);


	}
}


