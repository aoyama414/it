package sample.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.yaml.snakeyaml.Yaml;

import sample.Settlement;
import sample.config.Config;
import sample.config.Resource;

public class initFilter implements Filter{
	private static Config config = null;
	private static Resource resource = null;
	private static void setConfig( Config config){
		initFilter.config = config;
	}
	private static void setResource( Resource resource){
		initFilter.resource = resource;
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain){
		try{
			// コンフィグを属性として入れておく
			request.setAttribute("ep_config", initFilter.config);
			// リソースを属性に入れ込んでおく
			request.setAttribute("ep_resource", initFilter.resource);
			// UTF-8対応のみなのでエンコーディングを指定しておく
			request.setCharacterEncoding("UTF-8");
			chain.doFilter(request, response);
		}catch (ServletException se){
		}catch (IOException e){
		}
	}
	public void init(FilterConfig filterConfig) throws ServletException{
		try{
			// CONFIGを読み込んで属性に入れておく
			Yaml yaml = new Yaml();
			Config conf = (Config)yaml.loadAs(Settlement.class.getResourceAsStream("../../../conf/config.yaml"),Config.class);
			initFilter.setConfig(conf);
			Resource resource = (Resource)yaml.loadAs(Settlement.class.getResourceAsStream("../../../conf/resource.yaml"),Resource.class);
			initFilter.setResource(resource);
		}catch( Throwable e){
			System.err.println("YAMLファイルの読込処理中にエラーが発生");
			throw new ServletException("YAMLファイルでの読み込み処理中にエラーが発生");
		}
	}

	public void destroy(){
	}
}

