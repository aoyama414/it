export interface Product {
    id?: number; //商品番号
    name?: string; // 商品名
    checked?: boolean; // 選択済み?
    message?: string; //メッセージ
}

