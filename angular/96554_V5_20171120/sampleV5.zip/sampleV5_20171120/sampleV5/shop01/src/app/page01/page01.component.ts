import {Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges} from "@angular/core";
import {Page01Service} from "./page01.service";
import {Product} from "../interface/product.interface";

// 最上位コンポーネント
@Component({
    selector: "app-root",
    template: `
      <p>
        <!--商品選択コンテナ-->
        <app-sample-container
          [products]="products">
        </app-sample-container>
      </p>
      <p>
        <!--カートコンポーネント-->
        <app-sample-cart [cart]="cart">
        </app-sample-cart>
      </p>
    `,
    providers: [Page01Service]　// Page01専用サービス
})
export class Page01Component implements OnInit, OnDestroy {

    // 商品情報
    products: Product[] = [
    {id: 100, name: "商品０１", checked: false, message: ""},
    {id: 101, name: "商品０２", checked: false, message: ""},
    {id: 102, name: "商品０３", checked: false, message: ""}
];
    // 選択済み商品リスト
    cart: string[] = null;

    constructor(private service: Page01Service) {
    }

    ngOnInit() {
        // サービスにthisの参照を渡す
        this.service.init(this);
    }

    ngOnDestroy(): void {
        // サービスのthisの参照を解放
        this.service.init(null);
    }

}
