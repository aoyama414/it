import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from "@angular/core";
import {Page01Component} from "./page01/page01.component";
import {Page01ItemComponent} from "./page01/page01-item.component";
import {Page01ContainerComponent} from "./page01/page01-container.component";
import {Page01CartComponent} from "./page01/page01-cart.component";

@NgModule({
    declarations: [
        Page01Component,
        Page01ItemComponent,
        Page01ContainerComponent,
        Page01CartComponent,
    ],
    imports: [
        BrowserModule,
    ],
    providers: [
    ],
    bootstrap: [Page01Component]
})
export class AppModule {}