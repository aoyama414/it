import {Component, Input, OnChanges, SimpleChanges} from "@angular/core";
import {Page01Service} from "./page01.service";


@Component({
    selector: "app-sample-cart",
    template: `
      <div class="frame">
        <div class="title">カート</div>
        <p *ngFor="let item of cart">
         {{item}}
        </p>
        <p  *ngIf="cart?.length">
          <button  (click)="cancel()">全ての注文キャンセル</button>
        </p>
      </div>`
})
// カート表示コンポーネント
export class Page01CartComponent implements OnChanges{

    //親から受け取るプロパティ
    @Input() cart;

    constructor(private service: Page01Service) {
    }

    //変更検知
    ngOnChanges(changes: SimpleChanges): void {
        console.log("カートコンポーネント onChange:",changes);
    }

    cancel() {
        console.log("@@@ 全件キャンセル");
        this.service.clearCart();
    }

}
