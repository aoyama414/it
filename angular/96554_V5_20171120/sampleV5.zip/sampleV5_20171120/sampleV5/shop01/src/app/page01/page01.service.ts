import {Injectable} from "@angular/core";
import {Page01Component} from "./page01.component";
import {Product} from "../interface/product.interface";
import * as merge from "deepmerge";


@Injectable()
export class Page01Service {

    componentRef: Page01Component;

    //最上位コンポーネントの参照取得
    init(ref: Page01Component) {
        this.componentRef = ref;
    }

    //商品名のクリック
    clickedItem(id: number) {
        console.log("@@@ 商品名のクリック id=" + id);
        let cart = [];
        let updateProducts =
            this.componentRef.products.map(
                (product) => {
                    if (product.id === id) {
                        product.checked = !product.checked;
                    }
                    if (product.checked) {
                        cart.push(product.name);
                    }
                    return product;
                });
        this.componentRef.products =
            <Product[]>merge(
                {}, updateProducts, {clone: true});
        this.componentRef.cart = cart;
    }

    //全ての注文をキャンセル
    clearCart() {
        console.log("@@@ 選択をすべてクリア");
        let updateProducts: Product[];
        updateProducts = this.componentRef.products.map((product) => {
            product.checked = false;
            return product;
        });
        this.componentRef.products = updateProducts;
        this.componentRef.cart = null;
    }

}
