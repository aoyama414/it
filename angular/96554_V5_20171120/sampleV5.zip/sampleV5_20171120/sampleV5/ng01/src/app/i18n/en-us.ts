/**
 * Pipe処理用の英語辞書
 */
export const en_us={
    "labelName": "CustomerName",
    "labelTel": "Tel",
    "labelAddress": "Address",
    "labelUpdateTime": "Update",
    "labelSearch": "Search Word",
    "labelLogout": "Logout",
};
