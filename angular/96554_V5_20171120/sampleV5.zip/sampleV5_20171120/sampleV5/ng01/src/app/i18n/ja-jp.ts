/**
 * Pipe処理用の日本語辞書
 */
export const ja_jp={
    "labelName": "会社名",
    "labelTel": "電話番号",
    "labelAddress": "住所",
    "labelUpdateTime": "更新日時",
    "labelLogout": "ログアウト",
    "labelSearch": "検索文字",
};


