import * as fetch from "isomorphic-fetch";
 
const url = "http://localhost:3000/auth";

const token=`■■ここにトークンデータを貼り付け`;

let param:any ={};
//HTTPヘッダの設定
param.headers= {
	"Accept": "application/json",
    "Content-Type": "application/json",
    "cache": "no-cache",
};
//トークンをHTTPボディ部分にJSON形式で送る設定
param.body = JSON.stringify({token:token});
param.method="POST";

//fetch APIでリクエスト送信
fetch(url, param)
	.then((obj) => {
		return obj.json();
	})
	.then((obj) => {
		// レスポンスデータを出力
		console.log(JSON.stringify(obj))
	});
	