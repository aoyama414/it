// 外部ライブラリの読み込み
import * as bodyParser from "body-parser";
import * as cookieParser from "cookie-parser";
import * as express from "express";
import {NextFunction, Request, Response} from "express";
import * as logger from "morgan";
import * as cors from "cors";

// プロジェクト内クラスの読み込み
import {ServerConfig} from "./common/serverConfig";
import {Sqlite} from "./common/sqlite";
import {AppRes} from "./common/appRes";
import {Api} from "./routes/api";
import {Auth} from "./routes/auth";

// ----------------------------------------
// Sqliteデータベースの初期化
// ----------------------------------------
// データベースのオープン
Sqlite.init();

// ----------------------------------------
// Express Webサーバーの初期化
// ----------------------------------------
// Expressのインスタンス取得
const app = express();

// ----------------------------------------
// クロスドメインリクエストの許可
// Angular CLIプロキシー利用時に必要
// ----------------------------------------
app.use(cors({
    credentials: true,
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS",
    origin: ["http://localhost:4200", "http://localhost:49152"]
}));

// ----------------------------------------
// デバッグ用
// ----------------------------------------
app.use((req: Request, res: Response, next: NextFunction) => {
    console.log((new Date().toLocaleTimeString()) +
        "@@@リクエストされたUrl" + req.url);
    next();
});

// ----------------------------------------
// ミドルウェアの設定
// ----------------------------------------

// JSON変換
app.use(bodyParser.json(
    {
        limit: ServerConfig.MAX_REQUEST_SIZE
    }));
// Cookie読み書き
app.use(cookieParser());
// ログの取得
app.use(logger("dev"));

// -------------------------------------------------
// リクエスト処理ルート設定
// -------------------------------------------------
// 遅延ロードモジュールはログイン完了まで取得できない
app.use("/*.chunk.js", Auth.checkToken);

// Login関連ファイルは認証なしで許可
app.use("/", express.static(ServerConfig.LOGIN_FILE_DIR));

// エラーログ受信は認証なしで許可
app.post("/api/log", Api.setLog);

// ユーザー認証(フォーム認証)
app.post("/auth", Auth.checkUser);

// appファイルのアクセス許可(トークン認証)
app.use("/app", Auth.checkToken);
app.use("/app", express.static(ServerConfig.APP_FILE_DIR));
app.use("/app", Auth.redirect);

// adminファイルのアクセス許可(トークン認証)
app.use("/admin", Auth.checkAdmin);
app.use("/admin", express.static(ServerConfig.ADMIN_FILE_DIR));
app.use("/admin", Auth.redirect);

// WebAPIのアクセス許可(トークン認証)
app.use("/api", Auth.checkToken);
app.get("/api/user", Api.getUser);
app.get("/api/customer", Api.getCustomer);
app.post("/api/report", Api.setReport);
app.get("/api/report/:begin/:size", Api.getReport);
app.delete("/api/report/:reportId", Api.deleteReport);
app.use("/api/admin", Auth.checkAdmin);
app.get("/api/admin/log", Api.getLog);
app.delete("/api/admin/log/:timeStamp", Api.deleteLog);

// 未定義パスへのリクエスト
app.use((req: Request, res: Response, next: NextFunction) => {
    next(
        {
            message: "リクエストのパスが未定義です。" + req.url
        }
    );
});

// エラー処理（エラー内容をJSONで返す）
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    if (!res.headersSent) {
        AppRes.sendJson(
            res,
            false,
            err.message,
            err.data);
    }
});

// -------------------------------------------------
// リクエストの受信開始(Webサーバー起動)
// -------------------------------------------------
const port = ServerConfig.PORT_NUMBER;
app.listen(
    port, () => {
        console.info(port + "番ポートで待機中" + (new Date()).toLocaleTimeString());
    })
    .on(
        "error", (error) => {
            console.error("ポートが開けません" + error.message);
            process.exit(1);
        });
