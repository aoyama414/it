// ユーザー情報の型
export interface User {
    id: string;
    password?: string;
    name: string;
    roll: string;
    dept: string;
}
