"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServerConfig = (function () {
    function ServerConfig() {
    }
    return ServerConfig;
}());
/** Expressサーバー設定 **/
// Webサーバー待ち受けポート番号
ServerConfig.PORT_NUMBER = 3000;
// 受信するデータの最大サイズ
ServerConfig.MAX_REQUEST_SIZE = 20000000;
/** 実行ファイルの配置場所 **/
// フロントエンドモジュールの保存場所
ServerConfig.APP_PROJECT_DIR = "../ng01";
// ログイン関連ファイルの保存場所
ServerConfig.LOGIN_FILE_DIR = ServerConfig.APP_PROJECT_DIR + "/dist";
// アプリケーション関連ファイルの保存場所
ServerConfig.APP_FILE_DIR = ServerConfig.APP_PROJECT_DIR + "/dist";
// システム管理者用関連ファイルの保存場所
ServerConfig.ADMIN_FILE_DIR = ServerConfig.APP_PROJECT_DIR + "/dist";
/**トークン関連**/
//  単位(sec)　新規生成するトークンの有効期間（8時間）
ServerConfig.TOKEN_TIMEOUT = 8 * 3600;
// token書き込み時のキー名
ServerConfig.JWT_HEADER = "authorization";
// JWTのprefix
ServerConfig.TOKEN_PREFIX = "Bearer ";
/** データベース関連**/
ServerConfig.SQLITE_DB_PATH = "/db/myDB01.db"; // データベースファイルの場所
// Web API関連
ServerConfig.adminApiUrl = "/api/admin/"; //  管理者用Web API接続先
ServerConfig.userApiUrl = "/apix/"; //  ユーザー用Web API接続先
exports.ServerConfig = ServerConfig;
