"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var serverConfig_1 = require("./serverConfig");
var key_1 = require("./key");
var jwt = require("jsonwebtoken");
var Jwt = (function () {
    function Jwt() {
    }
    // トークンを生成しset-cookieヘッダに書き出し
    Jwt.setNewToken = function (res, userData, timeout) {
        // トークン生成
        var tokenStr = jwt.sign(userData, key_1.Key.PRIVATE, {
            algorithm: "RS256",
            expiresIn: timeout || serverConfig_1.ServerConfig.TOKEN_TIMEOUT * 60,
        });
        // set-cookieヘッダ書き込み
        res.cookie(serverConfig_1.ServerConfig.JWT_HEADER, serverConfig_1.ServerConfig.TOKEN_PREFIX + tokenStr);
        return tokenStr;
    };
    // reqオブジェクトからトークン取得
    Jwt.getToken = function (req) {
        var tokenStr = req.cookies[serverConfig_1.ServerConfig.JWT_HEADER] || "";
        tokenStr = tokenStr.replace(serverConfig_1.ServerConfig.TOKEN_PREFIX, "").trim();
        return tokenStr;
    };
    // トークンの検証
    Jwt.verifyToken = function (token) {
        var tokenObj;
        try {
            tokenObj = jwt.verify(token, key_1.Key.PUBLIC, { algorithms: ["RS256"] });
        }
        catch (e) {
            console.error("@@@@ トークン不正" + e.message);
            return null;
        }
        console.log("@@@@ トークン正常");
        return tokenObj;
    };
    // トークンからユーザー情報取得
    Jwt.getUserData = function (tokenObj) {
        // デコード結果からiat(発行日時)とexp(有効期限)を削除
        delete tokenObj.iat;
        delete tokenObj.exp;
        return tokenObj;
    };
    return Jwt;
}());
exports.Jwt = Jwt;
