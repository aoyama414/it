import {Response, Request, NextFunction} from "express";
import {ResJson} from "../class/resJson";

export class AppRes {

    // レスポンスデータ生成
    public static sendJson(res: Response, isSuccess = false,
                           message = "", jsonData = null) {
        const
            obj: ResJson = {
                data: jsonData,
                message: message,
                success: isSuccess
            };
        res.set("Cache-Control" , "no-cache").json(obj);
    }

}
