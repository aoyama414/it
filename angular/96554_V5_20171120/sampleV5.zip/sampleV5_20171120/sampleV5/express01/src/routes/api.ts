import {NextFunction, Request, Response} from "express";
import {Sqlite} from "../common/sqlite";
import {AppRes} from "../common/appRes";
import {BrowserConfig} from "../common/browserConfig";

export class Api {

    // ----------------------------------------
    // ユーザー情報取得
    // ----------------------------------------
    public static getUser(// データ取得
                          req: Request, res: Response, next: NextFunction) {
        const data = {
            browserConfig: BrowserConfig,
            userData: res.locals.userData,
        };
        // レスポンス出力
        AppRes.sendJson(res, true, "ユーザー情報取得成功", data);
    }

    // ----------------------------------------
    // 顧客情報の取得
    // ----------------------------------------
    public static async getCustomer(req: Request, res: Response, next: NextFunction) {
        // ----------------------------------------
        // 顧客基本情報と売上実績取得
        // ----------------------------------------
        // データ取得
        const userId = res.locals.userData.id;
        let data = {
            customer: null,
            report: null,
        };
        let param: any = {$userId: userId};
        // SQL文作成
        let sql = `select 
            t_customer.* 
            ,ifnull(r.reportNum,0) as reportNum   
             from t_customer LEFT OUTER JOIN   
            (select customerId as reportCustomerId,  
            count(*) as reportNum 
            from t_report group by customerId) as r   
            ON t_customer.id=r.reportCustomerId 
            where t_customer.userId=$userId 
            order by id ASC`;
        // SQL文実行
        let result = await Sqlite.select(sql, param);
        data.customer = result.rows;
        // ----------------------------------------
        // 顧客ごとに最近の報告取得
        // ----------------------------------------
        // データ取得
        param = {$userId: userId, $maxRecord: 3};
        // SQL文作成
        sql = `select reportId,timeStamp,title,reportStr,customerId,
         userId,dataLabel, resizePhoto IS NOT NULL AS isFileExist,
         resizePhoto 
         from t_report  as t1
          where userId=$userId  
          and 
          reportId in 
          (
          select reportId 
		    from	t_report as t2 
		    where 
			    t1.customerId = t2.customerId 
		    order by 
			    timeStamp desc 
		    limit $maxRecord
		)
          order by 
          customerId ASC , 
          timeStamp DESC`;
        // SQL文実行
        result = await Sqlite.select(sql, param);
        data.report = result.rows;
        // レスポンス出力
        if (!result.err) {
            AppRes.sendJson(res, true, "顧客情報取得成功", data);
        } else {
            next({message: "顧客情報取得失敗"});
        }
    }

    // ----------------------------------------
    // 報告の登録
    // ----------------------------------------
    public static async setReport(req: Request, res: Response, next: NextFunction) {
        // ----------------------------------------
        // 重複登録の確認
        // ----------------------------------------
        // データ取得
        const reportObj = req.body.report;
        let param: any = {$reportId: reportObj.reportId};
        // SQL文作成
        let sql = "select reportId from t_report where reportId=$reportId";
        // SQL文実行
        let result = await Sqlite.select(sql, param);
        // ----------------------------------------
        // 同一レポートIDが未登録の時は新規登録を行う
        // ----------------------------------------
        if (result.rows.length === 0) {
            // SQL文作成
            sql = `INSERT INTO t_report  
            (reportId,timeStamp,title,reportStr,customerId,
            userId,dataLabel,resizePhoto)  
            VALUES($reportId,$timeStamp,$title,$reportStr,
            $customerId,$userId,$dataLabel,$resizePhoto)`;
            const timestamp = Date.now();
            param = {
                $customerId: reportObj.customerId,
                $dataLabel: "report",
                $reportId: reportObj.reportId,
                $reportStr: reportObj.reportStr,
                $resizePhoto: req.body.resizePhoto,
                $timeStamp: timestamp,
                $title: reportObj.title,
                $userId: res.locals.userData.id,
            };
            // SQL文実行
            result = await Sqlite.insert(sql, param);
        }
        // レスポンス出力
        if (!result.err) {
            AppRes.sendJson(
                res, true, "報告登録成功", "data:{count:result.length}");
        } else {
            next({message: "報告登録失敗"});
        }
    }

    // ----------------------------------------
    // 報告の削除
    // ----------------------------------------
    public static async deleteReport(req: Request, res: Response, next: NextFunction) {
        // データ取得
        const param = {$reportId: req.params.reportId};
        // SQL文作成
        const sql = `delete from t_report where reportId = $reportId`;
        // SQL文実行
        let result;
        if (req.params.reportId) {
            result = await Sqlite.delete(sql, param);
        }
        // レスポンス出力
        if (result) {
            AppRes.sendJson(res, true, "報告削除成功", "");
        } else {
            next({message: "報告削除失敗"});
        }
    }

    // ----------------------------------------
    // 報告履歴の取得
    // ----------------------------------------
    public static async getReport(req: Request, res: Response, next: NextFunction) {
        // データ取得
        const begin = Number(req.params.begin);
        const size = Number(req.params.size);
        const param = {$begin: begin, $end: begin + size - 1};
        // SQL文作成
        const sql = `select id,category,report,strDate,sm 
                    from t_history where id between $begin  and $end`;
        // SQL文実行
        const result = await Sqlite.select(sql, param);
        // レスポンス出力
        if (!result.err) {
            AppRes.sendJson(res, true, "報告履歴取得成功", result.rows);
        } else {
            next({message: "報告履歴取得失敗"});
        }
    }

    // ----------------------------------------
    // エラーログ登録
    // ----------------------------------------
    public static async setLog(req: Request, res: Response, next: NextFunction) {
        // データ取得
        const timeStamp = req.body.timeStamp;
        const timeStr = req.body.timeStr;
        const message = req.body.message;
        const userAgent = req.body.userAgent;
        const param = {
            $message: message,
            $timeStamp: timeStamp,
            $timeStr: timeStr,
            $userAgent: userAgent,
        };
        // SQL文作成
        const sql = `INSERT INTO t_error  
            (timeStamp,timeStr,message,userAgent)  
            VALUES($timeStamp,$timeStr,$message,$userAgent)`;
        // SQL実行
        const result: any = await  Sqlite.insert(sql, param);
        // レスポンス出力
        if (result) {
            AppRes.sendJson(res, true, "エラーログ登録成功", "");
        } else {
            next({message: "エラーログ登録失敗"});
        }
    }

    // ----------------------------------------
    // エラーログの削除
    // ----------------------------------------
    public static async deleteLog(req: Request, res: Response, next: NextFunction) {
        // データ取得
        const timeStamp = req.params.timeStamp;
        const param = {
            $timeStamp: timeStamp,
        };
        // SQL文作成
        const sql = `DELETE from t_error  
            WHERE timeStamp=$timeStamp`;
        // SQL文実行
        const result: any = await  Sqlite.delete(sql, param);
        // レスポンス出力
        if (result) {
            AppRes.sendJson(res, true, "エラーログ削除成功", "");
        } else {
            next({message: "エラーログ削除失敗"});
        }
    }

    // ----------------------------------------
    // エラーログの取得
    // ----------------------------------------
    public static async getLog(req: Request, res: Response, next: NextFunction) {
        const param = {$maxRecord: 20};
        // SQL文作成
        const sql = `select id,timeStamp,message,userAgent 
        from t_error order by timeStamp DESC limit $maxRecord`;
        // SQL文実行
        const result = await Sqlite.select(sql, param);
        // レスポンス出力
        const data = result.rows;
        if (!result.err) {
            AppRes.sendJson(res, true, "ログ情報取得成功", data);
        } else {
            next({message: "ログ情報取得失敗"});
        }
    }
}
