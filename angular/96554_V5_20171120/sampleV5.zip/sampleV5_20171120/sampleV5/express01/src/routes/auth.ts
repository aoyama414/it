import {NextFunction, Request, Response} from "express";
import {User} from "../class/User";
import {Jwt} from "../common/jwt";
import {ServerConfig} from "../common/serverConfig";
import {Sqlite} from "../common/sqlite";
import {AppRes} from "../common/appRes";
import * as jsSHA from "jssha";

export class Auth {

    // ----------------------------------------
    // ユーザー認証（ログイン）
    // ----------------------------------------
    public static async checkUser(req: Request, res: Response, next: NextFunction) {

        // ID,パスワード取得
        const userId = req.body.userId;
        const password = req.body.password;

        // データベースにユーザー情報照会
        const sql = `select id,name,roll,dept,password 
            from t_user where id=$id`;
        const param = {$id: userId};
        const result: any = await Sqlite.select(sql, param);

        // id検証
        if (result.rows.length === 0) {
            next({message: "IDが不正"});
            return;
        }

        // パスワード検証
        // データベースの検索結果からユーザ情報取得
        const userData: User = result.rows[0];
        // 受信したパスワードのハッシュ値取得
        const shaObj = new jsSHA("SHA-256", "TEXT");
        shaObj.update(password);
        const hash = shaObj.getHash("B64");
        if (hash !== userData.password) {
            next({message: "パスワードが不正"});
            return;
        }
        console.log("@@@@ ユーザ認証成功");

        // トークンの作成
        delete userData.password; // ユーザ情報からパスワードを削除
        const token = Jwt.setNewToken(
            res,
            userData,
            ServerConfig.TOKEN_TIMEOUT);

        // ロールごとのwebApiの接続先設定
        let apiUrl = "";
        switch (userData.roll) {
            case "admin":
                apiUrl = ServerConfig.adminApiUrl;
                break;
            case "user":
            default:
                apiUrl = ServerConfig.userApiUrl;
        }

        const data = {apiUrl, userData};
        AppRes.sendJson(res, true, "ログイン成功", data);
    }

    // ----------------------------------------
    // トークン認証
    // ----------------------------------------
    public static checkToken(req: Request, res: Response, next: NextFunction) {
        // reqオブジェクトからトークン取得
        let token = Jwt.getToken(req);
        if (!token) {
            next({message: "トークンが空白"});
            return;
        }
        // トークン検証
        const tokenObj = Jwt.verifyToken(token);
        if (tokenObj) {
            // トークンからユーザー情報取得
            const userData = Jwt.getUserData(tokenObj);
            // トークンの生成しset-cookieヘッダに書き出し
            token = Jwt.setNewToken(res, userData,
                ServerConfig.TOKEN_TIMEOUT);
            // ユーザー情報を一時保存
            res.locals.userData = userData;
            next();
        } else {
            next({message: "トークンが無効"});
        }
    }

    // ----------------------------------------
    // 管理者権限チェック
    // ----------------------------------------
    public static checkAdmin(req: Request, res: Response, next: NextFunction) {
        if (res.locals.userData.roll === "admin") {
            next();
        } else {
            next({message: "管理者のみ利用可能"});
        }
    }

    // ----------------------------------------
    // ログイン画面へリダイレクト
    // ----------------------------------------
    public static redirect(req: Request, res: Response, next: NextFunction) {
        res.redirect("/");
    }

}
