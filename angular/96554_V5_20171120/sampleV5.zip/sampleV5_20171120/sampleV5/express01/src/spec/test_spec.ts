import * as fs from "fs";
import {Const} from "./testConst";
import {TestUtility} from "./testUtility";
import * as jwt from "jsonwebtoken";
import {Jwt} from "../common/jwt";
import {BrowserConfig} from "../common/browserConfig";

describe("顧客管理システムWeb APIテスト", () => {

    let cookie;

    describe("一般ユーザ向けWeb APIテスト", () => {

        it("ユーザーログイン", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/auth";
            const reqParam: RequestInit = {
                body: Const.USER_LOGIN_DATA,
                method: "POST",
            };
            // 評価条件の設定
            const matcher = (result) => {
                expect(result.body.success).toBeTruthy();
                expect(result.data).toEqual(
                    {
                        apiUrl: "/api/",
                        userData: {
                            dept: "総務部",
                            id: 1234,
                            name: "安藤　レイコ",
                            roll: "user",
                        },
                    },
                );
                // cookieからトークンを抽出して検証
                let token = result.cookie.replace(
                    "authorization=Bearer%20", "").trim();
                token = token.replace("; Path=/", "").trim();
                // トークンの検証
                expect(Jwt.verifyToken(token)).toBeTruthy();
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        cookie = result.cookie;
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("ユーザー情報取得", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/user";
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "GET",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
                // 値の完全一致検証
                expect(result.body.data.userData).toEqual({
                    dept: "総務部",
                    id: 1234,
                    name: "安藤　レイコ",
                    roll: "user",
                });
                // 値の完全一致検証
                expect(result.body.data.browserConfig).toEqual({
                    AUTO_LOGOUT: BrowserConfig.AUTO_LOGOUT,
                    CHECK_TOKEN_INTERVAL: BrowserConfig.CHECK_TOKEN_INTERVAL,
                    DB_KEY: BrowserConfig.DB_KEY
                });
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("顧客情報取得", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/customer";
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "GET",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
                expect(result.data.customer.length).toEqual(30);
                TestUtility.checkProperties(
                    result.data, Const.PROP_UPDATE_DATA);
                const customers = result.data.customer;
                customers.map((v) =>
                    TestUtility.checkProperties(v, Const.PROP_CUSTOMER));
                const reports = result.data.report;
                reports.map((v) =>
                    TestUtility.checkProperties(v, Const.PROP_REPORT));
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("報告登録", (done) => {
            // パラメータの設定
            const photo = fs.readFileSync(Const.IMAGE_FILE);
            const imageData = new Buffer(photo).toString("base64");
            const url = Const.BASE_URL + "/api/report";
            const reqParam: RequestInit = {
                body: {
                    report: Const.TEST_REPORT,
                    resizePhoto: imageData,
                },
                headers: {cookie},
                method: "POST",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("報告削除", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/report/"
                + Const.TEST_REPORT.reportId;
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "DELETE",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    });
        });

        it("報告履歴取得", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/report/1/30";
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "GET",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
                expect(result.data.length).toEqual(30);
                const reports = result.data;
                reports.map((v) => TestUtility.checkProperties(v, Const.PROP_HISTORY));
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });
    });

    describe("システム管理者向けWeb APIテスト", () => {

        it("管理者ログイン", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/auth";
            const reqParam: RequestInit = {
                body: Const.ADMIN_LOGIN_DATA,
                method: "POST",
            };
            // 評価条件の設定
            const matcher = (result) => {
                expect(result.body.success).toBeTruthy();
                expect(result.data).toEqual(
                    {
                        apiUrl: "/api/admin/",
                        userData: {
                            dept: "システム部",
                            id: 1000,
                            name: "管理者01",
                            roll: "admin",
                        },
                    },
                );
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        cookie = result.cookie;
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("ログ登録", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/log";
            const reqParam: RequestInit = {
                body: Const.TEST_ERROR_LOG,
                method: "POST",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("ログ取得", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/admin/log";
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "GET",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
                expect(result.data.length).toEqual(20);
                const log = result.data;
                log.map((v) => TestUtility.checkProperties(v, Const.PROP_LOG));
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });

        it("ログ削除", (done) => {
            // パラメータの設定
            const url = Const.BASE_URL + "/api/admin/log/" +
                Const.TEST_ERROR_LOG.timeStamp;
            const reqParam: RequestInit = {
                headers: {cookie},
                method: "DELETE",
            };
            // 評価条件の設定
            const matcher = (result) => {
                // 要求の成功・失敗確認
                expect(result.body.success).toBeTruthy();
            };
            // HTTPリクエストとレスポンスの評価
            TestUtility.request(url, reqParam)
                .then(
                    (result) => {
                        matcher(result);
                        done();
                    })
                .catch((e) => console.error(e.message));
        });
    });

});
