// Web API自動テスト用定数
import {BrowserConfig} from "../common/browserConfig";

export class Const {

    // テスト対象のサーバURL
    public static BASE_URL = "http://localhost:3000";

    // ユーザー権限でのログイン時のユーザIDとパスワード
    public static USER_LOGIN_DATA = {
        password: "0000",
        userId: "1234",
    };

    // システム管理者権限でのログイン時のユーザIDとパスワード
    public static ADMIN_LOGIN_DATA = {
        password: "0000",
        userId: "1000",
    };

    // 報告登録のテストデータ
    public static TEST_REPORT = {
        customerId: "1001",
        reportId: "999999",
        reportStr: "報告テスト文章報告テスト文章報告テスト" +
            "文章報告テスト文章",
        title: "報告テスト０１",
    };

    // 報告登録に利用する添付写真
    public static IMAGE_FILE = "./src/spec/photo01.jpg";

    // エラーログ登録に利用するテストデータ  
    public static TEST_ERROR_LOG = {
        message: `エラーログテストーーエラーログテストーー
        エラーログテストーーエラーログテストーーエラーログテストーー
        エラーログテストーーエラーログテストーーエラーログテストーー
        エラーログテストーーエラーログテストーーエラーログテストーー`,
        timeStamp: "14957217432570",
        timeStr: "20990101T12:00:00",
        userAgent: `テストUserAgentテストUserAgent
        テストUserAgentテストUserAgent`,
    };

    //  HTTPリクエストにBodyがある場合に設定するHTTPヘッダ
    public static WITHBODY_HEADERS = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "cache": "no-cache",
    };
    //  HTTPリクエストにBodyが無い場合に設定するHTTPヘッダ
    public static NOBODY_HEADERS = {
        Accept: "application/json",
        cache: "no-cache",
    };

    //  受信する定期更新オブジェクトのプロパティ名のリスト
    public static PROP_UPDATE_DATA = ["customer", "report"];

    //  受信する顧客オブジェクトのプロパティ名のリスト
    public static PROP_CUSTOMER =
        ["address", "address_en", "contract", "dataLabel",
            "goods", "id", "label", "name", "name_en", "pc", "person",
            "person_en", "reportNum", "revenue", "service",
            "tel", "updateTime", "userId"];

    //  受信する報告オブジェクトのプロパティ名のリスト
    public static PROP_REPORT =
        ["customerId", "dataLabel", "isFileExist", "reportId",
            "reportStr", "resizePhoto", "timeStamp", "title", "userId"];

    //  受信する履歴オブジェクトのプロパティ名のリスト
    public static PROP_HISTORY =
        ["id", "category", "report", "sm", "strDate"];

    //  受信するログオブジェクトのプロパティ名のリスト
    public static PROP_LOG =
        ["id", "timeStamp", "message", "userAgent"];
}
