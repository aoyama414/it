import {Injectable} from "@angular/core";
import {CryptoService} from "./crypto.service";
import * as NeDB from "nedb";

@Injectable()
export class DbService {

    // データベースのインスタンス
    db: NeDB;
    // IndexedDBのkey名として利用
    DB_NAME = "test01";
    // インメモリで実行？
    IN_MEMORY = false;
    // 保存データの暗号化？
    CRYPTO = false;
    // 暗号パスフレーズ;
    DB_KEY = `78wgyd9OOQTgkEp3c6Vj5sR32zorKHT
    dav4NVvyyqsa13RZKcYiewKF3KOOZYv5HAg5Ix
    NM5ncCZecLrlpyCxSUnnvmg8H4tbckA`;

    constructor(private cryptoService: CryptoService) {
    }

    /**
     *  データベースを開く
     * @returns {Promise<void>}
     */
    private async open(): Promise<string> {
        console.log("@@@@ DBオープン開始");
        // すでに開いているときは何もしない.
        if (this.db) {
            return;
        }
        // ---------DB初期設定----------
        let dbParam: NeDB.DataStoreOptions = {};
        // DB名
        dbParam.filename = this.DB_NAME;
        // 暗号処理関数の設定
        if (this.CRYPTO) {
            dbParam.afterSerialization =
                (line: string): string => {
                    console.log("@@@" + line);
                    return this.cryptoService.encrypt(line, this.DB_KEY)
                        .replace(/\n/g, "");
                };
            dbParam.beforeDeserialization =
                (line: string): string => {
                    return this.cryptoService.decrypt(line, this.DB_KEY);
                };
        }
        // インメモリ動作のオン・オフ
        dbParam.inMemoryOnly = this.IN_MEMORY;
        // ----------DBインスタンス生成----------
        this.db = new NeDB(dbParam);
        // ----------DBオープン----------
        await new Promise((resolve, reject) => {
            this.db.loadDatabase((err) => {
                if (err) {
                    reject("@@@ DBオープン失敗");
                    this.db = null;
                    this.clear();
                } else {
                    resolve("DBオープン成功");
                }
            });
        });
    }

    /**
     * データインサート
     * @param obj　追加データ
     * @return {Promise<number>} インサートされた件数
     */
    async insert(obj: any): Promise<number> {
        console.log("@@@@ DBデータ追加開始");
        await this.open();
        return new Promise<any>((resolve, reject) => {
            this.db.insert(obj, (err, newDocs) => {
                if (!err) {
                    if (newDocs.length === obj.length) {
                        console.log("@@@@ DB insert成功:" + newDocs.length + "件");
                        return resolve(newDocs.length);
                    }
                }
                console.log("@@@@ DB insert失敗");
                return reject(-1);
            });
        });
    }

    /**
     * データ検索
     * @param query 検索条件
     * @param projection　出力項目
     * @param sort　並べ替え
     * @return {Promise<any>}
     */
    async find(query = {}, projection = {}, sort = {}): Promise<any> {
        console.log("@@@@ DB検索開始");
        await this.open();
        return new Promise((resolve, reject) => {
            this.db.find(query, projection).sort(sort)
                .exec((err, docs) => {
                    if (!err) {
                        console.log("@@@@ DB find成功" + docs.length);
                        return resolve(docs);
                    } else {
                        console.log("@@@@ DB find失敗");
                        return reject("DB_ERROR:FIND");
                    }
                });
        });
    }

    /**
     * データの全件削除
     * @return {Promise<any>}
     */
    async clear(): Promise<any> {
        // すでに開いているときは何もしない.
        if (this.db) {
            return Promise.resolve("locked");
        }
        console.log("@@@ DB clear開始");
        return new Promise((resolve, reject) => {
            let req = window.indexedDB.deleteDatabase("NeDB");
            req.onsuccess = (event) => {
                console.log("@@@DB clear成功");
                return resolve("success");
            };
            req.onerror = (event) => {
                console.log("@@@DB clear失敗");
                return reject("error");
            };
        });
    }

}

