import {Component} from "@angular/core";
import {CryptoService} from "./crypto.service";
import {DbService} from "./db.service";
import {customer} from "./customer.data";


@Component({
    selector: "app-root",
    templateUrl: "./app.component.html",
    styles: ["input{width:100%;}"],
    providers: [DbService, CryptoService]
})
export class AppComponent {
    encStr = "";
    decStr = "";
    dbMessage = "";
    result = "";
    resultMessage = "";

    constructor(
        private cryptoService: CryptoService,
        private dbService: DbService) {
    }

    // 暗号化ボタンクリック
    clickEncrypt(originalData: string, key: string): void {
        this.encStr = this.cryptoService.encrypt(originalData, key);
    }

    // 復号ボタンクリック
    clickDecrypt(key: string): void {
        this.decStr = this.cryptoService.decrypt(this.encStr, key);
    }

    // DB生成ボタンをクリック
    async clickOpenDb() {
        // DBをクリアしてからデータ登録
        let ret = await this.dbService.clear();
        console.log("@@@" + ret);
        // 顧客データの登録
        if (ret === "success") {
            let count = await this.dbService.insert(customer);
            this.dbMessage = count + "件登録しました";
        }
    }

    // 検索実行ボタンをクリック
    async clickFindDb(query: string, projection: string, sort: string) {
        // 引数は入力欄の文字列のためオブジェクト化後にNeDBへ渡す
        let result: any =
            await this.dbService.find(
                query && JSON.parse(query),
                projection && JSON.parse(projection),
                sort && JSON.parse(sort));
        // 検索結果をJSON形式で整形
        this.result = JSON.stringify(result, null, 4)
            .replace(/\n/g, "<br>").replace(/\s{4}/g, "　");
        this.resultMessage = (result && result.length).toString() + "件見つかりました";

    }

}
