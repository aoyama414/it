import {Injectable} from "@angular/core";
import * as CryptoJS from "crypto-js";

@Injectable()
export class CryptoService {

    // 暗号化
    encrypt(str: string, key: string): string {
        let crypted = CryptoJS.AES.encrypt(str, key);
        return crypted.toString();
    }

    // 復号
    decrypt(encStr: string, key: string): string {
        let decrypted = CryptoJS.AES.decrypt(encStr, key);
        return decrypted.toString(CryptoJS.enc.Utf8);
    }

}
