import { ChatDatePipe } from './chat-date.pipe';

describe('ChatDatePipe', () => {
  it('create an instance', () => {
    const pipe = new ChatDatePipe();
    expect(pipe).toBeTruthy();
  });
});
