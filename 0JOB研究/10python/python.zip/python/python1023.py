# 10.2.3 二項分布に従う乱数を生成する
import numpy as np

# シードを設定します
np.random.seed(0)
# 0.5の確率で成功する試行を100回行った時の成功数を10,000回分求めて変数numsに代入してください
nums = np.random.binomial(100, 0.5, size=10000)

# 成功率の平均を出力してください
print(nums.mean()/100)
