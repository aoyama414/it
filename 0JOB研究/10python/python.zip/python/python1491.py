# 添削問題

import pandas as pd
import numpy as np
from numpy import nan as NA

df = pd.read_csv(
    "http://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data", header=None)
# カラムにそれぞれの数値が何を表しているかを追加します
df.columns = ["", "Alcohol", "Malic acid", "Ash", "Alcalinity of ash", "Magnesium",
              "Total phenols", "Flavanoids", "Nonflavanoid phenols", "Proanthocyanins",
              "Color intensity", "Hue", "OD280/OD315 of diluted wines", "Proline"]

# 変数dfの上から１０行を変数df_tenに代入し、表示してください
df.reset_index()
df_ten = df.head(10)
print(df_ten)

# データの一部を欠損させてください
df_ten.iloc[1, 0] = NA
df_ten.iloc[2, 3] = NA
df_ten.iloc[4, 8] = NA
df_ten.iloc[7, 3] = NA
print(df_ten)

# fillnaを用いてNaNの部分にその列の平均値を代入してください
df_ten.fillna(df_ten.mean())
print(df_ten)

# "Alcohol"列の平均を出力してください
print(df_ten["Alcohol"].mean())

# 重複している行を削除してください
df_ten.append(df_ten.loc[3])
df_ten.append(df_ten.loc[6])
df_ten.append(df_ten.loc[9])
df_ten = df_ten.drop_duplicates()
print(df_ten)


# Alcohol列の分割の粒度リストを作成してください
alcohol_bins = [0, 5, 10, 15, 20, 25]
alcoholr_cut_data = pd.cut(df_ten["Alcohol"], alcohol_bins)

# ビン数を集計して出力してください
print(pd.value_counts(alcoholr_cut_data))
