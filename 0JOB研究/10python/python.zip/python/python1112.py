# 11.1.2 グラフの表示範囲を設定する
# 11.1.3 グラフの要素に名前を設定する
# 11.1.4 グラフにグリッドを表示する
# 11.1.5 グラフの軸に目盛りを設定する

# matplotlib.pyplotをpltとしてimportします
import matplotlib.pyplot as plt
import numpy as np

# np.piは円周率を表します
x = np.linspace(0, 2*np.pi)
y = np.sin(x)

# グラフのタイトルを設定してください
plt.title("y=sin(x)( 0< y< 1)")
# グラフのx軸とy軸に名前を設定してください
plt.xlabel("x-axis")
plt.ylabel("y-axis")

# グラフにグリッドを表示してください
plt.grid(True)

# positionsとlabelsを設定します
positions = [0, np.pi/2, np.pi, np.pi*3/2, np.pi*2]
labels = ["0°", "90°", "180°", "270°", "360°"]
# グラフのx軸に目盛りを設定してください
plt.xticks(positions, labels)

# y軸の表示範囲を[0,1]に指定してください
plt.ylim([0, 1])

# データx,yをグラフにプロットし、表示します
plt.plot(x, y)
plt.show()
