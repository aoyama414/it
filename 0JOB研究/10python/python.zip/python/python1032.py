# ○10.3.2 timedelta型

import datetime as dt

# 1時間半を表すtimedeltaオブジェクトを作成し、xに代入してください
x = dt.timedelta(hours=1, minutes=30)

# 出力します
print(x)
