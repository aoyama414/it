import numpy as np
import pandas as pd
import math

np.random.seed(0)
columns = ["apple", "orange", "banana", "strawberry", "kiwifruit"]

# DataFrameを生成し、列を追加します
df = pd.DataFrame()
for column in columns:
    df[column] = np.random.choice(range(1, 11), 10)
df.index = range(1, 11)

# dfの各要素を2倍し、double_dfに代入してください
double_df = df * 2  # double_df = df + dfもOK

# dfの各要素を2乗し、square_dfに代入してください
square_df = df * df  # square_df = df**2 でもOK

# dfの各要素の平方根を計算し、sqrt_dfに代入してください
sqrt_df = np.sqrt(df)


# 出力します
print(df)
print()
print(double_df)
print()
print(square_df)
print()
print(sqrt_df)
