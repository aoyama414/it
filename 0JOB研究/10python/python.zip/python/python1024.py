# 10.2.4 リストからランダムに選択する

import numpy as np

x = ['Apple', 'Orange', 'Banana', 'Pineapple', 'Kiwifruit', 'Strawberry']

# シードを設定します
np.random.seed(0)
# xの中からランダムに5個選んでyに代入してください
y = np.random.choice(x, 5)

print(y)
