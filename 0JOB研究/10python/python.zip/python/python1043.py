# ○10.4.3 等間隔の数列を生成する②

import numpy as np

# 0から10までの範囲を等間隔にわける5点をxに代入してください
x = np.linspace(0, 10, 5)

# 出力します
print(x)
