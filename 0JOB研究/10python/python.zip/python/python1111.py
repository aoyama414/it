# 11.1.1 グラフにデータをプロットする

# matplotlib.pyplotをpltとしてimportしてください
import matplotlib.pyplot as plt
import numpy as np

# np.pi は円周率を表します
x = np.linspace(0, 2*np.pi)
y = np.sin(x)

# データx,yをグラフにプロットし、表示してください
plt.plot(x,y)

plt.show()
