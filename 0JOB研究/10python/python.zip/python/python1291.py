# ●添削問題

import matplotlib.pyplot as plt
import pandas as pd
# irisデータを取得します
df_iris = pd.read_csv(
    "http://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data", header=None)
df_iris.columns = ["sepal length", "sepal width",
                   "petal length", "petal width", "class"]

fig = plt.figure(figsize=(10, 10))
# setosa の sepal length - sepal width の関係図を描いてください
# ラベルをsetosa、色はblackを指定してください
plt.scatter(df_iris.iloc[:50, 0], df_iris.iloc[:50, 1],
            label="setosa", color="k")
# versicolor の sepal length - sepal width の関係図を描いてください
# ラベルをversicolor、色はblueを指定してください
plt.scatter(df_iris.iloc[50:100, 0],
            df_iris.iloc[50:100, 1], label="versicolor", color="b")
# virginica の sepal length - sepal width の関係図を描いてください
# ラベルをvirginica、色はgreenを指定してください。
plt.scatter(df_iris.iloc[100:150, 0],
            df_iris.iloc[100:150, 1], label="virginica", color="g")
# x軸名を sepal length にしてください
plt.xlabel("sepal length")
# y軸名を sepal width にしてください
plt.ylabel("sepal width")
# 図を表示します
plt.legend(loc="best")
plt.grid(True)
plt.savefig('1291.png')
plt.show()
