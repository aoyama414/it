# ●添削問題

# if とlamdaを用いて計算してください（引数aが8未満ならば、5倍にし、8以上ならば2で割る）
from collections import Counter
from collections import defaultdict
import re
a = 8
def basic(x): return x * 5 if x < 8 else x / 2


print('計算結果')
print(basic(a))


# 配列time_list
time_list = [
    "2018/1/23_19:40",
    "2016/5/7_5:25",
    "2018/8/21_10:50",
    "2017/8/9_7:5",
    "2015/4/1_22:15"
]
# 文字列から"月"を取り出す関数を作成してください
def get_month(x): return int(re.split("[/_:]", x)[1])


# 各要素の"月"を取り出して配列にしてください
month_list = list(map(get_month, time_list))

# 出力してください
print()
print('月')
print(month_list)

# リスト内包表記を用いて体積を計算してください
length = [3, 1, 6, 2, 8, 2, 9]
side = [4, 1, 15, 18, 7, 2, 19]
height = [10, 15, 17, 13, 11, 19, 18]

# 体積を計算してください
volume = [x * y * z for x, y, z in zip(length, side, height)]

# 出力してください
print()
print('体積')
print(volume)

# 各valueの平均値の計算とpriceリストの中のフルーツ名を数え上げてください

# まとめたいデータprice
price = [
    ("strawberry", 520),
    ("pear", 200),
    ("peach", 400),
    ("apple", 170),
    ("lemon", 150),
    ("grape", 1000),
    ("strawberry", 750),
    ("pear", 400),
    ("peach", 500),
    ("strawberry", 70),
    ("lemon", 300),
    ("strawberry", 700)
]
# defaultdictを定義してください
d = defaultdict(list)

# 上記の例と同様にvalueに値段とkeyにフルーツ名を追加してください
price_key_count = []
for key, value in price:
    d[key].append(value)
    price_key_count.append(key)

# 各valueの平均値を計算し、配列にして出力してください
print()
print('valueの平均値')
print([sum(x) / len(x) for x in d.values()])

# 上記のpriceリストの中のフルーツ名を数え上げてください
key_count = Counter(price_key_count)
print()
print('フルーツ名')
print(key_count)
