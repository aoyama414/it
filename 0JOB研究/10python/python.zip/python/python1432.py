# ○14.3.2 欠損値の補完

import numpy as np
from numpy import nan as NA
import pandas as pd
np.random.seed(0)

sample_data_frame = pd.DataFrame(np.random.rand(10, 4))

sample_data_frame.iloc[1, 0] = NA
sample_data_frame.iloc[6:, 2] = NA

# ここに解答を記述してください
# ffill:前の値で埋める
sample_data_frame2 = sample_data_frame.fillna(method="ffill")

print(sample_data_frame)
print()
print(sample_data_frame2)
print('********************')
# ●14.3.3 欠損値の補完（平均値代入法）
np.random.seed(0)

sample_data_frame = pd.DataFrame(np.random.rand(10, 4))

sample_data_frame.iloc[1, 0] = NA
sample_data_frame.iloc[6:, 2] = NA

# ここに解答を記述してください
sample_data_frame2 = sample_data_frame.fillna(sample_data_frame.mean())
print(sample_data_frame)
print()
print(sample_data_frame2)
