# 11.3.1 図の大きさを設定する


import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 2*np.pi)
y = np.sin(x)

# 図の大きさを設定してください(インチ単位)
plt.figure(figsize=(4, 4))

# データx,yをグラフにプロットし、表示します
plt.plot(x, y)
plt.show()
