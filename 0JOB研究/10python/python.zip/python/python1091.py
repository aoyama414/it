# ●添削問題

import matplotlib.pyplot as plt
import numpy as np

np.random.seed(100)

# 一様乱数を10,000個生成して、random_number_1に代入してください
random_number_1 = np.random.rand(10000)
# 正規分布に従う乱数を10,000個生成して、random_number_2に代入してください
random_number_2 = np.random.randn(10000)
# 二項分布に従う乱数を10,000個生成して、random_number_3に代入してください。成功確率は0.5としてください
random_number_3 = np.random.binomial(100, 0.5, size=(10000))

plt.figure(figsize=(5, 5))
# 一様乱数をヒストグラムで表示させてください。binsは50に指定してください
plt.hist(random_number_1, bins=50)
plt.title('uniform_distribution')
plt.grid(True)
plt.show()

plt.figure(figsize=(5, 5))
# 正規分布に従う乱数をヒストグラムで表示させてください。bins は 50 に指定してください
plt.hist(random_number_2, bins=50)
plt.title('normal_distribution')
plt.grid(True)
plt.show()

plt.figure(figsize=(5, 5))
# 二項分布に従う乱数をヒストグラムで表示させてください。binsは50に指定してください
plt.hist(random_number_3, bins=50)
plt.title('binomial_distribution')
plt.grid(True)
plt.show()
