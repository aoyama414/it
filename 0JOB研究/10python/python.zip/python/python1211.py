# 〇12.1.1 マーカーの種類と色を設定する
# 〇12.1.2 線のスタイルと色を設定する


import numpy as np
import matplotlib.pyplot as plt

days = np.arange(1, 11)
weight = np.array([10, 14, 18, 20, 18, 16, 17, 18, 20, 17])
# 表示を設定します
plt.ylim([0, weight.max()+1])
plt.xlabel("days")
plt.ylabel("weight")

# 円マーカーを赤色でプロットし、青の破線の折れ線グラフを作成してください
plt.plot(days, weight, linestyle="--", color="b",
         marker="o", markerfacecolor="k")

plt.show()
