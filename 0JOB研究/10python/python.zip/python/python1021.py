import numpy as np

# 初期化せず適当な乱数が一致するかを確認します
# X,Yにそれぞれ5つの乱数を格納します
X = np.random.randn(5)
Y = np.random.randn(5)
# X,Yの値を出力します
print("シードを設定しない場合")
print("X:", X)
print("Y:", Y)

# シードを設定してください
np.random.seed(0)
# 乱数列を変数に代入します
x = np.random.randn(5)
# 同じシードを与えて初期化してください
np.random.seed(0)
# 再び乱数列を作り別の変数に代入します
y = np.random.randn(5)
# x,yの値を出力し、一致するか確認します
print("シードを設定した場合")
print("x:", x)
print("y:", y)
# 何も書き込まずに出力してください
