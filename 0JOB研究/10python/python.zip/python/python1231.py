# ○12.3.1 ヒストグラムを作成する
# ○12.3.2 ビン数を設定する
# ○12.3.3 正規化を行う
# ○12.3.4 累積ヒストグラムを作成する

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(0)
data = np.random.randn(10000)

# dataを用いてヒストグラムを作成してください
# ビン数100のヒストグラムを作成してください bins=100
# 正規化されたビン数100のヒストグラムを作成してください density=True
# 正規化されたビン数100の累積ヒストグラムを作成してください cumulative=True
plt.hist(data, bins=100, density=True, cumulative=True)

plt.show()
