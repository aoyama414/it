import pandas as pd

df = pd.read_csv('NewMeikaiPython/python/data/sample_date.csv',
                 index_col=0,
                 parse_dates=True)

print(df)
print('*****週単位の集計*****')
print(df.resample('W').sum())
print('*****10日単位の集計*****')
print(df.resample('10D').sum())
print('*****3週間単位の集計*****')
print(df.resample('3W').sum())
