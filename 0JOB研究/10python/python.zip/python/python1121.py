# 11.2.1 1つのグラフに2種類のデータをプロットする
# 11.2.2 系列ラベルを設定する

import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0, 2*np.pi)
y1 = np.sin(x)
y2 = np.cos(x)
labels = ["90°", "180°", "270°", "360°"]
positions = [np.pi/2, np.pi, np.pi*3/2, np.pi*2]
# グラフのタイトルを設定します
plt.title("graphs of trigonometric functions")
# グラフのx軸とy軸に名前を設定します
plt.xlabel("x-axis")
plt.ylabel("y-axis")
# グラフにグリッドを表示します
plt.grid(True)
# グラフのx軸にラベルを設定します
plt.xticks(positions, labels)
# データx, y1をグラフにプロットし、黒で表示してください
plt.plot(x, y1, color="k")

# データx, y2をグラフにプロットし、青で表示してください
plt.plot(x, y2, color="b")

# データx, y1をグラフにプロットし、"y=sin(x)"とラベルを付けて黒で表示してください
plt.plot(x, y1, color="k", label="y=sin(x)")
# データx, y2をグラフにプロットし、"y=cos(x)"とラベルを付けて青で表示してください
plt.plot(x, y2, color="b", label="y=cos(x)")
# 系列ラベルを設定してください
plt.legend(["y=sin(x)", "y=cos(x)"])


plt.show()
