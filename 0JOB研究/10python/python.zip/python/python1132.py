# 11.3.2 サブプロットを作成する
# 11.3.3 サブプロットのまわりの余白を調整する
# 11.3.4 サブプロット内のグラフの表示範囲を設定する
# 11.3.5 サブプロット内のグラフの要素に名前を設定する
# 11.3.6 サブプロット内のグラフにグリッドを表示する
# 11.3.7 サブプロット内のグラフの軸に目盛りを設定する

import matplotlib.pyplot as plt
import numpy as np


x = np.linspace(0, 2*np.pi)
y = np.sin(x)

positions = [0, np.pi/2, np.pi, np.pi*3/2, np.pi*2]
labels = ["0°", "90°", "180°", "270°", "360°"]

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(9, 6))
# 2×3のレイアウトの上から2行目、左から2列目にサブプロットオブジェクトを作ってください
ax = fig.add_subplot(2, 3, 5)

# 図内のサブプロット間を、縦横ともに1の割合で空けてください
plt.subplots_adjust(wspace=1, hspace=1)

# サブプロットaxのグラフにグリッドを設定してください
ax.grid(True)

# サブプロットaxのグラフのy軸の表示範囲を[0,1]に設定してください
ax.set_ylim([0, 1])

# サブプロットaxのグラフのタイトルを設定してください
ax.set_title("y=sin(x)")

# サブプロットaxのグラフのx軸、y軸に名前を設定してください
ax.set_xlabel("x-axis")
ax.set_ylabel("y-axis")

# サブプロットaxのグラフのx軸に目盛りを設定してください
ax.set_xticks(positions)
ax.set_xticklabels(labels)

# データx,yをグラフにプロットし、表示します
ax.plot(x, y)

# グラフがどこに追加されるか確認するため空白部分をサブプロットで埋めます
axi = []
for i in range(6):
    if i == 4:
        continue
    fig.add_subplot(2, 3, i+1)
plt.show()
