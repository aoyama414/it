# ○10.3.4 時を表す文字列からdatetimeオブジェクトを作成する

import datetime as dt

# sに1992年10月22日を表す文字列を"年-月-日"の形式でsに代入してください
s = "1992-10-22"
# sを変換して、1992年10月22日を表すdatetimeオブジェクトをxに代入してください
x = dt.datetime.strptime(s, "%Y-%m-%d")

# 出力します
print(x)
