# 〇12.2.1 棒グラフを作成する
# 〇12.2.2 横軸にラベルを設定する
# 〇12.2.3 積み上げ棒グラフを作成する

import numpy as np
import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5, 6]
y1 = [12, 41, 32, 36, 21, 17]
y2 = [43, 1, 6, 17, 17, 9]

labels = ["Apple", "Orange", "Banana", "Pineapple", "Kiwifruit", "Strawberry"]

# 積み上げ棒グラフを作成し、横軸にラベルを設定してください
plt.bar(x, y1, tick_label=labels)
plt.bar(x, y2, bottom=y1)

# このように系統ラベルを設定することもできます
plt.legend(("y1", "y2"))

plt.show()
