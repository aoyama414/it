# ○12.6.1 3D Axesを作成する

import numpy as np
import matplotlib.pyplot as plt
# # カラーマップを表示するためのライブラリです
# import matplotlib.cm as cm
# 3D描画を行うために必要なライブラリです
from mpl_toolkits.mplot3d import Axes3D


t = np.linspace(-2*np.pi, 2*np.pi)
X, Y = np.meshgrid(t, t)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(6, 6))
# サブプロットaxを作成してください
ax = fig.add_subplot(1, 1, 1, projection="3d")

# プロットして表示します
ax.plot_surface(X, Y, Z)
plt.savefig('1261.png')
# plt.show()

# ○12.6.2 曲面を作成する

x = y = np.linspace(-5, 5)
X, Y = np.meshgrid(x, y)
Z = np.exp(-(X**2 + Y**2)/2) / (2*np.pi)

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(6, 6))
# サブプロットaxを作成します
ax = fig.add_subplot(1, 1, 1, projection="3d")
# 曲面を描画して表示してください
ax.plot_surface(X, Y, Z)
plt.savefig('1262.png')
# plt.show()

# ○12.6.3 3Dヒストグラムを作成する
# Figureオブジェクトを作成します
fig = plt.figure(figsize=(5, 5))
# サブプロットax1を作成します
ax = fig.add_subplot(111, projection="3d")
# x, y, zの位置を決めます
xpos = [i for i in range(10)]
ypos = [i for i in range(10)]
zpos = np.zeros(10)
# x, y, zの増加量を決めます
dx = np.ones(10)
dy = np.ones(10)
dz = [i for i in range(10)]

# 3次元のヒストグラムを作成してください
ax.bar3d(xpos, ypos, zpos, dx, dy, dz)
plt.savefig('1263.png')
# plt.show()

# ○12.6.4 3D散布図を作成する
np.random.seed(0)

X = np.random.randn(1000)
Y = np.random.randn(1000)
Z = np.random.randn(1000)

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(6, 6))
# サブプロットaxを作成します
ax = fig.add_subplot(1, 1, 1, projection="3d")
# X,Y,Zを1次元に変換します
x = np.ravel(X)
y = np.ravel(Y)
z = np.ravel(Z)
# 3D散布図を作成してください
ax.scatter3D(x, y, z)

plt.savefig('1264.png')
# plt.show()

# ○12.6.5 3Dグラフにカラーマップを適用する
t = np.linspace(-2*np.pi, 2*np.pi)
X, Y = np.meshgrid(t, t)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(6, 6))
# サブプロットaxを作成します
ax = fig.add_subplot(1, 1, 1, projection="3d")
# 以下を一部変更して、zの値についてカラーマップを適用してください
cm = plt.cm.get_cmap('RdYlBu')
ax.plot_surface(X, Y, Z, cmap=cm)

plt.savefig('1265.png')
# plt.show()
