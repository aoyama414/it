# ○10.3.1 datetime型

import datetime as dt

# 1992年10月22日を表すdatetimeオブジェクトを作成してxに代入してください
x = dt.datetime(1992, 10, 22)

# 出力します
print(x)
