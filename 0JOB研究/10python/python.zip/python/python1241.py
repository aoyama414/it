# 〇12.4.1 散布図を作成する
# ○12.4.2 マーカーの種類と色を設定する
# ○12.4.3 値に応じてマーカーの大きさを設定する
# ○12.4.4 値に応じてマーカーの濃さを設定する
# ○12.4.5 カラーバーを表示する

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(0)
# x = np.random.choice(np.arange(100), 100)
# y = np.random.choice(np.arange(100), 100)

# # 散布図を作成してください
# #plt.scatter(x, y)
# # マーカーの種類を四角、色を黒に設定して散布図を作成してください
# plt.scatter(x, y, marker="s", color="k")

x = np.random.choice(np.arange(100), 100)
y = np.random.choice(np.arange(100), 100)
z = np.random.choice(np.arange(100), 100)

# # zの値に応じて、マーカーの大きさが変わるようにプロットしてください
# plt.scatter(x, y, s=z)

# zの値に応じて、マーカーの濃さが青系統で変わるようにプロットしてください
plt.scatter(x, y, c=z, cmap="Blues")

# カラーバーを表示してください
plt.colorbar()

plt.show()
