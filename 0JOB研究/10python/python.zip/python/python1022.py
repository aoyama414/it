import numpy as np
import matplotlib.pyplot as plt

# シードの値を0に設定してください
np.random.seed(0)
# 正規分布に従う乱数を10,000個生成し、xに代入してください
x = np.random.randn(10000)

# 可視化します
plt.hist(x, bins='auto')
plt.show()
