# ○14.4.1 キーごとの統計量の算出

import pandas as pd
from pandas import DataFrame

df = pd.read_csv(
    "http://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data", header=None)
df.columns = ["", "Alcohol", "Malic acid", "Ash", "Alcalinity of ash", "Magnesium", "Total phenols", "Flavanoids",
              "Nonflavanoid phenols", "Proanthocyanins", "Color intensity", "Hue", "OD280/OD315 of diluted wines", "Proline"]

# ここに解答を記述してください
print(df["Magnesium"].mean())

# 14.4.2 重複データ
print('*****14.4.2*****')

dupli_data = DataFrame({"col1": [1, 1, 2, 3, 4, 4, 6,
                                 6, 7, 7, 7, 8, 9, 9],
                        "col2": ["a", "b", "b", "b", "c",
                                 "c", "b", "b", "d", "d",
                                 "c", "b", "c", "c"]})

# ここに解答を記述してください
dupli_data2 = dupli_data.drop_duplicates()

print(dupli_data)
print()
print(dupli_data2)

# 14.4.3 マッピング
print('*****14.4.3*****')
attri_data1 = {"ID": ["100", "101", "102", "103", "104",
                      "106", "108", "110", "111", "113"],
               "city": ["Tokyo", "Osaka", "Kyoto", "Hokkaido",
                        "Tokyo", "Tokyo", "Osaka", "Kyoto",
                        "Hokkaido", "Tokyo"],
               "birth_year": [1990, 1989, 1992, 1997, 1982,
                              1991, 1988, 1990, 1995, 1981],
               "name": ["Hiroshi", "Akiko", "Yuki", "Satoru",
                        "Steeve", "Mituru", "Aoi", "Tarou",
                        "Suguru", "Mitsuo"]}
attri_data_frame1 = DataFrame(attri_data1)

# ここに解答を記述してください
WE_map = {"Tokyo": "east", "Hokkaido": "east",
          "Osaka": "west", "Kyoto": "west"}

attri_data_frame1["WE"] = attri_data_frame1["city"].map(WE_map)

print(attri_data_frame1)

# 14.4.4 ビン分割
print('*****14.4.4*****')
attri_data1 = {"ID": [100, 101, 102, 103, 104, 106, 108, 110, 111, 113],
               "city": ["Tokyo", "Osaka", "Kyoto", "Hokkaido", "Tokyo", "Tokyo", "Osaka", "Kyoto", "Hokkaido", "Tokyo"],
               "birth_year": [1990, 1989, 1992, 1997, 1982, 1991, 1988, 1990, 1995, 1981],
               "name": ["Hiroshi", "Akiko", "Yuki", "Satoru", "Steeve", "Mituru", "Aoi", "Tarou", "Suguru", "Mitsuo"]}
attri_data_frame1 = DataFrame(attri_data1)

# ここに解答を記述してください
# IDを2個に分割
attri_data_frame2 = pd.cut(attri_data_frame1.ID, 2)
print(attri_data_frame1)
print()
print(attri_data_frame2)
