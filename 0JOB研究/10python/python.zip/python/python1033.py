# ○10.3.3 datetime型とtimedelta型の演算

import datetime as dt


# 1992年10月22日を表すdatetimeオブジェクトを作成してxに代入してください
x = dt.datetime(1992, 10, 22)

# xから1日後を表すdatetimeオブジェクトをyに代入してください
y = x + dt.timedelta(1)

# 出力します
print(y)
