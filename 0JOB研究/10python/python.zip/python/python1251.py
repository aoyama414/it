# ○12.5.1 円グラフを作成する
# ○12.5.2 円グラフにラベルを設定する
# ○12.5.3 特定の要素を目立たせる

import matplotlib.pyplot as plt


data = [60, 20, 10, 5, 3, 2]
labels = ["Apple", "Orange", "Banana", "Pineapple", "Kiwifruit", "Strawberry"]
explode = [0, 0, 0.1, 0, 0, 0]

# # dataを円グラフとして可視化してください
# plt.pie(data)

# # dataにlabelsのラベルをつけ円グラフ可視化してください
# plt.pie(data, labels=labels)

# dataにlabelsのラベルを付けて、Bananaを目立たせた円グラフで可視化してください
plt.pie(data, labels=labels, explode=explode)

# 円グラフを円楕円から真円にしてください
plt.axis("equal")

plt.show()
