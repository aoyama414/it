# ○14.3.1 リストワイズ/ペアワイズ削除

import pandas as pd
from numpy import nan as NA
import numpy as np
np.random.seed(0)

sample_data_frame = pd.DataFrame(np.random.rand(10, 4))

sample_data_frame.iloc[1, 0] = NA
sample_data_frame.iloc[2, 2] = NA
sample_data_frame.iloc[5:, 3] = NA

print(sample_data_frame)
print()
# ここに解答を記述してください
sample_data_frame2 = sample_data_frame[[0, 2]].dropna()
print(sample_data_frame2)
