# 添削問題

import matplotlib.pyplot as plt
import numpy as np

x_upper = np.linspace(0, 5)
x_lower = np.linspace(0, 2 * np.pi)
x_tan = np.linspace(-np.pi / 2, np.pi / 2)
positions_upper = [i for i in range(5)]
positions_lower = [0, np.pi / 2, np.pi, np.pi * 3 / 2, np.pi * 2]
positions_tan = [-np.pi / 2, 0, np.pi / 2]
labels_upper = [i for i in range(5)]
labels_lower = ["0°", "90°", "180°", "270°", "360°"]
labels_tan = ["-90°", "0°", "90°"]

# Figureオブジェクトを作成します
fig = plt.figure(figsize=(9, 6))

# 3×2のレイアウトをもつ複数の関数のグラフをプロットしてください
# サブプロット同士が重ならないように設定します
plt.subplots_adjust(wspace=0.4, hspace=0.4)

# 上段のサブプロットを作成します
for i in range(3):
    y_upper = x_upper ** (i + 1)
    ax = fig.add_subplot(2, 3, i + 1)
    # サブプロットaxのグラフにグリッドを表示します
    ax.grid(True)
    # サブプロットaxのグラフのタイトルを設定します
    ax.set_title("$y=x^%i$" % (i + 1))
    # サブプロットaxのグラフのx軸、y軸に名前を設定します
    ax.set_xlabel("x-axis")
    ax.set_ylabel("y-axis")
    # サブプロットaxのグラフのx軸にラベルを設定します
    ax.set_xticks(positions_upper)
    ax.set_xticklabels(labels_upper)
    # データx,yをグラフにプロットし、表示します
    ax.plot(x_upper, y_upper)

# 下段のサブプロットを作成します
# あらかじめリストに使う関数とタイトルを入れておくことでfor文による処理を可能にします
y_lower_list = [np.sin(x_lower), np.cos(x_lower)]
title_list = ["$y=sin(x)$", "$y=cos(x)$"]
for i in range(2):
    y_lower = y_lower_list[i]
    ax = fig.add_subplot(2, 3, i + 4)
    # サブプロットaxのグラフにグリッドを表示します
    ax.grid(True)
    # サブプロットaxのグラフのタイトルを設定します
    ax.set_title(title_list[i])
    # サブプロットaxのグラフのx軸、y軸に名前を設定します
    ax.set_xlabel("x-axis")
    ax.set_ylabel("y-axis")
    # サブプロットaxのグラフのx軸にラベルを設定します
    ax.set_xticks(positions_lower)
    ax.set_xticklabels(labels_lower)
    # データx,yをグラフにプロットし、表示します
    ax.plot(x_lower, y_lower)

# y=tan(x)のグラフのプロットします
ax = fig.add_subplot(2, 3, 6)
# サブプロットaxのグラフにグリッドを表示します
ax.grid(True)
# サブプロットaxのグラフのタイトルを設定します
ax.set_title("$y=tan(x)$")
# サブプロットaxのグラフのx軸、y軸に名前を設定します
ax.set_xlabel("x-axis")
ax.set_ylabel("y-axis")
# サブプロットaxのグラフのx軸にラベルを設定します
ax.set_xticks(positions_tan)
ax.set_xticklabels(labels_tan)
# サブプロットaxのグラフのyの範囲を設定します
ax.set_ylim(-1, 1)
# データx,yをグラフにプロットし、表示します
ax.plot(x_tan, np.tan(x_tan))

plt.show()
