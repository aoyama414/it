import pandas as pd
import numpy as np

print('DataFrameの値を置換する')
print('************')

print()
print('replace 値を置換する')

df = pd.DataFrame([['apple', 10], ['oranggg', 20], ['banana', 30]],
                  columns=['name', 'price'])
print(df.replace('oranggg', 'orange'))

#      name  price
# 0   apple     10
# 1  orange     20
# 2  banana     30

print()
print('正規表現による置換')

print(df.replace('.*ggg.*', 'orange', regex=True))

#      name  price
# 0   apple     10
# 1  orange     20
# 2  banana     30
#

print()
print('欠損値の0埋め')
df = pd.DataFrame([[1, 10], [None, 20], [3, None]],
                  columns=['col1', 'col2'])
print(df.replace(np.NaN, 0))
#    col1  col2
# 0   1.0  10.0
# 1   0.0  20.0
# 2   3.0   0.0
