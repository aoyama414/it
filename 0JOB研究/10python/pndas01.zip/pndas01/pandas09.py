import pandas as pd

print('DataFrameの更新系処理')
print('************')
print('Seriesを列として追加')

# DataFrameとSeries生成
df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]], columns=[
                  'col1', 'col2'], index=['a', 'b', 'c', 'd'])
s = pd.Series([1, 1, 1, 1], index=['a', 'b', 'c', 'd'])

# DataFrameにSeriesを新たな列をして追加
df['new_col'] = s
print(df)
#    col1  col2  new_col
# a     1    10        1
# b     2    20        1
# c     3    30        1
# d     4    40        1

# DataFrameの既存列を更新する
df['col1'] = s
print(df)
#    col1  col2  new_col
# a     1    10        1
# b     1    20        1
# c     1    30        1
# d     1    40        1

print('************')
print('行を追加')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'],
                  index=['a', 'b', 'c', 'd'])
df2 = pd.DataFrame([[9, 99]],
                   columns=['col1', 'col2'],
                   index=['x'])
print(df.append(df2))
print(df)  # 元のデータには追加されない
#    col1  col2
# a     1    10
# b     2    20
# c     3    30
# d     4    40
# x     9    99

print('************')
print('行の削除：元のデータは更新されない')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'],
                  index=['a', 'b', 'c', 'd'])

# 単一行を削除
print(df.drop('a'))
#    col1  col2
# b     2    20
# c     3    30
# d     4    40

# 複数行を削除
print()
print(df.drop(['a', 'b']))
#    col1  col2
# c     3    30
# d     4    40

print()
print(df)

print('************')
print('列の削除：元のデータは更新されない')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]], columns=[
                  'col1', 'col2'], index=['a', 'b', 'c', 'd'])
print(df.drop('col1', axis=1))
#   col2
# a    10
# b    20
# c    30
# d    40

print()
print(df)

print('************')
print('要素の更新')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'],
                  index=['a', 'b', 'c', 'd'])
df.at['a', 'col1'] = 999
print(df)

#    col1  col2
# a   999    10
# b     2    20
# c     3    30
# d     4    40
#
