import pandas as pd

print('column(列名) index(行名)の変更')
print('************')
print('DataFrame.rename column、indexをリネームする')

# DataFrameを生成する
df = pd.DataFrame([[1, 10], [2, 20]], columns=[
                  'col1', 'col2'], index=['a', 'b'])
print(df)
#    col1  col2
# a     1    10
# b     2    20

# 列名を変更する
print()
print('列名を変更する')
new_df = df.rename(columns={'col1': 'new1', 'col2': 'new2'})
print(new_df)
#    new1  new2
# a     1    10
# b     2    20

# 行名を変更する
print()
print('行名を変更する')
new_df = df.rename(index={'a': 'new1', 'b': 'new2'})
print(new_df)
#       col1  col2
# new1     1    10
# new2     2    20

# 破壊的に変更する
print()
print('破壊的に変更する')
df.rename(columns={'col1': 'new1', 'col2': 'new2'}, inplace=True)
print(df)
#    new1  new2
# a     1    10
# b     2    20
