import pandas as pd

print('DataFrameをgroupbyで集計する')
print('************')

df = pd.DataFrame([['cate1', 'tag1', 150],
                   ['cate1', 'tag2', 210],
                   ['cate2', 'tag2', 80],
                   ['cate2', 'tag1', 310], ],
                  columns=['category', 'tag', 'value'])
print(df)
#   category   tag  value
# 0    cate1  tag1    150
# 1    cate1  tag2    210
# 2    cate2  tag2     80
# 3    cate2  tag1    310

# categoryごとの合計を算出する
print()
print('categoryごとの合計を算出する')
print(df.groupby('category').sum())

#           value
# category
# cate1       360
# cate2       390

# category、tagごとの件数を算出する
print()
print('category、tagごとの件数を算出する')
print(df.groupby(['category', 'tag']).count())
#                value
# category tag
# cate1    tag1      1
#          tag2      1
# cate2    tag1      1
#          tag2      1

# tagごとのばらつきを算出する
print()
print('tagごとのばらつきを算出する')
print(df.groupby(['tag']).std())

#            value
# tag
# tag1  113.137085
# tag2   91.923882
