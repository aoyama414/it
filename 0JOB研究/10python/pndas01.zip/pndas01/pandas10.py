import pandas as pd

print('DataFrameのループ処理')
print('************')
print('iterrows 1行ずつ処理する')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'])

for index, row in df.iterrows():
    print(row['col1'], row['col2'])

# 1 10
# 2 20
# 3 30
# 4 40

print('************')
print('iteritems 一列ずつ処理する')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'])

print(df)
#    col1  col2
# 0     1    10
# 1     2    20
# 2     3    30
# 3     4    40

for index, col in df.iteritems():
    print(sum(col))

# 10
# 100
