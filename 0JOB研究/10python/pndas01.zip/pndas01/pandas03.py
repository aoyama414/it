import pandas as pd

print('DataFrameの生成の基本')
print('************')
print('index、columnを指定しないで生成する')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30]])
print(df)
print('************')
print('index、columnを指定する')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  index=['a', 'b', 'c', 'd'],
                  columns=['col1', 'col2'])
print(df)
#    col1  col2
# a     1    10
# b     2    20
# c     3    30
# d     4    40

print('************')
print('辞書から生成する')
data = {'col1': [1, 2, 3], 'col2': [10, 20, 30]}
df = pd.DataFrame(data)
print(df)

#    col1  col2
# 0     1    10
# 1     2    20
# 2     3    30

print('************')
print('SeriesからDataFrameを生成')
s1 = pd.Series([100, 101, 102], index=['a', 'b', 'c'])
s2 = pd.Series([100, 101, 102], index=['b', 'c', 'd'])
df = pd.DataFrame({'col1': s1, 'col2': s2})
print(df)

#     col1   col2
# a  100.0    NaN
# b  101.0  100.0
# c  102.0  101.0
# d    NaN  102.0
