import pandas as pd

print('DataFrameのフィルタリング')
print('************')


df = pd.DataFrame([['A', 10], ['B', 20], ['C', 30], [
                  'D', 40]], columns=['col1', 'col2'])
print(df)
#   col1  col2
# 0    A    10
# 1    B    20
# 2    C    30
# 3    D    40

print()
print('完全一致するものを抜き出す')
print(df[df.col1 == 'C'])

#   col1  col2
# 2    C    30

print()
print('大なり小なりでフィルタ')

print(df[df.col2 > 10])

#   col1  col2
# 1    B    20
# 2    C    30
# 3    D    40

print()
print('正規表現でフィルタ')

cond = df.col1.str.contains('.*A')

print(cond)
# 0     True
# 1    False
# 2    False
# 3    False
# Name: col1, dtype: bool

print(df[cond])

#   col1  col2
# 0    A    10
