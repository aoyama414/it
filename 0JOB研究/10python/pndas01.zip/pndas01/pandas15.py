import pandas as pd
import numpy as np

print('ピボットテーブル')
print('************')

df = pd.DataFrame([['cate1', 'tag1', 4],
                   ['cate2', 'tag1', 10],
                   ['cate1', 'tag2', 5],
                   ['cate3', 'tag3', 5],
                   ['cate2', 'tag3', 5]],
                  columns=['category', 'tag', 'value'])
print(df)
# categoryとtagと値
#   category   tag  value
# 0    cate1  tag1      4
# 1    cate2  tag1     10
# 2    cate1  tag2      5
# 3    cate3  tag3      5
# 4    cate2  tag3      5

# 合計をクロス集計する
df2 = df.pivot_table(index=['category'], columns=['tag'],
                     values='value', fill_value=0, aggfunc=lambda x: sum(x))
print()
print(df2)

# tag       tag1  tag2  tag3
# category
# cate1        4     5     0
# cate2       10     0     5
# cate3        0     0     5
#

# index：縦の集計項目を指定します。複数指定することができます。
# columns：縦の集計項目を指定します。複数指定することができます。
# values：集計対象の値の項目を指定します。
# fill_value：NaNを何で埋めるかです。サンプルでは0埋めしています。
# aggfunc：集計関数を指定します。

# 個数
print()
print('個数')
print(df.pivot_table(index=['category'],
                     columns=['tag'],
                     values='value',
                     fill_value=0,
                     aggfunc=lambda x: len(x)))

# 平均
print()
print('平均')
print(df.pivot_table(index=['category'],
                     columns=['tag'],
                     values='value',
                     fill_value=0,
                     aggfunc=lambda x: np.average(x)))

# 標準偏差
print()
print('標準偏差')
print(df.pivot_table(index=['category'],
                     columns=['tag'],
                     values='value',
                     fill_value=0,
                     aggfunc=lambda x: np.std(x)))
