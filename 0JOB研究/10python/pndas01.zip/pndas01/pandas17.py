import pandas as pd
import numpy as np

print('DataFrame htmlで入出力')
print('************')

dfs = pd.read_html('https://www.data.jma.go.jp/obd/stats/etrn/view/rankall.php?prec_no=&block_no=&year=2017&month=&day=&view=',
                   header=0)
df = dfs[0]
print(df)


