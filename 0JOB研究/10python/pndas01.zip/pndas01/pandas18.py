from bs4 import BeautifulSoup

print('htmlをパース、スクレイピング')
print('************')
print('基本')
html = "<body><h1>python入門</h1><p>pythonの基礎について学習します</p></body>"
soup = BeautifulSoup(html, "html5lib")
print(soup.h1)

print()
print('Tagオブジェクト')
html = open('index.html', 'r').read()
soup = BeautifulSoup(html, "html.parser")

# 最初のh1タグ取得
h1 = soup.h1
print(h1)  # <h1 class="one">H1_String</h1>

# h1タグの属性を取得
print(h1.attrs)  # {'class': ['one']}

# h1タグのclassを取得
print(h1['class'])  # ['one']

# h1タグのタグ名を取得
print(h1.name)  # h1

# 最初のpタグ取得
print(soup.p)  # <p>おすすめ商品</p>

# divタグの次のpタグ取得
print(soup.div.p)  # <p>とってもキュートな商品。</p>

# divタグの次のpタグの内部テキストを取得
print(soup.div.p.string)  # とってもキュートな商品。

# タグを指定する
print(soup.find_all("h1"))
chapter3 = soup.find_all("h1")[0].text
print(chapter3)
