import pandas as pd
import numpy as np

print('DataFrameの行列を入れ替える')
print('************')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'],
                  index=['a', 'b', 'c', 'd'])
print(df)
print()
print(df.T)

#        a   b   c   d
# col1   1   2   3   4
# col2  10  20  30  40
