import pandas as pd

print('whereによるフィルタリング')
print('************')
print('DataFrameのwhere')

print('同じサイズで抽出')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'])

# 添字でフィルタ条件指定
print(df[df['col1'] > 2])

#    col1  col2
# 2     3    30
# 3     4    40


# whereを使用

print(df.where(df['col1'] > 2))
#    col1  col2
# 0   NaN   NaN
# 1   NaN   NaN
# 2   3.0  30.0
# 3   4.0  40.0

print()
print('NaN以外で値を埋める')

print(df.where(df['col1'] > 2, 0))

#    col1  col2
# 0     0     0
# 1     0     0
# 2     3    30
# 3     4    40
#

print()
print('セル毎にNaN以外で値を埋める')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'])

# col1は0、col2はハイフンのdataframeを定義
pad = pd.DataFrame([[0, '-']] * len(df),
                   columns=df.columns,
                   index=df.index)
print(pad)
#    col1 col2
# 0     0    -
# 1     0    -
# 2     0    -
# 3     0    -

print(df.where(df['col1'] > 2, pad))
#   col1 col2
# 0    0    -
# 1    0    -
# 2    3   30
# 3    4   40
