import pandas as pd
import math

print('欠損値（NaN）')

s = pd.Series([2, 5, 8, None])
print(s)
# 0    2.0
# 1    5.0
# 2    8.0
# 3    NaN
# dtype: float64

print('************')
print('dropna 欠損値NaNを除去する')
print()
print('Series 欠損値を除去する')
print(s.dropna())
# 0    2.0
# 1    5.0
# 2    8.0
# dtype: float64

print()
print('DataFrame 欠損値がある行を除去する')
df = pd.DataFrame([[1, None], [None, 20], [None, None], [4, 40]],
                  columns=['col1', 'col2'])
print(df)
#    col1  col2
# 0   1.0   NaN
# 1   NaN  20.0
# 2   NaN   NaN
# 3   4.0  40.0
print()
print('どれか1つでもNaNがあれば除去される')
print(df.dropna())
#    col1  col2
# 3   4.0  40.0

print()
print('col1でNaNがあるものが除去される。')
print(df.dropna(subset=['col1']))

# col1 col2
# 0 1.0 NaN
# 3 4.0 40.0


print()
print('DataFrame 欠損値がある列を除去する')
df = pd.DataFrame([[1, 10], [None, 20], [3, 30], [4, 40]],
                  columns=['col1', 'col2'])

print(df)
print()
print(df.dropna(axis=1))
# 0    10
# 1    20
# 2    30
# 3    40
