import pandas as pd

print('Seriesの演算')
print('************')
print('スカラー演算')
s = pd.Series([1, 2, 3, 4], index=['a', 'b', 'c', 'd'])
print(s)
# a    1
# b    2
# c    3
# d    4
# dtype: int64

# 足し算
print(s + 10)
# a    11
# b    12
# c    13
# d    14
# dtype: int64

# 引き算
print(s - 10)
# a   -9
# b   -8
# c   -7
# d   -6
# dtype: int64

# 掛け算
print(s * 1)
# a    1
# b    2
# c    3
# d    4
# dtype: int64

# 割り算
print(s / 2)
# a    0.5
# b    1.0
# c    1.5
# d    2.0
# dtype: float64
print('************')
print('Series同士の演算')
s1 = pd.Series([1, 2, 3, 4], index=['a', 'b', 'c', 'd'])
print(s1)
# a    1
# b    2
# c    3
# d    4
# dtype: int64

s2 = pd.Series([3, 4, 5, 6], index=['a', 'b', 'c', 'd'])
print(s1 + s2)
# a     4
# b     6
# c     8
# d    10
# dtype: int64
print('************')
print('Seriesの論理演算')
s = pd.Series([1, 2, 3, 4], index=['a', 'b', 'c', 'd'])
print(s > 2)
# a    False
# b    False
# c     True
# d     True
# dtype: bool
