import pandas as pd

print('DataFrame 基本統計量の算出')
print('************')
print('行数（レコード数）')
df = pd.DataFrame([[1, 10], [2, 20], [3, 30]], columns=['col1', 'col2'])
print(df)
#    col1  col2
# 0     1    10
# 1     2    20
# 2     3    30

print(len(df))
# 3
print('************')
print('要素数')
print(df.size)
# 6
print('************')
print('平均、最大最小、標準偏差、分散など')
print(df.count())  # 要素数
# col1    3
# col2    3
# dtype: int64

print(df.mean())   # 平均
# col1     2.0
# col2    20.0
# dtype: float64

# 例えば、列「col1」の平均値を取得する場合、df.mean()[‘col1’] と記述
print(df.mean()['col1'])
# 2.0
print('************')
print('まとめて取得')
print(df.describe())
#        col1  col2
# count   3.0   3.0
# mean    2.0  20.0
# std     1.0  10.0
# min     1.0  10.0
# 25%     1.5  15.0
# 50%     2.0  20.0
# 75%     2.5  25.0
# max     3.0  30.0

# 例えば、col2の平均を取得したい場合、df.describe()[‘col2’][‘mean’] と記述
s = "col2の平均 : " + str(df.describe()['col2']['mean'])
print(s)
