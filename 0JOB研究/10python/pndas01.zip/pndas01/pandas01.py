import pandas as pd

print('Seriesの基本')
s = pd.Series([10, 20, 30])
print(s)
# 0    10
# 1    20
# 2    30
# dtype: int64

print('ラベルあり')
s = pd.Series([1, 2, 3, 4], index=['a', 'b', 'c', 'd'])
print(s)
# ラベルあり
# a    1
# b    2
# c    3
# d    4
# dtype: int64

print('辞書からラベル生成')
s = pd.Series({'a': 1, 'b': 2, 'c': 3})
print(s)
# 辞書からラベル生成
# a    1
# b    2
# c    3
# dtype: int64

print('*********')
print('アクセスする')
s = pd.Series({'a': 1, 'b': 2, 'c': 3})
print(s['a'])  # 1が出力
print(s.a)  # 1が出力
print()
s = pd.Series([10, 20, 30, 40])
print(s[0:2])

# 0    10
# 1    20
# dtype: int64

print('*********')
print('更新')
s = pd.Series([10, 20, 30, 40])
s[0] = 100
print(s) 
# 0    100
# 1     20
# 2     30
# 3     40
# dtype: int64

print('*********')
print('list型に更新')
print(list(s)) 

