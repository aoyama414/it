import pandas as pd

print('DataFrameのソート')
print('************')

df = pd.DataFrame([[3, 10, 200], [2, 30, 100], [4, 40, 300], [
                  1, 20, 200]], columns=['col1', 'col2', 'col3'])

print(df)
#    col1  col2  col3
# 0     3    10   200
# 1     2    30   100
# 2     4    40   300
# 3     1    20   200

# col1で昇順、col2で降順にソートしてみる。

print(df.sort_values(['col1', 'col2'], ascending=[True, False]))
#    col1  col2  col3
# 3     1    20   200
# 1     2    30   100
# 0     3    10   200
# 2     4    40   300
