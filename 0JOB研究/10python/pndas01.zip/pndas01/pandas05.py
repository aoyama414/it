import pandas as pd

print('DataFrameのデータ参照')
print('************')
print('列を取得する')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30]], columns=[
                  'col1', 'col2'], index=['a', 'b', 'c'])
print(df)
#    col1  col2
# a     1    10
# b     2    20
# c     3    30

# col1を取得する
print(df['col1'])

# a    1
# b    2
# c    3
# Name: col1, dtype: int64

# col2を取得する
print(df.col2)

# a    10
# b    20
# c    30
# Name: col2, dtype: int64

# col2のa行目を[]で取得
print(df.col2['a'])
# 10

# col2のa行目を.で取得
print(df.col2.a)
# 10

print('************')
print('スライスする')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30]], columns=['col1', 'col2'])
print(df)

#    col1  col2
# 0     1    10
# 1     2    20
# 2     3    30

# スライスしてみる
print(df[1:2])
#    col1  col2
# 1     2    20

print('************')
print('loc、ilocで行データをSeries形式で取得')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30]], columns=['col1', 'col2'])
print(df)

#    col1  col2
# 0     1    10
# 1     2    20
# 2     3    30

print('***loc***')
print(df.loc[0])
# col1     1
# col2    10
# Name: 0, dtype: int64
print()
print(df.loc[1:2])
#    col1  col2
# 1     2    20
# 2     3    30
print()
print(df.loc[0]['col1'])
# 1
print()
print('***iloc***')
print(df.iloc[1])
# col1     2
# col2    20
# Name: 1, dtype: int64

print('************')
print('at、iatで行、列を指定して値を取得する')

df = pd.DataFrame([[1, 10], [2, 20], [3, 30]],
                  index=['a', 'b', 'c'],
                  columns=['col1', 'col2'])
print(df)

print(df.at['a', 'col1'])

print(df.iat[1, 1])
