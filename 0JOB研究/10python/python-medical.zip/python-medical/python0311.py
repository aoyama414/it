# 「国民健康・栄養調査」の利用

import gc
import math
import pickle
import csv
import time
import sys
import pickle

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm

from mylibs import mylib1 as mylib1
from mylibs import mylib2 as mylib2
from mylibs import mylib3 as mylib3

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 12

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# 国民健康・栄養調査
# 読み込みと整形
df_bp = pd.read_csv('./public_stats/original/nhns_bp.csv', skiprows=6)
# print(df_bp.head())
# 割合情報の削除
df_bp = df_bp.loc[:, df_bp.columns[df_bp.iloc[0] != '%']]
# 0行目(NaN        NaN        NaN      人数     人数     人数  ...)を削除し、
#    「再掲）40-89歳」より右側である10列目以降削除
# 0~2列目がNaNの場合、上の行の文字列で埋める
df_bp = df_bp.loc[1:, df_bp.columns[:10]]
df_bp = df_bp.fillna(method='ffill')
# 列名を変更
df_bp.columns = ['sex', 'bp_type', 'bp_value', 'total',
                 '20s', '30s', '40s', '50s', '60s', '70s']
# print(df_bp.tail())
# 51行目以下は注釈なので削除
# 「総数」は冗長なので削除
df_bp = df_bp.iloc[:50]
df_bp = df_bp.loc[df_bp.bp_value != '総数', :]
# print(df_bp)
# コーディングのしやすさで、sexとbp_typeの値を英語に変更
df_bp.sex[df_bp.sex == '男性'] = 'M'
df_bp.sex[df_bp.sex == '女性'] = 'F'
df_bp.bp_type[df_bp.bp_type == '収縮期（最高）血圧'] = 'sbp'
df_bp.bp_type[df_bp.bp_type == '拡張期（最低）血圧'] = 'dbp'
df_bp = df_bp.reset_index()
del df_bp['index']

# print(df_bp)
# ユニーク値を取得
# print(df_bp.bp_value.unique())
# '90mmHg未満' '90- 99' '100-109' '110-119' '120-129' '130-139' '140-149'
#  '150-159' '160-169' '170-179' '180mmHg以上' '40mmHg未満' '40-49' '50-59'
#  '60-69' '70-79' '80-89' '90-99' '140ｍｍHg以上']

# 新たにbp_min、bp_max等列を追加し、
# bp_valueが冗長、total列も冗長なので削除
sbp_min = np.concatenate([[70], np.arange(9, 19) * 10])
# [ 70  90 100 110 120 130 140 150 160 170 180]
sbp_max = np.concatenate([sbp_min[1:] - 1, [199]])
# [ 89  99 109 119 129 139 149 159 169 179 199]
dbp_min = np.arange(4, 15) * 10
# 40未満は削除
# [ 40  50  60  70  80  90 100 110 120 130 140]
dbp_max = np.concatenate([dbp_min[1:] - 1, [159]])
# [ 49  59  69  79  89  99 109 119 129 139 159]

dict_sbp_max = {k: v for (k, v) in zip(sbp_min, sbp_max)}
# {70: 89, 90: 99, 100: 109, 110: 119, 120: 129, 130: 139, 140: 149, 150: 159, 160: 169, 170: 179, 180: 199}
dict_dbp_max = {k: v for (k, v) in zip(dbp_min, dbp_max)}
# {40: 49, 50: 59, 60: 69, 70: 79, 80: 89, 90: 99, 100: 109, 110: 119, 120: 129, 130: 139, 140: 159}
# print(dict_sbp_max)
# print(dict_dbp_max)

# df_bpのbp_valueに入れ替え
df_bp = df_bp[df_bp['bp_value'] != '40mmHg未満'].copy()
df_bp['bp_min'] = np.tile(np.concatenate([sbp_min, dbp_min]), 2)
# [ 70  90 100 110 120 130 140 150 160 170 180  40  50  60  70  80  90 100
#  110 120 130 140  70  90 100 110 120 130 140 150 160 170 180  40  50  60
#   70  80  90 100 110 120 130 140]
del df_bp['bp_value']
del df_bp['total']

# 人数を整数型に変更
df_bp[df_bp.columns[2:]] = df_bp[df_bp.columns[2:]].copy().astype('int16')

# -----------
# 確認作業
# -----------
ages = df_bp.columns[2:8]
# print(ages)
# # Index(['20s', '30s', '40s', '50s', '60s', '70s'], dtype='object')
# print()
# # SBP の男性回答者数
# print(df_bp.loc[(df_bp.sex == 'M') & (df_bp.bp_type == 'sbp'), ages].sum())
# # 20s     64
# # 30s     94
# # 40s    128
# # 50s    166
# # 60s    341
# # 70s    500
# # dtype: int64
# # DBP の男性回答者数
# print(df_bp.loc[(df_bp.sex == 'M') & (df_bp.bp_type == 'dbp'), ages].sum())
# # 20s     64
# # 30s     94
# # 40s    128
# # 50s    166
# # 60s    341
# # 70s    500
# # dtype: int64

# ----------
# SEPとDBPの同時確率分布
# ----------
# sex = 'M'
# bp_type = 'sbp'
# age = '20s'

# # 指定する (sex, bp_type, age) における回答者数リスト
# ix = (df_bp.sex == sex) & (df_bp.bp_type == bp_type)
# n = df_bp.loc[ix, age].values

# # リスト n に対応する bp_min リスト
# bp_min = df_bp.loc[ix, 'bp_min'].values

# print('n =', n)
# print('bp_min =', bp_min)
# n = [ 0  5 15 18 18  7  0  1  0  0  0]
# bp_min = [ 70  90 100 110 120 130 140 150 160 170 180]

# bp_min.repeat(n)
dict_bp_min_dist = {}
dict_bp_min_dist['M'] = {}
dict_bp_min_dist['M']['dbp'] = {}
dict_bp_min_dist['M']['sbp'] = {}
dict_bp_min_dist['F'] = {}
dict_bp_min_dist['F']['dbp'] = {}
dict_bp_min_dist['F']['sbp'] = {}

for sex in ['M', 'F']:
    for bp_type in ['sbp', 'dbp']:
        for age in ages:
            dict_bp_min_dist[sex][bp_type][age] = {}
            ix = (df_bp.sex == sex) & (df_bp.bp_type == bp_type)
            n = df_bp.loc[ix, age].values
            bp_min = df_bp.loc[ix, 'bp_min'].values
            dict_bp_min_dist[sex][bp_type][age] = bp_min.repeat(n)

# print(dict_bp_min_dist['M']['sbp']['20s'])
# [ 90  90  90  90  90 100 100 100 100 100 100 100 100 100 100 100 100 100
#  100 100 110 110 110 110 110 110 110 110 110 110 110 110 110 110 110 110
#  110 110 120 120 120 120 120 120 120 120 120 120 120 120 120 120 120 120
#  120 120 130 130 130 130 130 130 130 150]

f = open('./public_stats/processed/dict_bp_min_dist.binaryfile',
         'wb')  # wb: Write Binary
pickle.dump(dict_bp_min_dist, f)
f.close()

f = open('./public_stats/processed/dict_bp_min_dist.binaryfile',
         'rb')  # rb: Read Binary
dict_bp_min_dist = pickle.load(f)
f.close()

# print(dict_bp_min_dist['M']['sbp']['20s'])
# [ 90  90  90  90  90 100 100 100 100 100 100 100 100 100 100 100 100 100
#  100 100 110 110 110 110 110 110 110 110 110 110 110 110 110 110 110 110
#  110 110 120 120 120 120 120 120 120 120 120 120 120 120 120 120 120 120
#  120 120 130 130 130 130 130 130 130 150]

f = open('./public_stats/processed/dict_dbp_max.binaryfile',
         'wb')  # wb: Write Binary
pickle.dump(dict_dbp_max, f)
f.close()

f = open('./public_stats/processed/dict_sbp_max.binaryfile',
         'wb')  # wb: Write Binary
pickle.dump(dict_sbp_max, f)
f.close()

f = open('./public_stats/processed/dict_dbp_max.binaryfile',
         'rb')  # rb: Read Binary
dict_dbp_min = pickle.load(f)
f.close()

# print(dict_dbp_min)
# {40: 49, 50: 59, 60: 69, 70: 79, 80: 89, 90: 99, 100: 109, 110: 119, 120: 129, 130: 139, 140: 159}

f = open('./public_stats/processed/dict_sbp_max.binaryfile',
         'rb')  # rb: Read Binary
dict_sbp_min = pickle.load(f)
f.close()

# print(dict_sbp_min)
# {70: 89, 90: 99, 100: 109, 110: 119, 120: 129, 130: 139, 140: 149, 150: 159, 160: 169, 170: 179, 180: 199}

# ファイルの保存
df_bp.to_csv('./public_stats/processed/df_bp.csv', index=False)

df_bp = pd.read_csv('./public_stats/processed/df_bp.csv')
# print(df_bp)
#    sex bp_type  20s  30s  40s  50s  60s  70s  bp_min
# 0    M     sbp    0    0    0    0    0    0      70
# 1    M     sbp    5    2    3    1    1    1      90
# 2    M     sbp   15   18    9    4    9    9     100
# 3    M     sbp   18   30   26   31   31   36     110
# ..  ..     ...  ...  ...  ...  ...  ...  ...     ...
# 40   F     dbp    0    0    1    2    1    1     110
# 41   F     dbp    0    0    0    0    0    1     120
# 42   F     dbp    0    0    0    0    0    0     130
# 43   F     dbp    0    0    0    0    0    0     140

# 年齢ごとにマーカーの色を変える
dict_color = {'20s': 'r', '30s': 'orange', '40s': 'y',
              '50s': 'g', '60s': 'b', '70s': 'purple'}

# マーカーを血圧分類値にする
dict_marker = {0: '$0$', 1: '$1$', 2: '$2$', 3: '$3$', 4: '$4$', 5: '$5$'}

# 表示の大きさと解像度を設定
fig = plt.figure(figsize=(8, 12))
fig.suptitle('BP Class Distribution')

# 6つの散布図を同時に表示
ax_My = fig.add_subplot(321)  # Male   Young
ax_Fy = fig.add_subplot(322)  # Female Young
ax_Mm = fig.add_subplot(323)  # Male   Middle
ax_Fm = fig.add_subplot(324)  # Female Middle
ax_Me = fig.add_subplot(325)  # Male   Elderly
ax_Fe = fig.add_subplot(326)  # Female Elderly

rs = 0
np.random.seed(rs)

sexes = ['M', 'F']
ages = df_bp.columns[2:8]

for sex in sexes:
    for age in ages:
        sbp_min = dict_bp_min_dist[sex]['sbp'][age]
        sbp_max = [dict_sbp_max[sbpm] for sbpm in sbp_min]
        dbp_min = dict_bp_min_dist[sex]['dbp'][age]
        dbp_max = [dict_dbp_max[dbpm] for dbpm in dbp_min]
        n = len(sbp_min)

        # SBP を乱数生成
        sbp = np.random.rand(n) * (sbp_max - sbp_min) + sbp_min
        rs = rs + 1
        np.random.seed(rs)

        # DBP を乱数生成
        dbp = np.random.rand(n) * (dbp_max - dbp_min) + dbp_min
        rs = rs + 1
        np.random.seed(rs)

        # 軸を選ぶ
        if sex == 'M' and (age == '20s' or age == '30s'):
            ax = ax_My
        elif sex == 'M' and (age == '40s' or age == '50s'):
            ax = ax_Mm
        elif sex == 'M' and (age == '60s' or age == '70s'):
            ax = ax_Me
        elif sex == 'F' and (age == '20s' or age == '30s'):
            ax = ax_Fy
        elif sex == 'F' and (age == '40s' or age == '50s'):
            ax = ax_Fm
        else:
            ax = ax_Fe

        # 各性別・年齢区分における最初の人だけ凡例をつける
        marker = mylib3.calc_bp_class(dbp, sbp)
        for m in np.arange(6):
            x = dbp[marker == m]
            y = sbp[marker == m]
            if m == 0:
                ax.scatter(x, y, c=dict_color[age], marker=dict_marker[m],
                           s=25, linewidth=0.1, label='BP class of Age ' + age)
            else:
                ax.scatter(x, y, c=dict_color[age], marker=dict_marker[m],
                           s=25, linewidth=0.1)

axes = [ax_My, ax_Mm, ax_Me, ax_Fy, ax_Fm, ax_Fe]

# 血圧分類の境界を作成
for ax in axes:
    # vertical lines
    ax.plot([80, 80], [70, 120], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([85, 85], [70, 130], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([90, 90], [70, 140], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([100, 100], [70, 160], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([110, 110], [70, 180], linestyle='--', c='grey', linewidth=0.2)
    # horizontal lines
    ax.plot([40, 80], [120, 120], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([40, 85], [130, 130], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([40, 90], [140, 140], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([40, 100], [160, 160], linestyle='--', c='grey', linewidth=0.2)
    ax.plot([40, 110], [180, 180], linestyle='--', c='grey', linewidth=0.2)

# 各散布図にタイトルを追加
titles = ['Young Male (age:20-39)', 'Middle Male (age:40-59)',
          'Elderly Male (age:60-)', 'Young Female (age:20-39)',
          'Middle Female (age40-59)', 'Elderly Female (age:60-)']
for ax, title in zip(axes, titles):
    ax.set_xlabel('DBP', fontsize=10)
    ax.set_ylabel('SBP', fontsize=10)
    ax.set_xlim(40, 140)
    ax.set_ylim(70, 200)
    ax.set_title(title, fontsize=10)
    ax.tick_params(labelsize=8)
    ax.legend(fontsize=10)

# 散布図同士の間隔調整
plt.tight_layout()
plt.subplots_adjust(top=0.93)

plt.savefig("0311.png")
plt.show()


# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
