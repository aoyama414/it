# 健診レコードの擬似生成

import gc
import math
import pickle
import csv
import time
import sys
import pickle

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns

from mylibs import mylib1 as mylib1
from mylibs import mylib2 as mylib2
from mylibs import mylib3 as mylib3

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 12

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# 血圧情報の擬似生成
df_bp = pd.read_csv('./public_stats/processed/df_bp.csv')

try:
    dict_bp_min_dist = mylib1.get_content(
        './public_stats/processed/dict_bp_min_dist.binaryfile', 'rb')
    dict_sbp_max = mylib1.get_content(
        './public_stats/processed/dict_sbp_max.binaryfile', 'rb')
    dict_dbp_max = mylib1.get_content(
        './public_stats/processed/dict_dbp_max.binaryfile', 'rb')
    # テスト用
    # dict_dbp_max1 = mylib1.get_content(
    #     './public_stats/processed/dict_dbp_max.binary', 'rb')
except Exception:
    print("ファイルエラー")
    sys.exit()

# print(dict_bp_min_dist)
# print(dict_sbp_max)
# print(dict_dbp_max)

sns.set()

fig = plt.figure()
ax = fig.add_subplot(111)

# Original Distribution
sbp_min_0 = dict_bp_min_dist['M']['sbp']['60s']
sbp_max_0 = [dict_sbp_max[sbp_min] for sbp_min in sbp_min_0]
sbp_0 = (sbp_min_0 + sbp_max_0 + 1) / 2  # 血圧
l = len(np.unique(sbp_0))
label = 'Original (N=' + str(len(sbp_0)) + ')'
ax.hist(sbp_0, bins=l, range=(80, 180), label=label, zorder=2)

# Reproducted Distribution
sbp_min_1 = np.random.choice(
    dict_bp_min_dist['M']['sbp']['60s'], 1000, replace=True)
sbp_max_1 = [dict_sbp_max[sbp_min] for sbp_min in sbp_min_1]
sbp_1 = (sbp_min_1 + sbp_max_1 + 1) / 2
label = 'Reproducted (N=1000)'
ax.hist(sbp_1, bins=l, range=(80, 180), label=label, zorder=1)
ax.set_xlabel('SBP')
ax.set_ylabel('N')

ax.legend(loc='best')
ax.set_title('Distribution of SBP (Male, 60s)', fontsize=15)

plt.savefig("0321.png")

# plt.show()

df_info = pd.read_csv('./pseudo_medical/records/excl_bp/info.csv')
df_info['bp_class'] = -1  # 初期値設定
(i, hct, rs) = (0, 2010.55, 100)
df_hc = mylib3.make_new_df_hc(
    df_info, dict_bp_min_dist, i, hct, rs, dict_dbp_max, dict_sbp_max)

# print(df_hc)
rs = 0  # 初期値設定
df_hcs = None  # # DataFrame of Health CheckupS

for i in df_info.index:
    st = mylib1.ym_to_t(df_info.loc[i, 'start_obs_ym'])
    et = mylib1.ym_to_t(df_info.loc[i, 'end_obs_ym'])
    # 血圧分類属性の決定
    rs = rs + 1
    df_hc = mylib3.make_new_df_hc(df_info,  dict_bp_min_dist, i,
                                  st, rs, dict_dbp_max, dict_sbp_max)
    (dbp, sbp) = df_hc[['dbp', 'sbp']].values[0]
    bp_class = mylib3.calc_bp_class(dbp, sbp)
    df_info.loc[i, 'bp_class'] = bp_class

    # 健診レコードの擬似生成
    df_hcs_for_i = None
    rs = rs + 1
    np.random.seed(rs)
    if np.random.rand() > 0.5:  # 被保険者の半分が健診レコードを持つこととする
        rs = rs + 1
        pass
    else:
        # 健診レコードを観察開始から6か月後に、以後1年ごとに登場させる。
        if st + 0.5 > et:
            pass
        else:  # 健診レコード作成
            hct = st + 0.5  # 初期値
            make_record = True
            while make_record:
                rs = rs + 1
                # print(i, hct, rs)
                df_hc = mylib3.make_new_df_hc(
                    df_info,  dict_bp_min_dist, i, hct, rs, dict_dbp_max, dict_sbp_max)
                df_hcs_for_i = pd.concat([df_hcs_for_i, df_hc], axis=0)
                if hct + 1 > et:
                    make_record = False
                else:
                    hct = hct + 1
            df_hcs = pd.concat([df_hcs, df_hcs_for_i], axis=0)
# print(df_info.shape)
# print(df_info.head())
# print(df_hcs.shape)
# # 健診レコードを保有する被保険者の人数を確認
# print(len(df_hcs['iid'].unique()))
# print(df_hcs.head())

df_info.to_csv('./pseudo_medical/records/incl_bp/info.csv', index=False)
df_hcs.to_csv(
    './pseudo_medical/records/incl_bp/healthckeckup.csv', index=False)

# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
