# 死亡率計算の準備と検討

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns

import mylibs.mylib1 as mylib1

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

df_info = pd.read_csv('./pseudo_medical/records/excl_bp/info.csv')

print(df_info)

death = df_info['death'].sum()
print(death)

exposure = (df_info.end_obs_ym.apply(mylib1.ym_to_t)
            - df_info.start_obs_ym.apply(mylib1.ym_to_t)
            ).sum()

print(exposure)
