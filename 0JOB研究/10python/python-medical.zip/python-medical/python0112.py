# 出生比率

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

url = 'http://www.ipss.go.jp/p-toukei/JMD/00/STATS/Births.txt'

df_birth = pd.read_csv(url, skiprows=1, delim_whitespace=True)

print(df_birth)
# ------------------
# 女性
df_birth_F = df_birth[['Year', 'Female']].copy()
df_birth_F.columns = ['year', 'l']  # l は life(生存者数) の頭文字
df_birth_F['sex'] = 'F'
# 男性
df_birth_M = df_birth[['Year', 'Male']].copy()
df_birth_M.columns = ['year', 'l']
df_birth_M['sex'] = 'M'
# 縦方向に結合
df_birth = pd.concat([df_birth_F, df_birth_M], axis=0,
                     ignore_index=True)
print()
print(df_birth)
# ------------------
df_birth['ratio'] = df_birth['l'] / df_birth['l'].sum() # 全体に対する比率
df_birth['cum_ratio'] = df_birth['ratio'].cumsum() # 累積比率
del df_birth['l']
print()
print(df_birth)
# ------------------
print()
print('ファイルの保存')
df_birth.to_csv('./public_stats/processed/ipss_birth.csv', index=False)
# ------------------
print()
print('ファイルの読み込み')
df_birth2 = pd.read_csv('./public_stats/processed/ipss_birth.csv')

print()
print(df_birth)
