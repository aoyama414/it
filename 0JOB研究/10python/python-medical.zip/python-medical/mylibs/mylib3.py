import numpy as np
from scipy.stats import norm
import pandas as pd
import matplotlib.pyplot as plt
import gc
import math
import csv

import mylibs.mylib1 as mylib1

#############
##   3-1   ##
#############


def calc_bp_class(dbp, sbp):
    return ((dbp >= 80) | (sbp >= 120)) * 1 \
        + ((dbp >= 85) | (sbp >= 130)) * 1 \
        + ((dbp >= 90) | (sbp >= 140)) * 1 \
        + ((dbp >= 100) | (sbp >= 160)) * 1 \
        + ((dbp >= 110) | (sbp >= 180)) * 1

#############
##   3-2   ##
#############


def alb_to_ageband(alb):
    if alb <= 29:
        return '20s'
    elif alb >= 70:
        return '70s'
    else:
        return str(int(alb // 10 * 10)) + 's'


def make_random_bp_in_range(dbp_min, dbp_max, sbp_min, sbp_max, rs):
    n = len(sbp_min)
    np.random.seed(rs)
    j = np.random.choice(np.arange(n), 1)
    rs = rs + 1
    np.random.seed(rs)
    dbp = int(np.random.rand() *
              (dbp_max[j] - dbp_min[j]) + dbp_min[j])
    rs = rs + 1
    np.random.seed(rs)
    sbp = int(np.random.rand() *
              (sbp_max[j] - sbp_min[j]) + sbp_min[j])
    rs = rs + 1
    return (dbp, sbp, rs)


def make_random_bp(dict_bp_min_dist, sex, alb, bp_class, rs, dict_dbp_max, dict_sbp_max):  # rs: Random Seed
    dbp_class_border = [40, 80,  85,  90, 100, 110, 160]
    sbp_class_border = [70, 120, 130, 140, 160, 180, 200]
    if not(-1 <= bp_class <= 5):
        return None
    else:
        ageband = alb_to_ageband(alb)
        dbp_min = dict_bp_min_dist[sex]['dbp'][ageband]
        dbp_max = np.array([dict_dbp_max[dbpm] for dbpm in dbp_min])
        sbp_min = dict_bp_min_dist[sex]['sbp'][ageband]
        sbp_max = np.array([dict_sbp_max[sbpm] for sbpm in sbp_min])
        if bp_class == -1:
            # 血圧分類属性を指定せず血圧ランダム生成
            (dbp, sbp, rs) = make_random_bp_in_range(
                dbp_min, dbp_max, sbp_min, sbp_max, rs)
            return (dbp, sbp)
        else:
            # 血圧分類属性を指定して血圧ランダム生成
            satisfy_dbp = (dbp_class_border[bp_class] <= dbp_min) & (
                dbp_min < dbp_class_border[bp_class + 1])
            satisfy_sbp = (sbp_class_border[bp_class] <= sbp_min) & (
                sbp_min < sbp_class_border[bp_class + 1])
            dbp_min = np.append(dbp_min[satisfy_dbp], dbp_min[satisfy_sbp])
            dbp_max = np.append(dbp_max[satisfy_dbp], dbp_max[satisfy_sbp])
            sbp_min = np.append(sbp_min[satisfy_dbp], sbp_min[satisfy_sbp])
            sbp_max = np.append(sbp_max[satisfy_dbp], sbp_max[satisfy_sbp])
            # 血圧をランダム生成
            try:
                (dbp, sbp, rs) = make_random_bp_in_range(
                    dbp_min, dbp_max, sbp_min, sbp_max, rs)
            except:
                dbp = int(
                    (dbp_class_border[bp_class] + dbp_class_border[bp_class + 1]) / 2)
                sbp = int(
                    (sbp_class_border[bp_class] + sbp_class_border[bp_class + 1]) / 2)
            return (dbp, sbp)


def make_new_df_hc(df_info, dict_bp_min_dist, i, hct, rs, dict_dbp_max, dict_sbp_max):
    (iid, sex, birth_ym, bp_class) = df_info.loc[i, [
        'iid', 'sex', 'birth_ym', 'bp_class']].values
    birth_t = mylib1.ym_to_t(birth_ym)
    alb = int(hct - birth_t)
    (dbp, sbp) = make_random_bp(dict_bp_min_dist, sex,
                                alb, bp_class, rs, dict_dbp_max, dict_sbp_max)
    hc_ym = mylib1.t_to_ym(hct)
    # １行データは１列データに変換されてしまうため転置
    df_hc = pd.DataFrame([iid, hc_ym, dbp, sbp]).T
    df_hc.columns = ['iid', 'hc_ym', 'dbp', 'sbp']
    return df_hc
#############
##   3-3   ##
#############


def get_info_for_i(df_info, i):
    cols = ['iid', 'sex', 'birth_ym', 'start_obs_ym', 'end_obs_ym', 'bp_class']
    (iid, sex, birth_ym, start_obs_ym,
     end_obs_ym, bp_class) = df_info.iloc[i][cols]
    birth_t = mylib1.ym_to_t(birth_ym)
    start_obs_t = mylib1.ym_to_t(start_obs_ym)
    end_obs_t = mylib1.ym_to_t(end_obs_ym)
    return (iid, sex, birth_t, start_obs_t, end_obs_t, bp_class)
#############
##   3-4   ##
#############

# df_info, df_commons を健診レコードを持つ者のみに絞り込む


def filter_iid_with_hc(df_hc, df_info, df_commons):
    df_info = df_info[df_info['iid'].isin(df_hc['iid'])]
    df_commons = df_commons[df_commons['iid'].isin(df_hc['iid'])]
    return df_hc, df_info, df_commons


# ALB table, Exposure table を作成
def create_obs_ym_and_alb_table_and_exposure_table(
        start_study_t, end_study_t, df_info):
    npa_obs_ym = mylib1.create_npa_obs_ym(start_study_t, end_study_t)
    df_info = mylib1.convert_ym_to_t_in_info(df_info)
    df_alb_table = mylib1.create_alb_table_from_info(npa_obs_ym, df_info)
    df_exposure_table = mylib1.create_exposure_table_from_alb_table(
        npa_obs_ym, df_alb_table)
    return npa_obs_ym, df_alb_table, df_exposure_table


# Event table の作成
def create_admission_table(npa_obs_ym, df_alb_table, df_commons):
    df_event_table = df_alb_table.copy()
    df_event_table[npa_obs_ym] = 0
    # 入院レコードのみに限定
    df_hosps = df_commons[df_commons['receipt_type'] == 'inpatient']
    dfg = df_hosps.groupby(['iid', 'admission_ym'])
    df_admissions = dfg['days'].sum().reset_index()
    for ym in npa_obs_ym:
        is_ym = (df_admissions['admission_ym'] == ym)
        iid_in_ym = df_admissions.loc[is_ym, 'iid'].values
        in_iid_in_ym = df_event_table['iid'].isin(iid_in_ym)
        df_event_table.loc[in_iid_in_ym, ym] = 1
    return df_event_table


# DBP table の作成
def create_bp_tables(npa_obs_ym, df_alb_table, df_hc, dbp_or_sbp):
    df_bp_table = df_alb_table.copy()
    df_bp_table[npa_obs_ym] = 0
    df_hc.index = df_hc.iid
    idx = df_bp_table.index
    df_bp_table.index = df_bp_table.iid
    for ym in npa_obs_ym:
        ss_bp = df_hc.loc[(df_hc.hc_ym == ym), dbp_or_sbp]
        df_bp_table[ym] = ss_bp
    df_bp_table[npa_obs_ym] = df_bp_table[npa_obs_ym].fillna(
        method='ffill', axis=1)
    df_bp_table.index = idx
    return df_bp_table
