import numpy as np
from scipy.stats import norm
import pandas as pd
import matplotlib.pyplot as plt
import gc
import math
import csv
import pickle

import mylibs.mylib3 as mylib3


def calc_bp_class_allowing_nan(dbp, sbp):
    if np.isnan(dbp) | np.isnan(sbp):
        return None
    else:
        return mylib3.calc_bp_class(dbp, sbp)


def make_filters(npa_obs_ym, dict_tables, sex, age):
    df_alb = dict_tables['alb'][sex]
    is_alb = (df_alb[npa_obs_ym] == age)
    df_exp = dict_tables['exposure'][sex]
    is_exp = (df_exp[npa_obs_ym] == 1)
    df_out = dict_tables['outcome'][sex]
    is_out = (df_out[npa_obs_ym] == 1)
    return is_alb, is_exp, is_out


def get_bp_array(npa_obs_ym, dict_tables, sex, age, exp_or_out, dbp_sbp_or_class):
    is_alb, is_exp, is_out = make_filters(npa_obs_ym, dict_tables, sex, age)
    df_bp = dict_tables[dbp_sbp_or_class][sex]
    if exp_or_out == 'exp':
        df = df_bp[npa_obs_ym][is_alb & is_exp].values
    elif exp_or_out == 'out':
        df = df_bp[npa_obs_ym][is_alb & is_out].values
    else:
        raise ValueError('exp_or_out must be "exp" or "out"!')
    N, T = df.shape
    df = df.reshape(N * T)
    return df[pd.notnull(df)]


def log_L_by_sex_age(dict_bp, w, sex, x, out_num):
    return alpha(dict_bp, w, sex, x) - out_num * np.log(beta(dict_bp, w, sex, x))


def neg_log_L(w, dict_bp):
    log_L = 0
    for sex in ['M', 'F']:
        for x in np.arange(65):
            out_num = len(dict_bp[sex]['out']['class'][x])
            if out_num > 0:
                log_L = log_L + log_L_by_sex_age(dict_bp, w, sex, x, out_num)
            else:
                pass
    return - log_L

# 3


def alpha(dict_bp, w, sex, x):
    out_classes = dict_bp[sex]['out']['class'][x].astype('f8')
    return w * out_classes.sum()


def beta(dict_bp, w, sex, x):
    exp_classes = dict_bp[sex]['exp']['class'][x].astype('f8')
    return (np.exp(w * exp_classes)).sum()


def get_baseline(df_summary, sex, age):
    is_sex = (df_summary['sex'] == sex)
    is_age = (df_summary['age'] == age)
    return df_summary.loc[is_sex & is_age, 'baseline'].values[0]


def load_bases():
    # Load dict_bp
    f = open('./pseudo_medical/processed/incl_bp/dict_bp.binaryfile',
             'rb')  # rb: Read Binary
    dict_bp = pickle.load(f)
    f.close()
    # Load opt_result
    # rb: Read Binary
    f = open('./pseudo_medical/processed/incl_bp/opt_result.binaryfile', 'rb')
    opt_result = pickle.load(f)
    f.close()
    # Load df_summary
    df_summary = pd.read_csv(
        './pseudo_medical/processed/incl_bp/df_summary_with_CI.csv')
    return (dict_bp, opt_result, df_summary)


def predict_rate(df_summary, dict_bp, w, exp_or_out, sex, x):
    baseline = get_baseline(df_summary, sex, x)
    bp_classes = dict_bp[sex][exp_or_out]['class'][x].astype('f8')
    return baseline * np.exp(w * bp_classes)


def count_rates_exp_dif_out(rate_exp, count_exp, rate_out, count_out):
    for r in rate_out:
        count_exp[rate_exp == r] = (
            count_exp[rate_exp == r] - count_out[rate_out == r])
    return (rate_exp, count_exp)


def make_actual_and_score(df_summary, dict_bp, w, sex, age):
    rates_exp = predict_rate(df_summary, dict_bp, w, 'exp', sex, age)
    rates_out = predict_rate(df_summary, dict_bp, w, 'out', sex, age)
    rate_exp, count_exp = np.unique(rates_exp, return_counts=True)
    rate_out, count_out = np.unique(rates_out, return_counts=True)
    # edo: Exposure Diff Outcome
    (rate_edo, count_edo) = count_rates_exp_dif_out(
        rate_exp, count_exp, rate_out, count_out)
    y_actual = np.append(np.repeat(0, count_edo.sum()),
                         np.repeat(1, count_out.sum()))
    y_score = np.append(np.repeat(rate_edo, count_edo),
                        np.repeat(rate_out, count_out))
    return (y_actual, y_score)


def make_whole_actual_and_score(df_summary, dict_bp, w):
    Y_actual, Y_score = [], []
    for sex in ['M', 'F']:
        for age in np.arange(65):
            i = (sex == 'F') * 65 + age
            (y_actual, y_score) = make_actual_and_score(
                df_summary, dict_bp, w, sex, age)
            try:
                Y_actual = np.append(Y_actual, y_actual)
                Y_score = np.append(Y_score, y_score)
            except:
                Y_actual = y_actual
                Y_score = y_score
    return (Y_actual, Y_score)
