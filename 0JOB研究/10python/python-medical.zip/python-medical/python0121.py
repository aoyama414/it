# 死亡情報以外の擬似生成

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import gc

import mylibs.mylib1 as mylib1

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# ファイルの読み込み
df_birth = pd.read_csv('./public_stats/processed/ipss_birth.csv')

# ----------
# 疑似パラメータの設定
# ----------
start_study_t = 2010    # 分析開始時点 (2010年1月)
end_study_t = 2019.999  # 分析終了時点 (2019年12月)

# 指数分布のパラメタ
# 観察開始期間、観察終了期間を決定する。
mu = 10

N = 5000            # N 人の加入者を生成する。
family_ratio = 0.3  # 全体の内、被扶養者の占める割合

# ----------
# 加入者データの疑似生成
# ----------

# 変数初期化
i = 0
rs = 0              # rs: Random Seed
np.random.seed(rs)  # 乱数シードをセット
df_info = pd.DataFrame()

while len(df_info) < N:
    r = np.random.rand()  # 一様乱数
    rs = rs + 1           # 乱数シード更新
    np.random.seed(rs)
    ss = df_birth[df_birth['cum_ratio'] >= r].iloc[0]  # ss: pd.SerieS
    sex = ss.sex
    by = ss.year  # bs: Birth Year
    # 誕生月を一様に分布させる。
    # Birth Time -> Birth Year Month
    bt = by + np.random.rand()
    rs = rs + 1
    np.random.seed(rs)
    bym = mylib1.t_to_ym(bt)
    # 擬似データにおいては
    # 観察開始期間、観察終了期間は指数分布で決定する。
    start_t = start_study_t - mu + np.random.exponential(mu)
    rs = rs + 1
    np.random.seed(rs)
    end_t = start_t + np.random.exponential(mu)
    rs = rs + 1
    np.random.seed(rs)
    # | は論理和 (or)
    if (end_t < start_study_t) | (end_study_t < start_t):
        # 分析期間に在籍しない場合 -> 何もしない
        pass
    else:
        # iid: 個人ID
        cols = ['iid', 'sex', 'family', 'birth_ym',
                'start_obs_ym', 'end_obs_ym']
        df_exposure = pd.DataFrame(np.zeros(len(cols)).reshape(1, len(cols)),
                                   columns=cols)
        # 本人: 1, 家族: 2
        family = 2 - (np.random.rand() > family_ratio)
        rs = rs + 1
        np.random.seed(rs)
        df_exposure[cols] = ['i' + str(i).zfill(6), sex, family, bym,
                             mylib1.t_to_ym(start_t), mylib1.t_to_ym(end_t)]
        # df_info の下に
        # 新しく作成した１列データフレーム df_exposure を追加する。
        df_info = pd.concat([df_info, df_exposure], axis=0)
    i = i + 1

# index の振り直し
df_info = df_info.reset_index()
# reset_index() により作成されてしまった "index" という列を消す。
del df_info['index']

# ----------
# 真の比率 vs. 擬似生成された出生比率（男性のみ）を図で表現
# ----------
# 真の出生比率
df_birth_M = df_birth.loc[df_birth.sex == 'M', ['year', 'ratio']]
df_birth_M['ratio'] = df_birth_M.ratio / df_birth_M.ratio.sum()

# 擬似生成された加入者の出生比率
df_info_M = df_info.loc[df_info.sex == 'M', ['birth_ym', 'family']]
df_info_M['birth_ym'] = df_info_M.birth_ym.apply(mylib1.ym_to_t) // 1
df_info_M = df_info_M.groupby(['birth_ym']).count()
df_info_M = df_info_M / df_info_M.sum()
# print('*****d f_info_M *****')
# print(df_info_M)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(df_birth_M.year, df_birth_M.ratio, c='k', label='真の比率')
ax.plot(df_info_M.index, df_info_M.family, c='b',
        label='疑似比率', lw=0.5)
ax.legend(loc='best')
ax.set_xlabel('誕生年')
ax.set_title('出生率(男性)', fontsize=15)

plt.savefig('0121a.png')

# ----------
# 観察期間と分析期間の概念図
# 　観察期間から分析期間に制限
# ----------
df = df_info.iloc[:10].copy()
df['start_obs_t'] = df.start_obs_ym.apply(mylib1.ym_to_t)
df['end_obs_t'] = df.end_obs_ym.apply(mylib1.ym_to_t)
fig = plt.figure()
ax = fig.add_subplot(111)
for i in df.index:
    X = df.loc[i, ['start_obs_t', 'end_obs_t']]
    Y = [i, i]
    ax.plot(X, Y, c='k')
ax.plot([start_study_t, start_study_t], [0, 10], c='r', ls='--')
ax.plot([end_study_t, end_study_t], [0, 10], c='r', ls='--')
ax.annotate('', xy=(end_study_t, 10), xytext=(start_study_t, 10),
            arrowprops=dict(arrowstyle='<->', color='r'))
# 分析期間
x = end_study_t + 1
y = 10
t = '分析期間'
ax.text(x, y, t, color='r', va='center', ha='left')
# iid = i000009 の観察期間
x = (df.loc[6, 'start_obs_t'] + df.loc[6, 'end_obs_t']) / 2
y = 6.5
t = '観察期間 i000009'
ax.text(x, y, t, color='k', va='center', ha='center')
# iid = i000012 の観察期間
y = 8.5
t = '観察期間 i000012'
ax.text(x, y, t, color='k', va='center', ha='center')

ax.set_yticks(df.index)
ax.set_yticklabels(df.iid)
ax.set_xlabel('Year')
ax.set_title('観察期間 vs. 分析期間')

plt.savefig('0121b.png')

# ----------
# 観察開始年月の分析開始時点での制限
# ----------
df_info['start_obs_t'] = df_info['start_obs_ym'].apply(mylib1.ym_to_t)
# ---------------
# 時刻が文字列のままでも大小比較は可能ですが、
# 数値に変換しておくと次の年齢の計算で便利なので数値にすることとします。
more_start_study = (df_info['start_obs_t'] > start_study_t)
df_info['start_obs_t'] = more_start_study * df_info['start_obs_t'] \
    + ~more_start_study * start_study_t
#     -----------------
#     ~ は論理否定演算子、False→True, True→False, 0→1、1→0
df_info['start_obs_ym'] = df_info['start_obs_t'].apply(mylib1.t_to_ym)

# 観察終了年月の分析終了時点での制限
df_info['end_obs_t'] = df_info['end_obs_ym'].apply(mylib1.ym_to_t)
less_end_study = (df_info['end_obs_t'] < end_study_t)
df_info['end_obs_t'] = less_end_study * df_info['end_obs_t'] \
    + ~less_end_study * end_study_t
df_info['end_obs_ym'] = df_info['end_obs_t'].apply(mylib1.t_to_ym)
df_info['birth_t'] = df_info['birth_ym'].apply(mylib1.ym_to_t)

# print(df_info)

# plt.show()

# **************************************
# 死亡情報の擬似生成
# **************************************

# ----------
# 月次満年齢テーブルの作成
# ----------
npa_obs_ym = mylib1.create_npa_obs_ym(start_study_t, end_study_t)
npa_obs_t = mylib1.convert_ym_to_t_in_npa(npa_obs_ym)
npa_birth_t = np.array(df_info['birth_t'])

df_alb_table = df_info.copy()
for i in np.arange(len(npa_obs_ym)):
    # "//" で商(整数)をとる。ちなみに剰余演算子は "%"
    # df_alb_table に新しい列を追加しながら、計算した ALB 列を代入している。
    df_alb_table[npa_obs_ym[i]] = (npa_obs_t[i] - npa_birth_t) // 1
    df_alb_table[npa_obs_ym[i]] = df_alb_table[npa_obs_ym[i]].astype('int8')

df_mortality = pd.read_csv('./public_stats/processed/ipss_mortality.csv')

df_mortality_table = df_alb_table.copy()

# int8 から float64 に変換することで、死亡率がより精緻に取り扱える。
for i in np.arange(len(npa_obs_ym)):
    df_mortality_table[npa_obs_ym[i]] = \
        df_mortality_table[npa_obs_ym[i]].astype('float64')

# df_mortality_table に月次死亡率を埋める
for ym in npa_obs_ym:
    mortalities = mylib1.calc_monthly_mortality_col(
        df_mortality, df_alb_table, ym)
    df_mortality_table[ym] = mortalities

# ----------
# 月次エクスポージャテーブルの作成
# ----------
# 通常エクスポージャは [人年] で計算されるが
# ここでは単位を [人月] とする。
df_exposure_table = df_alb_table.copy()

for ym in npa_obs_ym:
    # Boolean values for Start_obs_t
    bs = (df_exposure_table['start_obs_t'] <= mylib1.ym_to_t(ym))
    # Boolean values for End_obs_t
    be = (mylib1.ym_to_t(ym) <= df_exposure_table['end_obs_t'])
    # Boolean values for Birth_t
    bb = (df_exposure_table['birth_t'] <= mylib1.ym_to_t(ym))
    # Boolean values for ALB
    # 健保組合は65歳以上を保障しない
    ba = (df_alb_table[ym] < 65)
    df_exposure_table[ym] = (bs & be & bb & ba) * 1

# 乱数列の作成
df_death_table = df_alb_table.copy()

rs = 0              # rs: Random Seed
np.random.seed(rs)  # 乱数シードをセット
df_random = np.random.random(df_death_table[npa_obs_ym].shape)
df_death_table[npa_obs_ym] = (df_random < df_mortality_table[npa_obs_ym]) \
    * df_exposure_table[npa_obs_ym] * 1

# 上の手続きで加入者 i000027 は2011年4月に死亡
# 確認
# pd.options.display.max_rows = 20
# print(df_death_table.iloc[17].iid, '\n')
# print(df_death_table.loc[17, npa_obs_ym[12:]].head(10))

# ----------
# 死亡を最初の1つが確定するとその後のエクスポージャを0にする
# cumsum を２回適用して、１となるセルのみを１とし、それ以外を０とする。
# ----------
df_death_table[npa_obs_ym] \
    = (df_death_table[npa_obs_ym].cumsum(axis=1).cumsum(axis=1) == 1) * 1

# 整数型に変更してメモリ効率を上げる。
for i in np.arange(len(npa_obs_ym)):
    df_death_table[npa_obs_ym[i]] \
        = df_death_table[npa_obs_ym[i]].astype('int8')

# 死亡後のエクスポージャを０に変更。
before_death_filter = (df_death_table[npa_obs_ym].cumsum(
    axis=1).cumsum(axis=1) <= 1) * 1
df_exposure_table[npa_obs_ym] = df_exposure_table[npa_obs_ym] * \
    before_death_filter

# print(df_exposure_table)

# ----------
# 死亡情報の加入者情報への付与
# ----------
# 加入者情報データに死亡情報を追加
df_info['death'] = 0
df_info['death'] = df_info['death'].astype('int8')
df_info.loc[(df_death_table[npa_obs_ym].sum(axis=1) == 1), 'death'] = 1
# ---------------------------------------------
# 死亡レコードがある者

# 当月のエクスポージャが 1、翌月のエクスポージャが０の時
# 当月が観察終了年月となる。
# エクスポージャを 1 ヶ月ずらした差分が 1 となる年月が観察最終年月。
df_exp_dif = df_exposure_table[npa_obs_ym] \
    - df_exposure_table[npa_obs_ym].shift(-1, axis=1)
# ただし分析終了年月の翌月は存在しないため None となる。
# 分析終了年月 (2019/12) にエクスポージャが 1 の場合
# 分析終了年月が観察終了年月となる。
df_exp_dif[npa_obs_ym[-1]] = df_exposure_table[npa_obs_ym[-1]]
# 差分が -1 の箇所を 0 に変更。
df_exp_dif[df_exp_dif < 0] = 0

# エクスポージャがすべて0となった加入者については
# df_infoから除外
exposure_exists = (df_exposure_table[npa_obs_ym].sum(axis=1) > 0)
df_info = df_info[exposure_exists]
df_exposure_table = df_exposure_table[exposure_exists]

# 誕生年月を観察開始年月に変更
b = (df_info['start_obs_ym'] < df_info['birth_ym'])
df_info.loc[b, 'birth_ym'] = df_info.loc[b, 'start_obs_ym']
df_info.loc[b, 'birth_t'] = df_info.loc[b, 'start_obs_t']

# エクスポージャの最終年月を観察終了年月とする。
for i in df_exposure_table.index:
    end_of_exp = (df_exp_dif.loc[i, npa_obs_ym] == 1)
    df_info.loc[i, 'end_obs_ym'] = npa_obs_ym[end_of_exp][0]

# 時刻 t に関する情報を削除し、カラムを並べ替える。
info_cols = ['iid', 'sex', 'family', 'birth_ym',
             'start_obs_ym', 'end_obs_ym', 'death']
df_info = df_info[info_cols]

# print(df_info)
# ----------
# ガページコレクション
# ----------
del df_birth
del df_mortality
del df_exposure
del df_alb_table
del df_mortality_table
del df_exposure_table
del df_death_table

gc.collect()

# ----------
# データの保存
# ----------
df_info.to_csv('./pseudo_medical/records/excl_bp/info.csv', index=False)

print(df_info)
