# 2-2 レセプトの擬似生成

import gc
import csv
import time

from mylibs import mylib1, mylib2
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 10

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
# ----------
# 擬似生成に必要なデータの用意
# ----------
# 加入者情報データ
df_info = pd.read_csv('./pseudo_medical/records/excl_bp/info.csv')
# print(df_info)

# 月次入院発生率
df_admission = pd.read_csv('./public_stats/processed/ps_admission.csv')
# 75歳以上のデータを削除
less_age_75 = (df_admission.alb_max < 75)
df_admission = df_admission.loc[less_age_75]
cols = df_admission.columns[3:]
df_admission_cumrate = df_admission.copy()
df_admission_cumrate[cols] = df_admission[cols].cumsum(axis=1)
# 月次発生率の累計
# 0.025144669399999993
# 累計が1を超えないので一様乱数を適用できる
# print(df_admission_cumrate[cols[-1]].max())
# print(df_admission_cumrate)

# 月次外来発生率
df_outpatient = pd.read_csv('./public_stats/processed/ps_outpatient.csv')
# 75歳以上のデータを削除
less_age_75 = (df_outpatient.alb_max < 75)
df_outpatient = df_outpatient.loc[less_age_75]
cols = df_outpatient.columns[3:]
df_outpatient_cumrate = df_outpatient.copy()
df_outpatient_cumrate[cols] = df_outpatient[cols].cumsum(axis=1)
# 月次外来発生率の累計
# print(df_outpatient_cumrate[cols[-1]].max())
# print(df_outpatient_cumrate)

# 2.5299410747999995
# 累計が1を超えるので累積発生率と一様乱数を使ったレコードの疑似生成ができない
# 外来については、各疾病の発生率毎に一様乱数を適用して疑似生成を適用
# 月次外来発生率
# 女性55～59歳を例にとる
# print(df_outpatient[(df_outpatient['sex']=='F') & (df_outpatient['alb_min']==55)])

# 平均在院日数
df_days = pd.read_csv('./public_stats/processed/ps_days.csv')
# 75歳以上を削除
less_age_75 = (df_days.alb_max < 75)
df_days = df_days.loc[less_age_75]

# ----------
# 擬似生成するレセプトのフォーマット定義
# ----------
# の再作成が必要
# すべてを関数化する必要があるのに少ない


dict_csv_paths = {'common': './pseudo_medical/records/excl_bp/commons.csv',
                  'disease': './pseudo_medical/records/excl_bp/diseases.csv',
                  'treatment': './pseudo_medical/records/excl_bp/treatments.csv'}

commons_csv = open(dict_csv_paths['common'], 'w', newline="")
open_common_object = csv.writer(commons_csv)
cols = ['iid', 'rid', 'ym', 'receipt_type', 'admission_ym', 'days']
open_common_object.writerow(cols)

diseases_csv = open(dict_csv_paths['disease'], 'w', newline="")
open_disease_object = csv.writer(diseases_csv)
cols = ['iid', 'rid', 'first_ym', 'icd10_code']
open_disease_object.writerow(cols)

treatments_csv = open(dict_csv_paths['treatment'], 'w', newline="")
open_treatment_object = csv.writer(treatments_csv)
cols = ['iid', 'rid', 'treatment_code']
open_treatment_object.writerow(cols)

# レセプトIDの初期値
rid = 'r00000000'
# 乱数シードの初期値
rs = 0

# print(len(df_info)) 4815件
for i in np.arange(len(df_info)):  # df_info を上から順に参照
    gc.collect()
    # df_info の i 番目の (iid, sex, birth_t, start_obs_t, end_obs_t) を取得 # 1
    (iid, sex, birth_t, start_obs_t,
     end_obs_t) = mylib2.get_info_for_i(df_info, i)
    t = start_obs_t

    while start_obs_t <= t <= end_obs_t:
        alb = int(t - birth_t)

        # 入院累積発生率の pd.Series を取得 # 2
        ss_adm_cumrate = mylib2.get_ss_admission_cumrate(
            df_admission_cumrate, sex, alb)
        # 入院用に一様乱数 u(rs) (0 <= r <= 1)を生成 & ランダムシード更新 # 3
        (u, rs) = mylib2.get_random_num_for_adm(rs)
        # (入院発生？, 入院原因傷病 dis) = 入院乱数シミュレーション(u) # 4
        (does_adm_occur, dis) = mylib2.get_admission_disease(ss_adm_cumrate, u)
# ************************************************
    #     if i == 100:
    #         print(iid, sex, birth_t, start_obs_t,     end_obs_t)
    #         print(start_obs_t <= t <= end_obs_t)
    #         print(alb)
    #         print(ss_adm_cumrate)
    #         print(u, rs)
    #         print(does_adm_occur, dis)
    #         elapsed_time = time.time() - start
    #         print("elapsed_time:{0}".format(elapsed_time) + "[sec]")

    #         break
    #     t = t + 1 / 12  # t を１ヶ月ずらす
    # if i == 100:
    #   break
# ************************************************

        if does_adm_occur:
            mu = mylib2.get_avg_hospdays(df_days, sex, alb, dis)  # 5mylib2
            # 在院日数 days を指数分布(mu) で決定 # 6
            (days, rs) = mylib2.get_random_days(mu, rs)
            # 入院発生年月、入院は全て月央に発生すると仮定
            admission_ym = mylib1.t_to_ym(t)
            # 月をまたぐ継続入院でなくても次のコードブロックを実行
            does_hosp_continue = True
            m = 0  # 初月入院を 0、次月から月をまたぐごとに +1
            while does_hosp_continue:
                ym = mylib1.t_to_ym(t)
                rid = mylib2.make_new_rid(rid)  # 7
                # 共通レコード(入院)の発行
                # 共通レコード(入院)の作成
                df_common = mylib2.create_df_common_inpatient_after_m_months(
                    iid, rid, ym, admission_ym, days, m)  # 8
                mylib2.add_df_xxx_on_csv(
                    open_common_object, df_common)  # 9
                # 傷病レコードの発行
                df_disease = mylib2.create_df_disease(
                    iid, rid, admission_ym, dis)  # 10
                mylib2.add_df_xxx_on_csv(
                    open_disease_object, df_disease)  # 9
                # 診療行為レコード(入院)の発行
                df_treatment = mylib2.create_df_treatment(
                    iid, rid, 'A100')  # 11
                mylib2.add_df_xxx_on_csv(
                    open_treatment_object, df_treatment)  # 9
                # 診療行為レコード(手術)を入院の 10% に発行
                (u, rs) = mylib2.get_random_num_for_adm(rs)
                if u <= 0.1:
                    df_treatment = mylib2.create_df_treatment(
                        iid, rid, 'K000')
                    mylib2.add_df_xxx_on_csv(
                        open_treatment_object, df_treatment)  # 9

                t = t + 1 / 12  # t を１ヶ月ずらす
                does_hosp_continue = (days - 15 - 30 * m > 0)
                m = m + 1

        else:  # 入院発生なし
            # 外来発生率 out(sex, alb) を取得 # 12
            ss_out_rare = mylib2.get_outpatient_rate(
                df_outpatient, sex, alb)
            # 外来用に一様乱数 u(rs) (0 <= r <= 1)を生成 & ランダムシード更新 # 13
            (us, rs) = mylib2.get_random_num_for_out(rs)
            # (外来発生？, 複数外来原因傷病 diss) = 外来乱数シミュレーション(u) # 14
            (does_occur_outpatient, diss) \
                = mylib2.get_outpatient_diseases(ss_out_rare, us)
            if does_occur_outpatient:
                # 外来発生年月、外来は全て月央に発生すると仮定
                ym = mylib1.t_to_ym(t)
                for dis in diss:
                    rid = mylib2.make_new_rid(rid)
                    # 共通レコード(外来)の発行
                    # 共通レコード(外来) df_common(iid, rid, ym) の作成 # 15
                    df_common = mylib2.create_df_common(
                        iid, rid, ym, 'outpatient', '-', 1)
                    mylib2.add_df_xxx_on_csv(
                        open_common_object, df_common)  # 9
                    # 傷病レコードの発行
                    df_disease = mylib2.create_df_disease(
                        iid, rid, ym, dis)
                    mylib2.add_df_xxx_on_csv(
                        open_disease_object, df_disease)  # 9
                    # 診療行為レコード(外来)の発行
                    df_treatment = mylib2.create_df_treatment(
                        iid, rid, 'A000')
                    mylib2.add_df_xxx_on_csv(
                        open_treatment_object, df_treatment)  # 9
                    df_treatment = mylib2.create_df_treatment(
                        iid, rid, 'F000')
                    mylib2.add_df_xxx_on_csv(
                        open_treatment_object, df_treatment)  # 9
                    # 診療行為レコード(手術)を外来の 1% に発行
                    (u, rs) = mylib2.get_random_num_for_adm(rs)
                    if u <= 0.01:
                        df_treatment = mylib2.create_df_treatment(
                            iid, rid, 'K000')
                        mylib2.add_df_xxx_on_csv(
                            open_treatment_object, df_treatment)  # 9
            t = t + 1 / 12  # t を１ヶ月ずらす
# ***************************************
    #     if i == 100:
    #         print(df_treatment)
    #         elapsed_time = time.time() - start
    #         print("elapsed_time:{0}".format(
    #             elapsed_time) + "[sec]")
    #         break

    # if i == 100:
    #     break
# ***************************************
commons_csv.close()
diseases_csv.close()
treatments_csv.close()

print('作業終了')
