# セミパラメトリック分析 ~ 区間推定

import gc
import math
import pickle
import csv
import time
import sys
import pickle

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns
import scipy as sp

from mylibs import mylib1 as mylib1
from mylibs import mylib2 as mylib2
from mylibs import mylib3 as mylib3
from mylibs import mylib4 as mylib4

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 6
pd.options.display.max_columns = 12

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# データ分析
f = open('./pseudo_medical/processed/incl_bp/dict_bp.binaryfile',
         'rb')  # rb: Read Binary
dict_bp = pickle.load(f)
f.close()

f = open('./pseudo_medical/processed/incl_bp/opt_result.binaryfile',
         'rb')  # rb: Read Binary
opt_result = pickle.load(f)
f.close()

w = opt_result.x[0]


def gamma(dict_bp, w, sex, x):
    exp_classes = dict_bp[sex]['exp']['class'][x].astype('f8')
    return (np.exp(w * exp_classes) * (exp_classes ** 2)).sum()


def delta(dict_bp, w, sex, x):
    exp_classes = dict_bp[sex]['exp']['class'][x].astype('f8')
    return (np.exp(w * exp_classes) * exp_classes).sum()


def zeta(dict_bp, w, sex, x):
    f1 = len(dict_bp[sex]['out']['class'][x].astype('f8'))
    beta = mylib4.beta(dict_bp, w, sex, x)
    f2 = gamma(dict_bp, w, sex, x) / beta
    f3 = (delta(dict_bp, w, sex, x) / beta)**2
    return - f1 * (f2 - f3)


def hesse(dict_bp, w):
    h = None
    for sex in ['M', 'F']:
        for x in np.arange(65):
            try:
                z = zeta(dict_bp, w, sex, x)
                try:
                    h = h + z
                except:
                    h = z
            except:
                pass
    return h

# 95%の信頼区間の計算


def stdev(dict_bp, w):
    return (-1 / hesse(dict_bp, w))**0.5


sigma = stdev(dict_bp, w)

lcl = w - 1.96 * sigma
ucl = w + 1.96 * sigma

# print('LCL(w*) =', lcl)
# print('    w*  =', w)
# print('UCL(w*) =', ucl)
# LCL(w*) = 0.27346469226915315
#     w*  = 0.33310546874999997
# UCL(w*) = 0.3927462452308468

# イェンセンの不等式


def fa(x):
    return x * (1 - x)


fig = plt.figure()
ax = fig.add_subplot(111)
# y = f(x) = x(1-x)
x = np.arange(101) / 100
y = fa(x)
ax.plot(x, y, c='b')
ax.text(0.8, 0.25, r'$y = f(x) = x(1-x)$',
        ha='center', va='top', color='b', fontsize=15)
# 三角形
x = np.array([0.2, 0.4, 0.8])
y = fa(x)
ax.plot(x[:2], y[:2], c='k')
ax.plot(x[1:], y[1:], c='k')
ax.plot([x[0], x[2]], [y[0], y[2]], c='k')
# 三角形の重心
x, y = x.sum()/3, y.sum()/3
ax.scatter(x, y, c='k')
ax.text(x, y-0.1, r'$\frac{f(x_1) + f(x_2) + f(x_3)}{3}$',
        ha='center', va='top', fontsize=20)
ax.arrow(x, y-0.1, dx=0, dy=0.09,
         width=0.001, head_width=0.01, head_length=0.005,
         length_includes_head=True, color='k')
# 重心から f(x) に伸ばした点
ax.plot([x, x], [y, fa(x)], c='k', ls='--')
ax.scatter(x, fa(x), c='r')
ax.text(x, 0.26, r'$f\left( \frac{x_1 + x_2 + x_3}{3} \right)$',
        ha='center', va='bottom', color='red', fontsize=20)
# 共通
ax.set_ylim([0, 0.3])
ax.set_title("Jensen's inequality")

plt.savefig("o421a.png")

# plt.show()

# ベースライン発生率の分散の評価
sex, x = 'M', 60


def U(sex, x):
    E = len(dict_bp[sex]['exp']['class'][x].astype('f8'))
    O = len(dict_bp[sex]['out']['class'][x].astype('f8'))
    return O * (1 - O / E)


def T(dict_bp, sex, x, w, sigma):
    exp_classes = dict_bp[sex]['exp']['class'][x].astype('f8')
    return ((np.exp(w * exp_classes) * exp_classes)**2).sum() * (sigma**2)


def VX(sex, x, w, sigma, baseline):
    nume = U(sex, x) - baseline**2 * T(dict_bp, sex, x, w, sigma)
    deno = T(dict_bp, sex, x, w, sigma) + mylib4.beta(dict_bp, w, sex, x)**2
    return nume / deno


def get_baseline(df_summary, sex, age):
    is_sex = (df_summary['sex'] == sex)
    is_age = (df_summary['age'] == age)
    return df_summary.loc[is_sex & is_age, 'baseline'].values[0]


def add_baseline_CI(df_summary, sex, age, w, sigma):
    baseline = get_baseline(df_summary, sex, age)
    is_sex = (df_summary['sex'] == sex)
    is_age = (df_summary['age'] == age)
    vx = VX(sex, x, w, sigma, baseline)
    df_summary.loc[is_sex & is_age, 'baseline_LCL'] = baseline - 1.96 * vx
    df_summary.loc[is_sex & is_age, 'baseline_UCL'] = baseline + 1.96 * vx
    return df_summary


def add_baseline_CIs(df_summary, w, sigma):
    df_summary['baseline_LCL'] = 0
    df_summary['baseline_UCL'] = 0
    for sex in ['M', 'F']:
        for age in np.arange(65):
            df_summary = add_baseline_CI(df_summary, sex, age, w, sigma)
    return df_summary


df_summary = pd.read_csv('./pseudo_medical/processed/incl_bp/df_summary.csv')
# print(df_summary)
# print(w,sigma)
#     sex   age   out     exp         beta      rate  baseline
# 0     M   0.0   3.0   314.0   390.033267  0.009554  0.007692
# 1     M   1.0   1.0   677.0   860.863440  0.001477  0.001162
# 2     M   2.0   7.0   796.0  1011.510175  0.008794  0.006920
# ..   ..   ...   ...     ...          ...       ...       ...
# 127   F  62.0  17.0  1448.0  2906.680608  0.011740  0.005849
# 128   F  63.0  21.0  1356.0  2839.252421  0.015487  0.007396
# 129   F  64.0  13.0  1243.0  2599.738200  0.010459  0.005001

# [130 rows x 7 columns]
# 0.33310546874999997 0.03042896759226878

df_summary = add_baseline_CIs(df_summary, w, sigma)

print(df_summary)

fig = plt.figure(figsize=(8, 4))
axes = fig.subplots(1, 2, sharex=True, sharey=True)
# 男性
ax = axes[0]
df = df_summary[df_summary['sex'] == 'M']
ax.plot(df['age'], df['baseline'], c='b')
ax.plot(df['age'], df['baseline_LCL'], c='b', ls='--')
ax.plot(df['age'], df['baseline_UCL'], c='b', ls='--')
ax.set_title('Male')
# 女性
ax = axes[1]
df = df_summary[df_summary['sex'] == 'F']
ax.plot(df['age'], df['baseline'], c='r')
ax.plot(df['age'], df['baseline_LCL'], c='r', ls='--')
ax.plot(df['age'], df['baseline_UCL'], c='r', ls='--')
ax.set_title('Female')
# 共通
fig.suptitle('Baseline Rates and 95% CI')

plt.savefig("0421b.png")
df_summary.to_csv(
    './pseudo_medical/processed/incl_bp/df_summary_with_CI.csv', index=False)

plt.show()

# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
