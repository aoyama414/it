# 受療率の算出に用いた人口

import gc

import mylibs.mylib1 as mylib1  # 自作ライブラリ
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm

# 表示する行・列の数を設定
pd.options.display.max_rows = 6
pd.options.display.max_columns = 10

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# ----------
# 受診率の算出に用いた人口
# ----------
df_pop = pd.read_csv('./public_stats/processed/ps_pop.csv')
# print(df_pop)
# print()

# ----------
# 月次新入院発生件数
# ----------

# 読み込みと整形
df_hosp = pd.read_csv('./public_stats/original/ps_hosp.csv',
                      skiprows=13, encoding='cp932')
# print(df_hosp)
# print()

cols = df_hosp.columns[2:]
df_admission = df_hosp.loc[df_hosp['入院－外来_010'] == '新入院', cols]
df_outpatient = df_hosp.loc[df_hosp['入院－外来_010'] == '外来', cols]

# print(df_admission.head())
# print()

print(df_admission[cols[2]].notnull().sum())  # NaN でない値の数
df_admission = df_admission.drop(cols[2], axis=1)

# print(df_admission.head())
# print()
# 現状のカラム名
# print(df_admission.columns)
# print()
# Index(['性別_001', '年齢階級_003', '１　感染症及び寄生虫症', '２　新生物＜腫瘍＞',
#        '３　血液及び造血器の疾患並びに免疫機構の障害', '４　内分泌，栄養及び代謝疾患', '５　精神及び行動の障害', '６　神経系の疾患',
#        '７　眼及び付属器の疾患', '８　耳及び乳様突起の疾患', '９　循環器系の疾患', '１０　呼吸器系の疾患', '１１　消化器系の疾患',
#        '１２　皮膚及び皮下組織の疾患', '１３　筋骨格系及び結合組織の疾患', '１４　腎尿路生殖器系の疾患', '１５　妊娠，分娩及び産じょく',
#        '１６　周産期に発生した病態', '１７　先天奇形，変形及び染色体異常',
#        '１８　症状，徴候及び異常臨床所見・異常検査所見で他に分類されないもの', '１９　損傷，中毒及びその他の外因の影響'],
#       dtype='object')

# ヘッダをICDコードに変更
idx = ['sex', 'alb', 'A00', 'C00', 'D50', 'E00', 'F00', 'G00', 'H00', 'H60', 'I00',
       'J00', 'K00', 'L00', 'M00', 'N00', 'O00', 'P00', 'Q00', 'R00', 'S00']
df_admission = df_admission.T.reset_index()  # 'index' という列が新しく作成される
# reset_index() によって作られた 'index' 列を削除
del df_admission['index']
df_admission.index = idx                     # 代表 ICD-10 に置き換える
df_admission = df_admission.T

# print(df_admission.head())
# print()

# 年齢区分の変更
alb_min = [0, 1]
# [ 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85]
alb_min.extend(np.arange(17)*5+5)
alb_min.extend(alb_min)
df_admission['alb_min'] = alb_min

alb_max = [0, 4]
alb_max.extend(np.arange(16)*5+9)
alb_max.extend([130])
alb_max.extend(alb_max)
# [ 9 14 19 24 29 34 39 44 49 54 59 64 69 74 79 84]
df_admission['alb_max'] = alb_max

del df_admission['alb']

# print(df_admission)
# print()

# sexを(M,F)に変更
# 列の変更
cols = ['sex', 'alb_min', 'alb_max']
cols.extend(df_admission.columns[1:-2])  # A00~S00の取り出し
df_admission = df_admission[cols]

df_admission['sex'] = np.concatenate([np.repeat('M', 19), np.repeat('F', 19)])

# print(df_admission)

# [-],[・]を0に変更
df_admission = df_admission.replace('-', 0)
df_admission = df_admission.replace('･', 0)
df_admission[df_admission.columns[1:]
             ] = df_admission[df_admission.columns[1:]].astype('float32')

# print(df_admission)

# 週に1日日曜日が休診日があることを考慮する
cols = df_admission.columns[3:]
df_admission[cols] = df_admission[cols] * 365 * 6 / 7 / 12

# print(df_admission)

######
# df_outpatient
######
cols = df_hosp.columns[2:]

# df_outpatient の 2 列目は全て NaN なので、削除
df_outpatient = df_outpatient.drop(cols[2], axis=1)

# 傷病分類と ICD1-10 の対応表より、傷病分類を 1 つの ICD-10 コードで代表
df_outpatient = df_outpatient.T.reset_index()
# reset_index() によって作られた 'index' 列を削除
del df_outpatient['index']
df_outpatient.index = idx                     # 代表 ICD-10 に置き換える
df_outpatient = df_outpatient.T

# 年齢区分を、年齢の最小値 alb_min と最大値 alb_max に置き換えて、alb を削除
alb_min = [0, 1]
alb_min.extend(np.arange(17)*5+5)
alb_min.extend(alb_min)
df_outpatient['alb_min'] = alb_min
alb_max = [0, 4]
alb_max.extend(np.arange(16)*5+9)
alb_max.extend([130])
alb_max.extend(alb_max)
df_outpatient['alb_max'] = alb_max
del df_outpatient['alb']

# sex の値を (M,F) に変換して、列を並べ替え
cols = ['sex', 'alb_min', 'alb_max']
cols.extend(df_outpatient.columns[1:-2])
df_outpatient = df_outpatient[cols]
df_outpatient['sex'] = np.concatenate([np.repeat('M', 19), np.repeat('F', 19)])

# 「-」と「・」を数値の「0」に置き換え
df_outpatient = df_outpatient.replace('-', 0)
df_outpatient = df_outpatient.replace('･', 0)
df_outpatient[df_outpatient.columns[1:]
              ] = df_outpatient[df_outpatient.columns[1:]].astype('float32')

# 月次発生件数への変換
cols = df_outpatient.columns[3:]
df_outpatient[cols] = df_outpatient[cols] * 365 * 6 / 7 / 12

# print(df_outpatient)

# -----------
# 月次新入院発生率（回数）
# -----------


def get_pop_num(df_pop, sex, alb_min, alb_max):
    more_alb_min = (df_pop.alb_min >= alb_min)
    less_alb_max = (df_pop.alb_max <= alb_max)
    return df_pop.loc[more_alb_min & less_alb_max, sex].sum()
# print()
# print(get_pop_num(df_pop, 'M', 85, 130))


# 各人数を人口で割る
cols = df_admission.columns[3:]

for i in df_admission.index:
    sex = df_admission.loc[i, 'sex']
    alb_min = df_admission.loc[i, 'alb_min']
    alb_max = df_admission.loc[i, 'alb_max']
    df_admission.loc[i, cols] = df_admission.loc[i, cols] / \
        get_pop_num(df_pop, sex, alb_min, alb_max)
# print(df_admission)

# ファイルの保存
df_admission.to_csv('./public_stats/processed/ps_admission.csv', index=False)

# 年齢別入院回数の可視化
df = df_admission[df_admission.alb_max <= 74]

fig = plt.figure()
ax = fig.subplots()

df_M = df.loc[df.sex == 'M']
x = (df_M.alb_min + df_M.alb_max) / 2
y = df_M[cols].sum(axis=1)
ax.plot(x, y*12, c='b', label='男性, 月次発生回数')                   # 月次発生回数に変換
ax.plot(x, 1-(1-y)**12, c='b', ls='--', label='男性, 年次発生率')    # 月次発生率を年次に変換

df_F = df.loc[df.sex == 'F']
x = (df_F.alb_min + df_F.alb_max) / 2
y = df_F[cols].sum(axis=1)
ax.plot(x, y*12, c='r', label='女性, 月次発生回数')                 # 月次発生回数に変換
ax.plot(x, 1-(1-y)**12, c='r', ls='--', label='女性, 年次発生率')  # 月次発生率を年次に変換

ax.set_xlabel('年齢')
ax.legend(loc='best')
ax.set_title('年齢別入院回数 月次発生回数 & 年次発生率', fontsize=15)

plt.savefig('0211.png')

# ----------
# 月次外来発生率（回数）
# ----------
cols = df_outpatient.columns[3:]

for i in df_outpatient.index:
    sex = df_outpatient.loc[i, 'sex']
    alb_min = df_outpatient.loc[i, 'alb_min']
    alb_max = df_outpatient.loc[i, 'alb_max']
    df_outpatient.loc[i, cols] = df_outpatient.loc[i, cols] / \
        get_pop_num(df_pop, sex, alb_min, alb_max)
df_outpatient.to_csv('./public_stats/processed/ps_outpatient.csv', index=False)

# 年齢別外来回数の可視化
df = df_outpatient[df_outpatient.alb_max <= 74]

fig = plt.figure()
ax = fig.subplots()

df_M = df.loc[df.sex == 'M']
x = (df_M.alb_min + df_M.alb_max) / 2
y = df_M[cols].sum(axis=1) * 12      # 月次発生回数を年次に変換
ax.plot(x, y, c='b', label='男性')

df_F = df.loc[df.sex == 'F']
x = (df_F.alb_min + df_F.alb_max) / 2
y = df_F[cols].sum(axis=1) * 12      # 月次発生回数を年次に変換
ax.plot(x, y, c='r', label='女性')

ax.set_xlabel('年齢')
ax.legend(loc='best')
ax.set_title('年齢別年次外来回数', fontsize=15)

plt.savefig('0211b.png')
# plt.show()

# -----------
# 退院患者平均在院日数
# -----------

# 読み込み
df_days = pd.read_csv('./public_stats/original/ps_days.csv', skiprows=13)

cols = df_days.columns[2:]
df_days = df_days[cols]
df_days = df_days.drop(cols[2], axis=1)

cols = ['sex', 'alb']
cols.extend(df_admission.columns[3:])
df_days.columns = cols

# 年齢区分を、年齢の最小値 alb_min と最大値 alb_max に置き換えて、alb を削除
alb_min = [0, 1]
alb_min.extend(np.arange(18)*5+5)
alb_min.extend(alb_min)
df_days['alb_min'] = alb_min
alb_max = [0, 4]
alb_max.extend(np.arange(17)*5+9)
alb_max.extend([130])
alb_max.extend(alb_max)
df_days['alb_max'] = alb_max
del df_days['alb']

# sex の値を (M,F) に変換して、列を並べ替え
cols = ['sex', 'alb_min', 'alb_max']
cols.extend(df_days.columns[1:-2])
df_days = df_days[cols]
df_days['sex'] = np.concatenate([np.repeat('M', 20), np.repeat('F', 20)])

# 「-」と「・」を数値の「0」に置き換え
df_days = df_days.replace('-', 0)
df_days = df_days.replace('･', 0)
df_days[df_days.columns[1:]] = df_days[df_days.columns[1:]].astype('float32')

df_days = df_days[df_days.alb_min != 90].copy()
df_days.loc[df_days.alb_max == 89, 'alb_max'] = 130
df_days = df_days.reset_index()
del df_days['index']

df_days.to_csv('./public_stats/processed/ps_days.csv', index=False)

# print(df_days)

# 平均在院日数の可視化
cols = df_admission.columns[3:]
is_F = (df_admission.sex == 'F')
is_age_10 = (df_admission.alb_min == 10)

df_admission.loc[is_F & is_age_10, cols].sum().sum()


def calc_days_avg(df_admission, df_days, delta):
    df_admission_adj = df_admission[cols] + delta
    days = (df_admission_adj * df_days[cols]
            ).sum(axis=1) / df_admission_adj.sum(axis=1)
    df_days_avg = pd.concat(
        [df_days[['sex', 'alb_min', 'alb_max']], days], axis=1)
    df_days_avg.columns = ['sex', 'alb_min', 'alb_max', 'days']
    return df_days_avg


df_days_avg = calc_days_avg(df_admission, df_days, 0)
df_days_avg3 = calc_days_avg(df_admission, df_days, 0.1**3)
df_days_avg6 = calc_days_avg(df_admission, df_days, 0.1**6)


def add_chart(ax, df, sex, chart, color, label, ls='-'):
    df_sex = df.loc[df.sex == sex]
    x = (df_sex.alb_min + df_sex.alb_max) / 2
    y = df_sex.days
    if chart == 'plot':
        ax.plot(x, y, c=color, label=label, ls=ls)
    else:
        ax.scatter(x, y, c=color, label=label)


df = df_days_avg[df_days_avg.alb_max <= 74]
df6 = df_days_avg6[df_days_avg6.alb_max <= 74]
df3 = df_days_avg3[df_days_avg3.alb_max <= 74]

fig = plt.figure(figsize=(8, 4))
fig.suptitle('Average Hospital Days', fontsize=15)
# 男性
ax1 = fig.add_subplot(121)
add_chart(ax1, df, 'M', 'scatter', 'b', r'$\Delta=0$')
add_chart(ax1, df6, 'M', 'plot', 'b', r'$\Delta=0.1^6$')
add_chart(ax1, df3, 'M', 'plot', 'b', r'$\Delta=0.1^3$', ls='--')
ax1.legend(loc='best')
ax1.set_xlabel('Age')
# 女性
ax2 = fig.add_subplot(122)
add_chart(ax2, df, 'F', 'scatter', 'r', r'$\Delta=0$')
add_chart(ax2, df6, 'F', 'plot', 'r', r'$\Delta=0.1^6$')
add_chart(ax2, df3, 'F', 'plot', 'r', r'$\Delta=0.1^3$', ls='--')
ax2.legend(loc='best')
ax2.set_xlabel('Age')

ax2.annotate('Age 10-14 \nAveraged by 0', xy=[12, 12], xytext=[12, 15],
             arrowprops=dict(shrink=0, width=1, headwidth=5,
                             headlength=5, connectionstyle='arc3',
                             facecolor='k', edgecolor='k')
             )

plt.savefig('0211c.png')
plt.show()
