# 予測精度の評価 ~ 混同行列と性能評価指標

import gc
import math
import pickle
import csv
import time
import sys
import pickle

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns
import scipy as sp

from mylibs import mylib1 as mylib1
from mylibs import mylib2 as mylib2
from mylibs import mylib3 as mylib3
from mylibs import mylib4 as mylib4

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 6
pd.options.display.max_columns = 12

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# 性能評価指標の計算


def load_bases():
    # Load dict_bp
    f = open('./pseudo_medical/processed/incl_bp/dict_bp.binaryfile',
             'rb')  # rb: Read Binary
    dict_bp = pickle.load(f)
    f.close()
    # Load opt_result
    # rb: Read Binary
    f = open('./pseudo_medical/processed/incl_bp/opt_result.binaryfile', 'rb')
    opt_result = pickle.load(f)
    f.close()
    # Load df_summary
    df_summary = pd.read_csv(
        './pseudo_medical/processed/incl_bp/df_summary_with_CI.csv')
    return (dict_bp, opt_result, df_summary)


(dict_bp, opt_result, df_summary) = load_bases()

sex, x = 'M', 60
w = opt_result.x[0]


def predict_rate(df_summary, dict_bp, w, exp_or_out, sex, x):
    baseline = mylib4.get_baseline(df_summary, sex, x)
    bp_classes = dict_bp[sex][exp_or_out]['class'][x].astype('f8')
    return baseline * np.exp(w * bp_classes)


def TP(df_summary, dict_bp, w, sex, x):
    rates = predict_rate(df_summary, dict_bp, w, 'out', sex, x)
    return rates.sum()


def FP(df_summary, dict_bp, w, sex, x):
    rates_exp = predict_rate(df_summary, dict_bp, w, 'exp', sex, x)
    return rates_exp.sum() - TP(df_summary, dict_bp, w, sex, x)


def FN(df_summary, dict_bp, w, sex, x):
    rates = predict_rate(df_summary, dict_bp, w, 'out', sex, x)
    return len(rates) - rates.sum()


def TN(df_summary, dict_bp, w, sex, x):
    exp = len(predict_rate(df_summary, dict_bp, w, 'exp', sex, x))
    tn = exp - TP(df_summary, dict_bp, w, sex, x) - FP(df_summary,
                                                       dict_bp, w, sex, x) - FN(df_summary, dict_bp, w, sex, x)
    return tn


tp = TP(df_summary, dict_bp, w, sex, x)
fp = FP(df_summary, dict_bp, w, sex, x)
fn = FN(df_summary, dict_bp, w, sex, x)
tn = TN(df_summary, dict_bp, w, sex, x)
exp = len(predict_rate(df_summary, dict_bp, w, 'exp', sex, x))

# print(tp, fp, fn, tn)
# print(tp + fp + fn + tn, exp)

# 0.4480081341366288 22.55199186586337 22.55199186586337 1219.4480081341367
# 1265.0 1265

dict_confusion = {'M': {}, 'F': {}}
for sex in ['M', 'F']:
    for x in np.arange(65):
        dict_confusion[sex][x] = {}
        dict_confusion[sex][x]['TP'] = TP(df_summary, dict_bp, w, sex, x)
        dict_confusion[sex][x]['FP'] = FP(df_summary, dict_bp, w, sex, x)
        dict_confusion[sex][x]['FN'] = FN(df_summary, dict_bp, w, sex, x)
        dict_confusion[sex][x]['TN'] = TN(df_summary, dict_bp, w, sex, x)

for sex in ['M', 'F']:
    for x in np.arange(65):
        tp = dict_confusion[sex][x]['TP']
        fp = dict_confusion[sex][x]['FP']
        fn = dict_confusion[sex][x]['FN']
        tn = dict_confusion[sex][x]['TN']
        n = tp + fp + fn + tn
        dict_confusion[sex][x]['TP_ratio'] = tp / n
        dict_confusion[sex][x]['FP_ratio'] = fp / n
        dict_confusion[sex][x]['FN_ratio'] = fn / n
        dict_confusion[sex][x]['TN_ratio'] = tn / n


def accuracy(dict_confusion, sex, x):
    tp = dict_confusion[sex][x]['TP']
    fp = dict_confusion[sex][x]['FP']
    fn = dict_confusion[sex][x]['FN']
    tn = dict_confusion[sex][x]['TN']
    if (tp + fp + fn + tn) > 0:
        return (tp + tn) / (tp + fp + fn + tn)
    else:
        return None


def sensitivity(dict_confusion, sex, x):
    tp = dict_confusion[sex][x]['TP']
    fn = dict_confusion[sex][x]['FN']
    if (tp + fn) > 0:
        return tp / (tp + fn)
    else:
        return None


def specificity(dict_confusion, sex, x):
    fp = dict_confusion[sex][x]['FP']
    tn = dict_confusion[sex][x]['TN']
    if (fp + tn) > 0:
        return tn / (fp + tn)
    else:
        return None


def PPV(dict_confusion, sex, x):
    tp = dict_confusion[sex][x]['TP']
    fp = dict_confusion[sex][x]['FP']
    if (tp + fp) > 0:
        return tp / (tp + fp)
    else:
        return None


def NPV(dict_confusion, sex, x):
    fn = dict_confusion[sex][x]['FN']
    tn = dict_confusion[sex][x]['TN']
    if (fn + tn) > 0:
        return tn / (fn + tn)
    else:
        return None


def Fscore(dict_confusion, sex, x):
    tp = dict_confusion[sex][x]['TP']
    fp = dict_confusion[sex][x]['FP']
    fn = dict_confusion[sex][x]['FN']
    if (2 * tp + fn + fp) > 0:
        return 2 * tp / (2 * tp + fn + fp)
    else:
        return None


for sex in ['M', 'F']:
    for x in np.arange(65):
        dict_confusion[sex][x]['accuracy'] = accuracy(dict_confusion, sex, x)
        dict_confusion[sex][x]['sensitivity'] = sensitivity(
            dict_confusion, sex, x)
        dict_confusion[sex][x]['specificity'] = specificity(
            dict_confusion, sex, x)
        dict_confusion[sex][x]['PPV'] = PPV(dict_confusion, sex, x)
        dict_confusion[sex][x]['NPV'] = NPV(dict_confusion, sex, x)
        dict_confusion[sex][x]['Fscore'] = Fscore(dict_confusion, sex, x)

# print(dict_confusion['M'][60])
# {'TP': 0.4480081341366288, 'FP': 22.55199186586337, 'FN': 22.55199186586337, 'TN': 1219.4480081341367, 'TP_ratio': 0.0003541566277759912, 'FP_ratio': 0.017827661554042192, 'FN_ratio': 0.017827661554042192,
#     'TN_ratio': 0.9639905202641397, 'accuracy': 0.9643446768919157, 'sensitivity': 0.019478614527679513, 'specificity': 0.9818421965653275, 'PPV': 0.019478614527679513, 'NPV': 0.9818421965653275, 'Fscore': 0.019478614527679513}


def get_values(dict_confusion, sex, indicator):
    values = []
    for x in np.arange(65):
        values.append(dict_confusion[sex][x][indicator])
    return values


sex, indicator = 'M', 'accuracy'
# print(get_values(dict_confusion, sex, indicator)[:5])
# [0.9811044473641141, 0.9970524712099581, 0.9825708584112463, 0.9913957464645334, 0.9935876705441492]


def plot_indicator(ax, dict_confusion, indicator):
    X = np.arange(65)
    Y = get_values(dict_confusion, 'M', indicator)
    ax.plot(X, Y, c='b', label='Male')
    Y = get_values(dict_confusion, 'F', indicator)
    ax.plot(X, Y, c='r', label='Female')
    ax.set_title(indicator)
    ax.legend(loc='best')
    ax.set_xlabel('Age')
    return ax


fig = plt.figure(figsize=(6, 6))
axes = fig.subplots(2, 2, sharex=True, sharey=True)
axes[0][0] = plot_indicator(axes[0][0], dict_confusion, 'TP_ratio')
axes[0][1] = plot_indicator(axes[0][1], dict_confusion, 'FP_ratio')
axes[1][0] = plot_indicator(axes[1][0], dict_confusion, 'FN_ratio')
axes[1][1] = plot_indicator(axes[1][1], dict_confusion, 'TN_ratio')

plt.savefig("0431a.png")

# plt.show()

fig = plt.figure(figsize=(9, 6))
axes = fig.subplots(2, 3, sharex=True, sharey=True)
axes[0][0] = plot_indicator(axes[0][0], dict_confusion, 'accuracy')
axes[0][1] = plot_indicator(axes[0][1], dict_confusion, 'sensitivity')
axes[0][2] = plot_indicator(axes[0][2], dict_confusion, 'specificity')
axes[1][0] = plot_indicator(axes[1][0], dict_confusion, 'PPV')
axes[1][1] = plot_indicator(axes[1][1], dict_confusion, 'NPV')
axes[1][2] = plot_indicator(axes[1][2], dict_confusion, 'Fscore')

plt.savefig("0431b.png")

plt.show()


# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
