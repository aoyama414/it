# 死亡情報以外の擬似生成
# ファイルの保存なし

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import gc

import mylibs.mylib1 as mylib1

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# 引数設定
df_birth = pd.read_csv('./public_stats/processed/ipss_birth.csv')
start_study_t = 2010    # 分析開始時点 (2010年1月)
end_study_t = 2019.999  # 分析終了時点 (2019年12月)
mu = 10
N = 5000            # N 人の加入者を生成する。
family_ratio = 0.3  # 全体の内、被扶養者の占める割合
df_mortality = pd.read_csv('./public_stats/processed/ipss_mortality.csv')

# df_info の作成
df_info = mylib1.create_df_info(df_birth,
                                df_mortality,
                                start_study_t,
                                end_study_t,
                                mu,
                                N,
                                family_ratio)

print(df_info)
