# 男女別・年齢別観察死亡率の推定

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns

import mylibs.mylib1 as mylib1

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# 引数設定
df_birth = pd.read_csv('./public_stats/processed/ipss_birth.csv')
start_study_t = 2010    # 分析開始時点 (2010年1月)
end_study_t = 2019.999  # 分析終了時点 (2019年12月)
mu = 10
N = 10000            # N 人の加入者を生成する。
family_ratio = 0.3   # 全体の内、被扶養者の占める割合
df_mortality = pd.read_csv('./public_stats/processed/ipss_mortality.csv')

# 100 倍死亡率のキャップ計算と概念図
fig = plt.figure(figsize=(8, 4))

# 男性
ax_M = fig.add_subplot(121)
ax_M.plot(df_mortality.alb, df_mortality.M, c='b', ls='--', label='TMR=1')
df_mortality['M'] = df_mortality.M * 100
df_mortality.loc[(df_mortality.M > 1), 'M'] = 1
ax_M.plot(df_mortality.alb, df_mortality.M, c='b', ls='-', label='TMR=100')
ax_M.legend()
ax_M.set_xlabel('Age')

# 女性
ax_F = fig.add_subplot(122)
ax_F.plot(df_mortality.alb, df_mortality.F, c='r', ls='--', label='TMR=1')
df_mortality['F'] = df_mortality.F * 100
df_mortality.loc[(df_mortality.F > 1), 'F'] = 1
ax_F.plot(df_mortality.alb, df_mortality.F, c='r', ls='-', label='TMR=100')
ax_F.legend()
ax_F.set_xlabel('Age')

fig.suptitle('100倍の死亡率')

plt.savefig('0143.png')

# df_info の作成
df_info = mylib1.create_df_info(df_birth, df_mortality,
                                start_study_t, end_study_t,
                                mu, N, family_ratio)

# 年月（文字列）の数値化
col_ts = ['start_obs_t',  'end_obs_t',  'birth_t']
col_yms = ['start_obs_ym', 'end_obs_ym', 'birth_ym']
for (col_t, col_ym) in zip(col_ts, col_yms):
    df_info[col_t] = df_info[col_ym].apply(mylib1.ym_to_t)

# ALB テーブルの作成
# npa_obs_ym は観察年月の配列
npa_obs_ym = mylib1.create_npa_obs_ym(start_study_t, end_study_t)

df_alb_table = df_info.copy()

npa_birth_t = np.array(df_info['birth_t'])
for ym in npa_obs_ym:
    t = mylib1.ym_to_t(ym)
    df_alb_table[ym] = (t - npa_birth_t) // 1
    df_alb_table[ym] = df_alb_table[ym].astype('int8')

# 月次エクスポージャテーブルの作成:単位は人月
# ある観察年月で生存し、かつ観察可能であれば1を付し、
# そうでなければ0を付す
df_exposure_table = df_alb_table.copy()
for ym in npa_obs_ym:
    # Boolean values for Start_obs_t
    bs = (df_exposure_table['start_obs_t'] <= mylib1.ym_to_t(ym))
    # Boolean values for End_obs_t
    be = (mylib1.ym_to_t(ym) <= df_exposure_table['end_obs_t'])
    df_exposure_table[ym] = (bs & be) * 1

# print(df_exposure_table)
# 月次死亡テーブルの作成
# 死亡情報は、ある観察年月で死亡したら1、そうでなければ0を付す
event = 'death'
N = len(df_alb_table)
df_event_table = df_alb_table.copy()

df_event_table[npa_obs_ym] = np.zeros((N, len(npa_obs_ym)))
i_of_events = df_event_table[df_event_table[event] == 1].index
for i in i_of_events:
    event_ym = df_event_table.loc[i, 'end_obs_ym']
    df_event_table.loc[i, event_ym] = 1

# print(df_event_table)
# 男女別・ALB別にエクスポージャと死亡数を集計
# 集計用の枠を用意、この時点では0
cols = ['sex', 'alb', 'exposure', event]
df_summary = pd.DataFrame(np.zeros((200, 4)), columns=cols)
df_summary['sex'] = np.concatenate([np.repeat('M', 100), np.repeat('F', 100)])
df_summary['alb'] = np.concatenate([np.arange(100), np.arange(100)])
types = {'alb': 'int8', 'exposure': 'int32', event: 'int8'}
df_summary = df_summary.astype(types)

for sex in ['M', 'F']:
    for alb in np.arange(100):
        # print(sex, alb)
        sex_filter = (df_alb_table['sex'] == sex).values.reshape(N, 1) * 1
        alb_filter = (df_alb_table[npa_obs_ym] == alb).values * 1
        i_smry = (sex == 'F') * 100 + alb
        df_summary.loc[i_smry, 'exposure'] = (
            df_exposure_table[npa_obs_ym].values
            * sex_filter * alb_filter
        ).sum().sum()
        df_summary.loc[i_smry, event] = (df_event_table[npa_obs_ym].values
                                         * sex_filter
                                         * alb_filter).sum().sum()

# 月次死亡率の点推定・区画推定
e = 0.05
df_summary['obs_rate'] = df_summary[event] / df_summary['exposure']
df_summary['LCL'] = mylib1.calc_LCL(df_summary['exposure'],
                                    df_summary[event], e)
df_summary['UCL'] = mylib1.calc_UCL(df_summary['exposure'],
                                    df_summary[event], e)
# print(df_summary.iloc[:60])

# 真の月次死亡率を集計表に追加
df_summary['true_rate'] = np.zeros(len(df_summary))
for sex in ['M', 'F']:
    for alb in np.arange(100):
        i_smry = (sex == 'F') * 100 + alb
        df_summary.loc[i_smry, 'true_rate'] \
            = mylib1.get_mortality(df_mortality, sex, alb)
# print(df_summary.iloc[:60])

# 観察死亡率と真の死亡率の可視化による比較
df_summary_M = df_summary[df_summary['sex'] == 'M']
df_summary_F = df_summary[df_summary['sex'] == 'F']
fig = plt.figure(figsize=(8, 4))
fig.suptitle('Observed Monthly Mortality (TMR = 100)', fontsize=15)

ax1 = fig.add_subplot(121)
ax1.plot(df_summary_M['alb'][:60], df_summary_M['obs_rate'][:60], '-', c='b')
ax1.plot(df_summary_M['alb'][:60], df_summary_M['LCL'][:60], '--', c='b')
ax1.plot(df_summary_M['alb'][:60], df_summary_M['UCL'][:60], '--', c='b')
ax1.plot(df_summary_M['alb'][:60], df_summary_M['true_rate'][:60], '-', c='k')
ax1.set_title('Male')
ax1.set_xlabel('Age')

ax2 = fig.add_subplot(122, sharey=ax1)
ax2.plot(df_summary_F['alb'][:60], df_summary_F['obs_rate'][:60], '-', c='r')
ax2.plot(df_summary_F['alb'][:60], df_summary_F['LCL'][:60], '--', c='r')
ax2.plot(df_summary_F['alb'][:60], df_summary_F['UCL'][:60], '--', c='r')
ax2.plot(df_summary_F['alb'][:60], df_summary_F['true_rate'][:60], '-', c='k')
ax2.set_title('Female')
ax2.set_xlabel('Age')

plt.tight_layout()
plt.subplots_adjust(top=0.85)

plt.savefig('0143b.png')

plt.show()
