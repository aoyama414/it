# 1-1 「日本版死亡データベース」の利用

# グラフを移動拡大縮小したい場合
# %matplotlib notebook
# グラフをインラインで表示
# %matplotlib inline

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# 表示する行の数を設定
pd.options.display.max_rows = 6

# matplotlib のフォントを設定
#plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# ALB と ANB の違いの概念図

# ---------------------------
# 主な引数	説明
# figsize	Figureのサイズ。横縦を(float, float)で指定。
# dpi	dpi。整数で指定。
# facecolor	図の背景色。Jupyterだと透過色になってたりする。
# linewidth	図の外枠の太さ。デフォルトは0（枠なし）。
# edgecolor	図の枠の色。linewidthを指定しないと意味ない。
# subplotpars	AxesSubplotの基準を指定する。
# tight_layout	Trueにするとオブジェクトの配置が自動調整される。
# constrained_layout	Trueにするとオブジェクトの配置が自動調整される。
# ---------------------------
fig = plt.figure(figsize=(8, 3),
                 facecolor='skyblue',
                 linewidth=10)  # 横縦 8 × 3
# ---------------------------
# 主な引数	説明
# title	グラフのタイトル。
# facecolor	グラフの背景色。fcでも可。
# alpha	グラフの透明度を0～1で指定。
# zorder	オブジェクトが重なっていた時この値が大きい方が前面に描画される。
# xlabel	横軸名。
# xmargin	データの最小値・最大値から横軸の最小値・最大値までのサイズ。
# xlim	横軸の最小値・最大値を(float, float)で指定。
# xticks	横軸の目盛線を表示する値をリストで指定。
# xticklabels	横軸の目盛のラベルをリストで指定。
# sharex	横軸を共有するAxesを指定。
# ---------------------------
# add_subplot(nrows, ncols, index)を実行すると、
# 無地の付箋Axes（正確にはAxesSubplotオブジェクト）が戻り値として返される。
# nrows，ncols，indexは位置と大きさを決めるパラメータで、整数を入れる。
# 台紙を縦nrows分割・横ncols分割したうちのindex番目の位置に配置されたAxesが返される。
# グラフを1つしか作らないときは(1, 1, 1)で良い。
ax = fig.add_subplot(111)

# s='' ⇒ ''
# ---------------------------
# annotateの主な引数
# s	注釈文章の内容
# xy	終点の位置
# xytext	始点の位置(テキストの位置)
# arrowprops	始点と終点間を結ぶ矢印の設定
# 矢印の作成
# ---------------------------

ax.annotate('',
            xytext=[39, 0],
            xy=[41.5, 0],
            arrowprops=dict(arrowstyle='->', color='k'))
ax.text(41.6, 0, r'Age $(y)$', va='center', ha='center')

# ANB：四捨五入

# ---------------------------
# plot::::
# 第一引数x（横軸の値）は省略可能。
# 省略すると[0, 1, 2, ..., N-1]（x=range(len(y))）として扱われる。
# 第三引数
# 主な引数	説明
# label	プロットのラベル。凡例に表示される。
# color	折れ線の色。cでも可。
# dashes	折れ線の実線部分と空白部分の長さをリストで指定。
# linestyle	折れ線の線種。lsでも可。dashesが指定されていると無効。
# linewidth	折れ線の太さ。lwでも可。
# alpha	透明度を0～1で指定。
# zorder	オブジェクトが重なっていた時この値が大きい方が前面に描画される。
# arker	マーカーの形状。Noneでマーカーなし。
# markersize	マーカーのサイズ。msでも可。
# markerfacecolor	マーカーの色。mfcでも可。
# markeredgewidth	マーカーの縁の太さ。mewでも可。
# markeredgecolor	マーカーの縁の色。mecでも可。
# ---------------------------
ax.plot([39.5, 40.25], [0.5, 0.5], c='k') # 上の線
ax.plot([39.5, 39.5], [0, 0.5], c='k') # 左線
ax.plot([40.25, 40.5], [0.5, 0], c='k') # 右の斜め線
ax.text(40, 0.75, 'ANB=40', va='center', ha='center')

# ALB：切り捨て
ax.plot([40, 40.75], [-0.5, -0.5], c='k') # 下の線
ax.plot([40, 40], [0, -0.5], c='k') # 左線
ax.plot([40.75, 41], [-0.5, 0], c='k') # 右の斜め線
ax.text(40.5, -0.75, 'ALB=40', va='center', ha='center')

# Age
ax.text(39.5, -0.2, '39.5', va='center', ha='center')
ax.text(40,    0.2, '40',   va='center', ha='center')
ax.text(40.5, -0.2, '40.5', va='center', ha='center')
ax.text(41,    0.2, '41',   va='center', ha='center')
X = np.arange(4) / 2 + 39.5
Y = np.zeros(4)
ax.scatter(X, Y, c='k', marker='|')

ax.set_xlim(38.5, 42)
ax.set_xticklabels('')
ax.set_ylim(-1, 1)
ax.set_yticklabels('')
ax.tick_params(top=False,
               bottom=False,
               left=False,
               right=False)
ax.set_title('Concept of ANB and ALB')

fig.savefig("0111.png")
plt.show()
