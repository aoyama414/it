# 傷病条件付き診療行為

from scipy.stats import gamma
import gc
import csv
import time

from mylibs import mylib1
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import sys

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 10

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# 準備 & 作成したデータの読み込み
df_info = pd.read_csv('./pseudo_medical/records/excl_bp/info.csv')
df_commons = pd.read_csv('./pseudo_medical/records/excl_bp/commons.csv')
df_diseases = pd.read_csv('./pseudo_medical/records/excl_bp/diseases.csv')
df_treatments = pd.read_csv('./pseudo_medical/records/excl_bp/treatments.csv')

# 分析開始時点 (2010年1月)
start_study_t = 2010
# 分析終了時点 (2019年12月)
end_study_t = 2019.999

# データの絞り込み
# ここでは、がんの定義を ICD-10 の C00-D09 とする。
in_cancer = ('C00' <= df_diseases['icd10_code']) & \
            (df_diseases['icd10_code'] <= 'D09')
df_cancers = df_diseases[in_cancer]
# 手術 K コードを含むデータのみに絞り込む
contain_K = df_treatments['treatment_code'].str.contains('K')
df_surgs = df_treatments[contain_K]
# rid をキーに inner join する
df_cancer_surgs = pd.merge(df_cancers, df_surgs, on=[
                           'iid', 'rid'], how='inner')

print(len(df_cancers), len(df_surgs), len(df_cancer_surgs))
print(df_cancer_surgs.head())

# がん入院・がん外来
# がん入院
df_commons_inpatient = df_commons[df_commons['receipt_type'] == 'inpatient']
df_cancer_inpatient = pd.merge(df_cancers, df_commons_inpatient, on=[
                               'iid', 'rid'], how='inner')
print()
print(len(df_cancer_inpatient))
print(df_cancer_inpatient.head())

# がん外来
df_commons_outpatient = df_commons[df_commons['receipt_type'] == 'outpatient']
df_cancer_outpatient = pd.merge(df_cancers, df_commons_outpatient, on=[
                                'iid', 'rid'], how='inner')
print()
print(len(df_cancer_outpatient))
print(df_cancer_outpatient.head())


# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
