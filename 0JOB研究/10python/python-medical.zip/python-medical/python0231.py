# 傷病条件付き新入院発生率・新入院平均在院日数

from scipy.stats import gamma
import gc
import csv
import time

from mylibs import mylib1
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import sys

# 再帰回数を増加：デフォルト1000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 10

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# 準備 & 作成したデータの読み込み
df_info = pd.read_csv('./pseudo_medical/records/excl_bp/info.csv')
df_commons = pd.read_csv('./pseudo_medical/records/excl_bp/commons.csv')
df_diseases = pd.read_csv('./pseudo_medical/records/excl_bp/diseases.csv')

# 分析開始時点 (2010年1月)
start_study_t = 2010
# 分析終了時点 (2019年12月)
end_study_t = 2019.999

npa_obs_ym = mylib1.create_npa_obs_ym(start_study_t, end_study_t)
df_info = mylib1.convert_ym_to_t_in_info(df_info)
df_alb_table = mylib1.create_alb_table_from_info(npa_obs_ym, df_info)
df_exposure_table = mylib1.create_exposure_table_from_alb_table(
    npa_obs_ym, df_alb_table)

# print(df_alb_table)
# print()
# print(df_exposure_table)
# print()
# print(df_diseases.head())

# event table の作成
df_event_table = df_exposure_table.copy()
df_event_table[npa_obs_ym] = 0
# がん（ICD-10コード：C00-D09）のみに限定
in_cancer = ('C00' <= df_diseases['icd10_code']) \
    & (df_diseases['icd10_code'] <= 'D09')
df_cancers = df_diseases[in_cancer]

# print(df_cancers)
# print(len(df_cancers)) # 8913 本より少ない
# print(len(df_cancers['rid'].unique())) # 8913 本より少ない
# print(df_commons.head())

# 入院レコードのみに限定
df_hosps = df_commons[df_commons['receipt_type'] == 'inpatient']

# print(df_hosps) # 2079 本より多い

# rid で内部結合 (inner join) する。
# iid が両方に存在するので、カラム名が iid_x と iid_y になってしまう。
df_cancer_hosps = pd.merge(df_cancers, df_hosps, on='rid', how='inner')

# print(df_cancer_hosps) # 350 本より少ない

del df_cancer_hosps['iid_y']
df_cancer_hosps.columns = ['iid', 'rid', 'first_ym',
                           'icd10_code', 'ym', 'receipt_type', 'admission_ym', 'days']

# print(df_cancer_hosps)

dfg = df_cancer_hosps.groupby(['iid', 'admission_ym'])
df_cancer_admissions = dfg['days'].sum().reset_index()

# print(df_cancer_admissions)
# print(len(df_cancer_admissions))
# print(len(df_cancer_admissions['iid'].unique()))

for ym in npa_obs_ym:
    is_ym = (df_cancer_admissions['admission_ym'] == ym)
    iid_in_ym = df_cancer_admissions.loc[is_ym, 'iid'].values
    in_iid_in_ym = df_event_table['iid'].isin(iid_in_ym)
    df_event_table.loc[in_iid_in_ym, ym] = 1

# print(df_event_table.head())
# print(df_event_table[npa_obs_ym].sum().sum())

# ALB ごとにエクスポージャとイベント件数を集計
df_summary = mylib1.count_exposure_and_event(npa_obs_ym, df_alb_table,
                                             df_exposure_table, df_event_table)

# print(df_summary)
df_summary['alb_mid'] = df_summary.alb // 5 * 5 + 2
# print(df_summary.head(10))
# FutureWarning: Indexing with multiple keys
# (implicitly converted to a tuple of keys) will be deprecated, use a list instead
# 対応　['exposure', 'event'] ⇒ [['exposure', 'event']]
df_summary_5x = df_summary.groupby(['sex', 'alb_mid'])[[
    'exposure', 'event']].sum()
df_summary_5x = mylib1.estimate_rate(df_summary_5x, e=0.05)
df_summary_5x = df_summary_5x.reset_index()
# print(df_summary_5x)

# 真の月次がん入院発生率の作成


def get_true_cancer_admission_rate(df_true_hosp_rate, sex, alb):
    is_sex = (df_true_hosp_rate.sex == sex)
    more_alb_min = (df_true_hosp_rate.alb_min <= alb)
    less_alb_max = (alb <= df_true_hosp_rate.alb_max)
    ix = is_sex & more_alb_min & less_alb_max
    return df_true_hosp_rate.loc[ix, 'C00'].values[0]


df_true_hosp_rate = pd.read_csv('./public_stats/processed/ps_admission.csv')
# print(df_true_hosp_rate.head())
df_summary_5x['true_rate'] = 0
for i in df_summary_5x.index:
    (sex, alb) = df_summary_5x.loc[i, ['sex', 'alb_mid']]
    df_summary_5x.loc[i, 'true_rate'] = get_true_cancer_admission_rate(
        df_true_hosp_rate, sex, alb)

# print(df_summary_5x)

df = df_summary_5x.loc[(df_summary_5x.alb_mid < 65)]
df_M = df.loc[df.sex == 'M']
df_F = df.loc[df.sex == 'F']


def plot_rates(ax, df_sex, color):
    ax.scatter(df_sex.alb_mid, df_sex.obs_rate,
               c=color, s=8, label='Observed rates')
    ax.plot(df_sex.alb_mid, df_sex.LCL, c=color,
            ls='--', lw=1, label=r'$95\% CI$')
    ax.plot(df_sex.alb_mid, df_sex.UCL, c=color, ls='--', lw=1)
    ax.plot(df_sex.alb_mid, df_sex.true_rate,
            c='k', ls='-', lw=1, label='True rates')
    ax.legend(loc='upper left')
    ax.set_ylim(0, 0.007)


fig = plt.figure(figsize=(8, 4))
ax1 = fig.add_subplot(121)
plot_rates(ax1, df_M, 'b')
ax1.set_title('Male')
ax1.set_xlabel('Age')

ax2 = fig.add_subplot(122)
plot_rates(ax2, df_F, 'r')
ax2.set_title('Female')
ax2.set_xlabel('Age')

fig.suptitle('Cancer Admission Rates (Monthly)')

plt.savefig('0231.png')

# plt.show()

# がん新入院平均在院日数
df_days_table = df_event_table.copy()

# 入院日数
for i in df_cancer_admissions.index:
    iid = df_cancer_admissions.loc[i, 'iid']
    ym = df_cancer_admissions.loc[i, 'admission_ym']
    days = df_cancer_admissions.loc[i, 'days']
    i_for_df_days_table = df_days_table[df_days_table['iid'] == iid].index[0]
    df_days_table.loc[i_for_df_days_table, ym] = days
ym_cols = df_days_table.columns[10:]

# print(df_days_table.head())
# print()
# print(df_days_table[ym_cols].max())

# ALB ごとに在院日数を集計
# print(df_alb_table)
# print(ym_cols)


def get_days_sum(df_alb_table, df_days_table, sex, alb):
    ym_cols = df_alb_table.columns[10:]
    is_sex = np.array(df_days_table.sex == sex).reshape(len(df_days_table), 1)
    is_alb = np.array(df_alb_table[ym_cols] == alb)
    return (is_sex * is_alb * df_days_table[ym_cols]).sum().sum()


df_summary['total_days'] = 0  # 列の作成
for i in df_summary.index:
    (sex, alb) = df_summary.loc[i, ['sex', 'alb']]
    df_summary.loc[i, 'total_days'] = get_days_sum(
        df_alb_table, df_days_table, sex, alb)

# print(df_summary)
# print(df_summary.total_days.sum())
# print(df_days_table[ym_cols].sum().sum())

df_summary_5x = df_summary.groupby(['sex', 'alb_mid'])[[
    'exposure', 'event', 'total_days']].sum()
df_summary_5x = mylib1.estimate_rate(df_summary_5x, e=0.05)
df_summary_5x = df_summary_5x.reset_index()

# print(df_summary_5x)

df_summary_5x['avg_days'] = df_summary_5x.total_days / df_summary_5x.event

# print(df_summary_5x)

# 真のがん入院平均在院日数の作成
df_true_days = pd.read_csv('./public_stats/processed/ps_days.csv')

# print(df_true_days.head())


def get_true_cancer_days(df_true_days, sex, alb):
    is_sex = (df_true_days.sex == sex)
    more_alb_min = (df_true_days.alb_min <= alb)
    less_alb_max = (alb <= df_true_days.alb_max)
    ix = is_sex & more_alb_min & less_alb_max
    return df_true_days.loc[ix, 'C00'].values[0]


df_summary_5x['true_days'] = 0  # 列の追加
for i in df_summary_5x.index:
    (sex, alb) = df_summary_5x.loc[i, ['sex', 'alb_mid']]
    df_summary_5x.loc[i, 'true_days'] = get_true_cancer_days(
        df_true_days, sex, alb)

# print(df_summary_5x)

e = 0.05
with np.errstate(invalid='ignore'):
    df_summary_5x['days_LCL'] = gamma.ppf(e/2, df_summary_5x['event'],
                                          0, df_summary_5x['avg_days']
                                          ) / df_summary_5x['event']
    df_summary_5x['days_UCL'] = gamma.ppf(1 - e/2, df_summary_5x['event'],
                                          0, df_summary_5x['avg_days']
                                          ) / df_summary_5x['event']

# print(df_summary_5x)

df = df_summary_5x.loc[(df_summary_5x.alb_mid < 65)]
df_M = df.loc[df.sex == 'M']
df_F = df.loc[df.sex == 'F']


def plot_days(ax, df_sex, color):
    ax.scatter(df_sex.alb_mid, df_sex.avg_days, c=color,
               s=8, label='Averaged Hospital Days')
    ax.plot(df_sex.alb_mid, df_sex.days_LCL, c=color,
            ls='--', lw=1, label=r'$95\% CI$')
    ax.plot(df_sex.alb_mid, df_sex.days_UCL, c=color, ls='--', lw=1)
    ax.plot(df_sex.alb_mid, df_sex.true_days,
            c='k', ls='-', lw=1, label='True days')
    ax.legend(loc='upper left')
    ax.set_ylim(0, 40)


fig = plt.figure(figsize=(8, 4))
ax1 = fig.add_subplot(121)
plot_days(ax1, df_M, 'b')
ax1.set_title('Male')
ax1.set_xlabel('Age')

ax2 = fig.add_subplot(122, sharey=ax1)
plot_days(ax2, df_F, 'r')
ax2.set_title('Female')
ax2.set_xlabel('Age')
fig.suptitle('Cancer Hospital Days')

plt.savefig("0231b.png")
plt.show()



elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
