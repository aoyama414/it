# 出生比率
# 乱数を利用したデータの生成方法

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# ファイルの読み込み
df_birth = pd.read_csv('./public_stats/processed/ipss_birth.csv')

# 累積比率と一様乱数を使った、男女別・誕生年別の割合の作成方法の概念図
fig = plt.figure()
ax = fig.add_subplot(111)
# 折れ線
x = df_birth.index
y = df_birth['cum_ratio']
ax.plot(x, y)
xlabels = df_birth['year'].apply(str) + ' ' + df_birth['sex']
ax.set_xticks(x[::10])
ax.set_xticklabels(xlabels[::10], rotation='45')
# 水平矢印
ax.annotate('',
            xytext=[0, 0.7],
            xy=[92.57888, 0.7],
            arrowprops=dict(arrowstyle='->',
                            color='k'))
# 垂直矢印
ax.annotate('',
            xytext=[92.57888, 0.7],
            xy=[92.57888, 0],
            arrowprops=dict(arrowstyle='->', color='k'))
# テキスト
ax.text(x=0, y=0.72, s='$random number=0.7$')
ax.text(x=94, y=0.1, s='$1969, M$')
# タイトル
ax.set_title('人口出生の累積比率')

fig.savefig("0113.png")
plt.show()
