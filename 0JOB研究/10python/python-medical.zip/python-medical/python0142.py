# 死亡率を 100 倍して加入者データを再作成

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns

import mylibs.mylib1 as mylib1

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

# 引数設定
df_birth = pd.read_csv('./public_stats/processed/ipss_birth.csv')
start_study_t = 2010    # 分析開始時点 (2010年1月)
end_study_t = 2019.999  # 分析終了時点 (2019年12月)
mu = 10
N = 10000            # N 人の加入者を生成する。
family_ratio = 0.3   # 全体の内、被扶養者の占める割合
df_mortality = pd.read_csv('./public_stats/processed/ipss_mortality.csv')

# print(df_mortality)

# 100 倍死亡率のキャップ計算と概念図
fig = plt.figure(figsize=(8, 4))

# 男性
ax_M = fig.add_subplot(121)
ax_M.plot(df_mortality.alb, df_mortality.M, c='b', ls='--', label='TMR=1')
df_mortality['M'] = df_mortality.M * 100
df_mortality.loc[(df_mortality.M > 1), 'M'] = 1
ax_M.plot(df_mortality.alb, df_mortality.M, c='b', ls='-', label='TMR=100')
ax_M.legend()
ax_M.set_xlabel('Age')

# 女性
ax_F = fig.add_subplot(122)
ax_F.plot(df_mortality.alb, df_mortality.F, c='r', ls='--', label='TMR=1')
df_mortality['F'] = df_mortality.F * 100
df_mortality.loc[(df_mortality.F > 1), 'F'] = 1
ax_F.plot(df_mortality.alb, df_mortality.F, c='r', ls='-', label='TMR=100')
ax_F.legend()
ax_F.set_xlabel('Age')

fig.suptitle('100倍の死亡率')

plt.savefig('0142.png')

# plt.show()

# df_info の作成
df_info = mylib1.create_df_info(df_birth, df_mortality,
                                start_study_t, end_study_t,
                                mu, N, family_ratio)

# print(df_info)

# 死亡件数：3683件
death = df_info.death.sum()

# print(death)

# 年次エクスポージャ [人年]:約36,691人年
exposure = (df_info.end_obs_ym.apply(mylib1.ym_to_t)
            - df_info.start_obs_ym.apply(mylib1.ym_to_t)
            ).sum()

# print(exposure)

# 平均月次死亡率:0.10037769959822744
q = death / exposure

print(q)
