# 月次死亡率

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

url = 'http://www.ipss.go.jp/p-toukei/JMD/00/STATS/Mx_1x1.txt'
df_mortality = pd.read_csv(url, skiprows=1, delim_whitespace=True)

# print(df_mortality)
# print()

# データを数値型に変更
# データは2016年のみ
df_mortality = df_mortality[df_mortality['Year'] == 2016].copy()
df_mortality['Age'].replace('110+', '110', inplace=True)
dict_types = {'Year': 'int16', 'Age': 'int8', 'Female': 'float64',
              'Male': 'float64', 'Total': 'float64'}
df_mortality = df_mortality.astype(dict_types)

# print(df_mortality)
# print()

# ageはANB基準
del df_mortality['Year']
del df_mortality['Total']
df_mortality.columns = ['anb', 'F', 'M']

# print(df_mortality)
# print()

# ALB基準に変更
# 当の死亡率と前年の死亡率とを足して2で割る
df_mortality['F'] = (df_mortality['F'] + df_mortality['F'].shift(-1))/2
df_mortality['M'] = (df_mortality['M'] + df_mortality['M'].shift(-1))/2
df_mortality.columns = ['alb', 'F', 'M']

# print(df_mortality)
# print()

# 100歳を超えるものを削除
df_mortality = df_mortality[df_mortality['alb'] < 100].copy()

# 死亡率を年率から月率に変換
df_mortality.loc[:, 'F'] = 1 - (1 - df_mortality['F'])**(1/12)
df_mortality.loc[:, 'M'] = 1 - (1 - df_mortality['M'])**(1/12)

# 年齢別死亡率を可視化
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(df_mortality.alb, df_mortality.M, c='b', label='Male')
ax.plot(df_mortality.alb, df_mortality.F, c='r', label='Female')
ax.plot([0, 110], [1, 1], c='k', ls='--')
ax.set_xlabel('ALB')
ax.set_ylabel('死亡率')
ax.legend(loc='best')
ax.set_title('死亡率', fontsize=15)

fig.savefig("0114.png")
# plt.show()

print(df_mortality)

# ファイルの保存
df_mortality.to_csv('./public_stats/processed/ipss_mortality.csv', index=False)
