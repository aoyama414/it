import numpy as np

print('ソートと検索')
np.random.seed(7)
a = np.floor(np.random.random((3, 4))*100).astype(int)
print(a)  # [[ 7 77 43 72]
#  [97 53 50  7]
#  [26 49 67 80]]

print(np.sort(a, axis=0))  # [[ 7 49 43  7]
#  [26 53 50 72]
#  [97 77 67 80]]

print(np.sort(a, axis=1))  # [[ 7 43 72 77]
#  [ 7 50 53 97]
#  [26 49 67 80]]

print(np.argsort(a, axis=0))  # [[0 2 0 1]
#  [2 1 1 0]
#  [1 0 2 2]]

print(np.argsort(a, axis=1))  # [[0 2 3 1]
#  [3 2 1 0]
#  [0 1 2 3]]

print(np.max(a))  # 97

print(np.max(a, axis=1))  # [77 97 80]

print(np.argmax(a))  # 4 (reshape(-1))された要素番号
print(np.argmax(a, axis=0))  # [1 0 2 2]
