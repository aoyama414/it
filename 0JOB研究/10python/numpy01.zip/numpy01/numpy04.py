import numpy as np

print('結合、繰り返し')
print('2つの配列を結合(np.concatenate())したり、')
print('1つの配列データを繰り返すここ とで')
print('新しい配列を生成(np.repeat()とnp.tile())することもできます。')

# ベクトル
x = np.linspace(1, 3, 3, dtype=int)
y = np.linspace(5, 8, 3, dtype=int)
print(np.concatenate((x, y)))  # [1 2 3 5 6 8]
print(np.repeat(x, 3))  # [1 1 1 2 2 2 3 3 3]
print(np.tile(x, 3))  # [1 2 3 1 2 3 1 2 3] (リスト変数[1, 2, 3]*3に相当)

# 行列
x = np.linspace(1, 4, 4, dtype=int).reshape((2, 2))
y = np.linspace(4, 7, 4, dtype=int).reshape((2, 2))
print(np.concatenate((x, y), axis=0))  # [[1 2]
#  [3 4]
#  [4 5]
#  [6 7]]

print(np.concatenate((x, y), axis=1))  # [[1 2 4 5]
#  [3 4 6 7]]


print(np.repeat(x, 3))       # [1 1 1 2 2 2 3 3 3 4 4 4]
print(np.repeat(x, 3, axis=0))  # [[1 2]
#  [1 2]
#  [1 2]
#  [3 4]
#  [3 4]
#  [3 4]]
print(np.repeat(x, 3, axis=1))  # [[1 1 1 2 2 2]
#  [3 3 3 4 4 4]]
print(np.tile(x, 2))            # [[1 2 1 2]
#  [3 4 3 4]]
