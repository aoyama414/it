import numpy as np
import matplotlib.pyplot as plt

print('統計関数')
x = np.linspace(1, 12, 12, dtype=int)
print(x)  # [ 1  2  3  4  5  6  7  8  9 10 11 12]

# ベクトルの平均値と標準偏差の計算
print(np.mean(x))  # 6.5  (重み付き平均するならnp.average())
print(np.std(x))  # 3.45205252953

x = x.reshape((3, 4))
print(x)  # [[ 1  2  3  4]
#  [ 5  6  7  8]
#  [ 9 10 11 12]]

print(np.mean(x, axis=0))  # [ 5.  6.  7.  8.]
print(np.mean(x, axis=1))  # [  2.5   6.5  10.5]

# ヒストグラム
x = np.random.seed(777)
x = np.random.random(100)
# 区分の数を指定していしてヒストグラムを生成
hist, bin_edge = np.histogram(x, bins=5)
# [ 0.00738845  0.20582267  0.40425689  0.60269111  0.80112532  0.99955954]
print(bin_edge)
print(bin_edge.size)  # 6
print(hist)          # [21 22 20 19 18]
print(hist.size)     # 5
width = bin_edge[1:] - bin_edge[:-1]
v = bin_edge[:-1] + 0.5*width
fig, ax = plt.subplots(2)
ax[0].bar(v, hist, width)

# 区分のエッジを指定していしてヒストグラムを生成
# [ 0.   0.1  0.2  0.3  0.4  0.5  0.6  0.7  0.8  0.9  1. ]
bins = np.arange(0, 1.1, 0.1)
hist, bin_edge = np.histogram(x, bins=bins)  # 区分の数を指定
width = bin_edge[1:] - bin_edge[:-1]
v = bin_edge[:-1] + 0.5*width
ax[1].bar(v, hist, width)
fig.savefig("histogram.png")
plt.show()
