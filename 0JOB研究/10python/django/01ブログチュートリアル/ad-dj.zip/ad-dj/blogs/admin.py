"""This is a program."""
from django.contrib import admin
from .models import Blog

# Register your models here.

# 一覧の表示
class BlogAdmin(admin.ModelAdmin):
    """クラス"""
    list_display = ('id', 'title', 'created_datetime', 'updated_datetime')
    list_display_links = ('id', 'title')

# 登録画面
admin.site.register(Blog, BlogAdmin)
