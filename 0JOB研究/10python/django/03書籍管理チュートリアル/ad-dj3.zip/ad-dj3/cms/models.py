""" モジュールの定義 """
from django.db import models

# Create your models here.


class Book(models.Model):
    """書籍"""
    name = models.CharField('書籍名', max_length=255)
    publisher = models.CharField('出版社', max_length=255, blank=True)
    page = models.IntegerField('ページ数', blank=True, default=0)

    def __str__(self):
        return self.name


class Impression(models.Model):
    """感想"""
    book = models.ForeignKey(
        Book, verbose_name='書籍', related_name='impressions', on_delete=models.CASCADE)
    comment = models.TextField('コメント', blank=True)

    def __str__(self):
        return self.comment


# models.py の変更を拾って、マイグレートファイルを作成
# (env01) C:\Python\ad-dj3>python manage.py makemigrations cms
# Migrations for 'cms':
#   cms\migrations\0001_initial.py
#     - Create model Book
#     - Create model Impression


# マイグレートファイルが、どのような SQL になるか、以下のコマンドで確認
# (env01) C:\Python\ad-dj3>python manage.py sqlmigrate cms 0001
# BEGIN;
# --
# -- Create model Book
# --
# CREATE TABLE "cms_book" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
# "name" varchar(255) NOT NULL, "publisher" varchar(255) NOT NULL, "page" integer NOT NULL);
# --
# -- Create model Impression
# --
# CREATE TABLE "cms_impression" ("id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
# "comment" text NOT NULL, "book_id" integer NOT NULL REFERENCES "cms_book" ("id")
# DEFERRABLE INITIALLY DEFERRED);
# CREATE INDEX "cms_impression_book_id_b2966102" ON "cms_impression" ("book_id");
# COMMIT;

# 以下のコマンドでデータベースに反映
# env01) C:\Python\ad-dj3>python manage.py migrate cms
# Operations to perform:
#   Apply all migrations: cms
# Running migrations:
#   Applying cms.0001_initial... OK
