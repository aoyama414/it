from django.apps import AppConfig


class Adminlte3Config(AppConfig):
    name = 'adminlte3'
