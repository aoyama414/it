""" モジュール """
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .models import Memo
from .forms import MemoForm


# Create your views here.


def index(request):
    """ 関数 """
    memos = Memo.objects.all().order_by('-updated_datetime')
    return render(request, 'app2/index.html', {'memos': memos})


def detail(request, memo_id):
    """ 関数 """
    memo = get_object_or_404(Memo, id=memo_id)
    return render(request, 'app2/detail.html', {'memo': memo})


def new_memo(request):
    """ 関数 """
    if request.method == "POST":
        form = MemoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('app2:index')
    else:
        form = MemoForm
    return render(request, 'app2/new_memo.html', {'form': form})


@require_POST
def delete_memo(request, memo_id):
    """ 関数 """
    memo = get_object_or_404(Memo, id=memo_id)
    memo.delete()
    return redirect('app2:index')


def edit_memo(request, memo_id):
    """ 関数 """
    memo = get_object_or_404(Memo, id=memo_id)
    if request.method == "POST":
        form = MemoForm(request.POST, instance=memo)
        if form.is_valid():
            form.save()
            return redirect('app2:index')
    else:
        form = MemoForm(instance=memo)
    return render(request, 'app2/edit_memo.html', {'form': form, 'memo': memo})
