from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import (
    authenticate, get_user_model, password_validation,
)
from django.conf import settings
# Avoid shadowing the login() and logout() views below.
from django.contrib.auth import *
from django.contrib.auth.views import *


from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.core.exceptions import ValidationError
from django.http import HttpResponseRedirect, QueryDict
from django.shortcuts import resolve_url
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.http import (
    url_has_allowed_host_and_scheme, urlsafe_base64_decode,
)
from django.utils.translation import gettext_lazy as _
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView
from django.views.generic import ListView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin

# デコレート
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

from django.db.models import Count
from django.core.mail import send_mail, EmailMessage
from django.template.loader import get_template


# カスタマイズ
from .forms import *
from django.contrib.auth import get_user_model

UserModel = get_user_model()


class CustomSuccessURLAllowedHostsMixin():
    pass


class CustomLoginView(LoginView):
    form_class = CustomAuthenticationForm


class CustomLogoutView(LogoutView):
    pass


class CustomPasswordContextMixin(PasswordContextMixin):
    pass


class CustomPasswordResetView(PasswordResetView):
    email_template_name = 'registration/password_reset_email.html'
    extra_email_context = None
    form_class = CustomPasswordResetForm
    from_email = None
    html_email_template_name = None
    subject_template_name = 'registration/password_reset_subject.txt'
    success_url = reverse_lazy('accounts:password_reset_done')
    template_name = 'registration/password_reset_form.html'
    title = _('Password reset')
    token_generator = default_token_generator

    @method_decorator(csrf_protect)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)

    def form_valid(self, form):
        opts = {
            'use_https': self.request.is_secure(),
            'token_generator': self.token_generator,
            'from_email': self.from_email,
            'email_template_name': self.email_template_name,
            'subject_template_name': self.subject_template_name,
            'request': self.request,
            'html_email_template_name': self.html_email_template_name,
            'extra_email_context': self.extra_email_context,
        }
        form.save(**opts)
        return super().form_valid(form)


INTERNAL_RESET_SESSION_TOKEN = '_password_reset_token'


class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'registration/password_reset_done.html'
    title = _('Password reset sent')


class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    form_class = CustomSetPasswordForm
    success_url = reverse_lazy('accounts:password_reset_complete')


class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    pass


class CustomPasswordChangeView(PasswordChangeView):
    form_class = CustomPasswordChangeForm
    success_url = reverse_lazy('accounts:password_change_done')


class CustomPasswordChangeDoneView(PasswordChangeDoneView):
    template_name = 'registration/password_change_done.html'
    title = _('Password change successful')


# カスタマイズ
class UserCreateView(FormView):
    form_class = CustomUserCreationForm
    model = UserModel
    template_name = 'access/create.html'
    template2 = 'access/create_confirm.html'
    title = 'ユーザの作成'
    form = CustomUserCreationForm()
    ctx = {}
    success_url = reverse_lazy('admin:index')  # accounts:profile

    def form_valid(self, form):
        print(self.request.POST['next'])
        self.form = form

        if self.request.POST.get('next', '') == 'back':
            return render(self.request, self.template_name, self.get_context_data())
        elif self.request.POST.get('next', '') == 'confirm':
            return render(self.request, self.template2, self.get_context_data())
        elif self.request.POST.get('next', '') == 'regist':
            form.save()
            # # 認証
            # user = auth_authenticate(
            #     username=form.cleaned_data['username'],
            #     password=form.cleaned_data['password1'],
            # )
            # # ログイン
            # auth_login(self.request, user)

            # メール送信処理
            template = get_template('access/mail/users_create_mail.html')
            mail_ctx = {
                'email': form.cleaned_data['email'],
                'password': form.cleaned_data['password1'],
            }
            email = EmailMessage(
                subject='ユーザが作成されました: ',
                body=template.render(mail_ctx),
                from_email=settings.EMAIL_HOST_USER,
                to=[form.cleaned_data['email']],
                # cc=[],
                bcc=[settings.EMAIL_HOST_USER],
            )
            # ファイル添付：ファイル名、内容、MIME
            # email.attach(
            #     'manage.py', 'C:\Python\ad-dj4\manage.py', "text/html")
            email.send()
            return super().form_valid(form)
        else:
            # 通常このルートは通らない
            return redirect(reverse_lazy('admin:index'))

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title'] = self.title
        if self.request.POST:
            context['form'] = CustomUserCreationForm(self.request.POST)
        else:
            context['form'] = CustomUserCreationForm()
        return context


class ListSortedMixin(object):
    def get_context_data(self, **kwargs):
        print('ListSortedMixin')
        return super(ListSortedMixin, self).get_context_data(**context)


class ListPaginatedMixin(object):
    def get_context_data(self, **kwargs):
        print('ListPaginatedMixin')
        return super(ListPaginatedMixin, self).get_context_data(**context)


class UserListView(ListView):  # ListSortedMixin, ListPaginatedMixin,
    template_name = 'access/user_list.html'
    context_object_name = 'users_list'
    title = 'ユーザ一覧'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title'] = self.title
        return context

    def get_queryset(self):
        model = get_user_model()
        return model.objects.filter(date_joined__isnull=False).order_by('-date_joined')

@method_decorator(login_required, name='dispatch')
class UserChangeView(UpdateView):
    '''
    Django組込みのUserを利用する場合のユーザー情報変更ビュー
    カスタムユーザーでは使用しない
    '''
    template_name = 'access/change.html'
    form_class = CustomUserChangeForm
    success_url = reverse_lazy('access:list_user')
    # fields = ('user','date', 'shift_name_1', 'shisetsu_name_1', 'shift_name_2', 'shisetsu_name_2', 'shift_name_3', 'shisetsu_name_3','shift_name_4', 'shisetsu_name_4', 'day_total_worktime')
    title = 'ユーザの権限更新'

    def get_object(self):
        return self.request.user

    # def get_queryset(self):
    #     model = get_user_model()
    #     return model.objects.get(id=pk)

    def form_valid(self, form):
        # formのupdateメソッドにログインユーザーを渡して更新
        form.update(user=self.request.user)
        return super().form_valid(form)

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        # # 更新前のユーザー情報をkwargsとして渡す
        # kwargs.update({
        #     'email' : self.request.user.email,
        #     'first_name' : self.request.user.first_name,
        #     'last_name' : self.request.user.last_name,
        # })
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        context['title'] = self.title
        return context


# return Post.objects.filter(published_date__isnull=True).order_by('created_date')
# published_date is Null, order by created_dateとしてリストを取得するようになります。
#     def get_queryset(self):
#        return Post.objects.filter(published_date__lte=timezone.now()).order_by('-published_date')
# Postモデルが、published_date <= timezone.now()で絞り込まれ、order by published_date descでソートされます。


# def UserCreate(request):
#     template1 = 'access/create.html'
#     title = 'ユーザの作成'
#     ctx = {}
#     # success_url = reverse_lazy('accounts:profile')

#     if request.method == 'GET':
#         ctx['form'] = CustomUserCreationForm()
#         ctx['title'] = title
#         return render(request, template1, ctx)

#     if request.POST.get('next', '') == 'back':
#         user_form = CustomUserCreationForm(request.POST)
#         ctx['form'] = user_form
#         ctx['title'] = title
#         return render(request, 'access/create.html', ctx)

#     elif request.POST.get('next', '') ==  'confirm':
#             user_form = CustomUserCreationForm(request.POST)

#             if user_form.is_valid():
#                 user_form.save()
#                 return redirect(reverse_lazy('/'))
#             else:
#                 ctx['form'] = user_form
#                 ctx['title'] = title
#                 return render(request, 'access/create.html', ctx)

#               # form.save()
#                 # # 認証
#                 # user = auth_authenticate(
#                 #     username=form.cleaned_data['username'],
#                 #     password=form.cleaned_data['password1'],
#                 # )
#                 # # ログイン
#                 # auth_login(self.request, user)
#                 # return super().form_valid(form)
#         else:
#             # 通常このルートは通らない
#             # return redirect('admin:index')
#             user_form = CustomUserCreationForm(request.POST)

#             ctx['form'] = user_form
#             ctx['title'] = title
#             return render(request, 'access/create.html', ctx)

# def form_valid(self, form):
#     print(self.request.POST['next'])
#     ctx = {'title': title, 'form': form}
#     if self.request.POST['next'] == 'back':

#         return render(self.request, 'access/create.html', ctx)
#     elif self.request.POST['next'] == 'confirm':
#         return render(self.request, 'access/create_confirm.html', ctx)
#     elif self.request.POST['next'] == 'regist':
#         form.save()
#         # 認証
#         user = auth_authenticate(
#             username=form.cleaned_data['username'],
#             password=form.cleaned_data['password1'],
#         )
#         # ログイン
#         auth_login(self.request, user)
#         return super().form_valid(form)
#     else:
#         # 通常このルートは通らない
#         return redirect(reverse_lazy('base:top'))
