from django.apps import AppConfig


class AccessConfig(AppConfig):
    name = 'access'
