from django.urls import path
from django.conf import settings
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import reverse_lazy

from . import views


app_name = 'access'


# ヘッダなどのカスタマイズ
admin.site.site_header = settings.ADMIN_SITE_HEADER
admin.site_title = settings.ADMIN_SITE_TITLE
admin.site.site_title = app_name
admin.site.index_title = settings.ADMIN_INDEX_TITLE


urlpatterns = [
    # from django.contrib.auth.urls.py　カスタマイズ
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),

    # パスワードチェンジ
    path('password_change/', views.CustomPasswordChangeView.as_view(),
         name='password_change'),
    path('password_change/done/', views.CustomPasswordChangeDoneView.as_view(),
         name='password_change_done'),

    # パスワードリセット
    path('password_reset/', views.CustomPasswordResetView.as_view(),
         name='password_reset'),
    path('password_reset/done/', views.CustomPasswordResetDoneView.as_view(),
         name='password_reset_done'),
    path('reset/<uidb64>/<token>/', views.CustomPasswordResetConfirmView.as_view(),
         name='password_reset_confirm'),
    path('reset/done/', views.CustomPasswordResetCompleteView.as_view(),
         name='password_reset_complete'),

    # システム管理者の追加
    path('create_user/', views.UserCreateView.as_view(),
         name='create_user'),
    path('list_user/', views.UserListView.as_view(),
         name='list_user'),
    path('users/<uidb64>/', views.UserChangeView.as_view(),
         name='change_user'),

]
