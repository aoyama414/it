"""aoyamadj URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
# from django.contrib import admin
from django.conf import settings
from django.contrib import admin
from django.urls import path, include


#######################
# サイトマップ
# from django.contrib.sitemaps.views import sitemap

# from thread.sitemaps import TopicSitemap, CategorySitemap
# from base.sitemaps import BaseSitemap
#######################
# 画像アップ用
from django.conf.urls.static import static

# sitemaps = {
#     'topic': TopicSitemap,
#     'cateogry': CategorySitemap,
#     'base': BaseSitemap,
# }
#######################

# ヘッダなどのカスタマイズ
admin.site.site_header = settings.ADMIN_SITE_HEADER
admin.site_title = settings.ADMIN_SITE_TITLE
admin.site.site_title = settings.ADMIN_SITE_TITLE
admin.site.index_title = settings.ADMIN_INDEX_TITLE

admin.site.site_url = '/'
admin.site.enable_nav_sidebar = True
admin.site._empty_value_display = '-'
admin.site.login_form = None
admin.site.index_template = None
admin.site.app_index_template = None
admin.site.login_template = None
admin.site.logout_template = None
admin.site.password_change_template = None
admin.site.password_change_done_template = None

urlpatterns = [
    # path('accounts/', include('accounts.urls')),
    path('accounts/', include('allauth.urls')),
    path('admin/', admin.site.urls),

    # 管理系ユーザ管理
    path('access/', include('access.urls')),
    
    path('', include('app3.urls')),

    # ダッシュボード系およびユーザ系以外の管理
    path('dashboard/', include('dashboard.urls')),



    # path('users/', include('users.urls')),
    # path('work_list/', include('app3.urls')),
    path('newsapp/', include('newsapp.urls')),
    path('app/', include('app.urls')),
    path('blogs/', include('blogs.urls')),  # 1
    path('app2/', include('app2.urls')),  # 2
    path('cms/', include('cms.urls')),  # 3

    # # path('base/', include('base.urls')),
    # path('thread/', include('thread.urls')),
    # path('api/', include('api.urls')),
    # path('search/', include('search.urls')),
    # # http://127.0.0.1:8000/sitemap.xml
    # path('sitemap.xml', sitemap, {'sitemaps': sitemaps}),
]

# 画像アップ用
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    import debug_toolbar
    urlpatterns = [
        path('__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns
