from django.http import HttpRequest

# 通知関連
# navbar.html用
# ユーザの通知関連
Messages = [
    {'url': '#', 'imgsrc': '/static/dist/img/user1-128x128.jpg',
     'name': 'Brad Diesel', 'text': 'Call me whenever you can...', 'time': ' 4 Hours Ago'},
    {'url': '#', 'imgsrc': '/static/dist/img/user8-128x128.jpg',
     'name': 'John Pierce', 'text': 'I got your message bro', 'time': '4 Hours Ago'},
    {'url': '#', 'imgsrc': '/static/dist/img/user3-128x128.jpg',
     'name': 'Nora Silvester', 'text': ' The subject goes here', 'time': '4 Hours Ago'},
]

# Notifications
Notifications = []


def common(request: HttpRequest):
    return {
        "Messages": Messages,
        "Notifications": Notifications,
    }
