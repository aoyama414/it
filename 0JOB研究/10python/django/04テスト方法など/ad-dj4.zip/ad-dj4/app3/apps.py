from django.apps import AppConfig


class App3Config(AppConfig):
    name = 'app3'
