from django.contrib import admin
# from django.conf import settings


# # Register your models here.
# # ヘッダなどのカスタマイズ
# admin.site.site_header = settings.ADMIN_SITE_HEADER
# admin.site_title = settings.ADMIN_SITE_TITLE
# admin.site.index_title = settings.ADMIN_INDEX_TITLE

# admin.site.site_url = '/'
# admin.site.enable_nav_sidebar = True
# admin.site._empty_value_display = '-'
# admin.site.login_form = None
# admin.site.index_template = None
# admin.site.app_index_template = None
# admin.site.login_template = None
# admin.site.logout_template = None
# admin.site.password_change_template = None
# admin.site.password_change_done_template = None

# # urls.py:

# #from Django.conf.urls import patterns, include
# #from myproject.admin import admin_site

# # urlpatterns = patterns('',
# #    (r'^myadmin/', include(admin_site.urls)),
# # )
