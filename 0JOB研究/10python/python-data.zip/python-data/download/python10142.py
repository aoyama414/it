# RESAS API でデータ取得

import gc
import math
import pickle
import csv
import time
import sys
import pickle
import json
import urllib.request
import pprint

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import norm
import seaborn as sns
import scipy as sp


# 再帰回数を増加：デフォルト100000件
sys.setrecursionlimit(100000)

# 表示する行・列の数を設定
pd.options.display.max_rows = 8
pd.options.display.max_columns = 20

# matplotlib のフォントを設定
plt.rcParams["font.family"] = "IPAexGothic"
plt.rcParams['mathtext.fontset'] = 'stix'

start = time.time()
gc.collect()

# ***************************
# API KEYの取得
with open('setting/api.json') as f:
    api_key = json.load(f)

# 全都道府県のデータを一括ダウンロード
l = []
url_base = 'https://opendata.resas-portal.go.jp/api/v1/cities'

for pref_code in range(1, 48):
    url = url_base + '?prefCode=' + str(pref_code)
    req = urllib.request.Request(url, headers=api_key)
    with urllib.request.urlopen(req) as response:
        data = response.read()
    d = json.loads(data.decode())
    l.append(pd.json_normalize(d['result']))

df_all = pd.concat(l, ignore_index=True)
print(df_all.head())
#    prefCode cityCode cityName bigCityFlag
# 0         1    01100      札幌市           2
# 1         1    01101   札幌市中央区           1
# 2         1    01102    札幌市北区           1
# 3         1    01103    札幌市東区           1
# 4         1    01104   札幌市白石区           1

# print(df_all.shape)
# (1922, 4)

# print(df_all.dtypes)
# prefCode        int64
# cityCode       object
# cityName       object
# bigCityFlag    object
# dtype: object

# 特別区・行政区フラグbigCityFlagを使って政令指定都市の市の一覧を取得したり、
# 特定の都道府県の政令指定都市の区の一覧を取得したりできる。
# print(df_all.query('bigCityFlag == "2"'))
#       prefCode cityCode cityName bigCityFlag
# 0            1    01100      札幌市           2
# 268          4    04100      仙台市           2
# 531         11    11100    さいたま市           2
# 604         12    12100      千葉市           2
# ...        ...      ...      ...         ...
# 1484        34    34100      広島市           2
# 1629        40    40100     北九州市           2
# 1637        40    40130      福岡市           2
# 1744        43    43100      熊本市           2

# [20 rows x 4 columns]

s_code = df_all.set_index('cityCode')['cityName']
# print(s_code.head())
# cityCode
# 01100       札幌市
# 01101    札幌市中央区
# 01102     札幌市北区
# 01103     札幌市東区
# 01104    札幌市白石区
# Name: cityName, dtype: object

# CSVで保存
df_all.to_csv('download/city_code_list.csv', index=None)

# jsonで保存
df_all.to_json('download/city_code_list.json',
               orient='records', force_ascii=False)


# jsonの読み込み
with open('download/city_code_list.json') as f:
    data_json = json.load(f)

# print(type(data_json))
# <class 'list'>

# pprint.pprint(data_json[:5])
# [{'bigCityFlag': '2', 'cityCode': '01100', 'cityName': '札幌市', 'prefCode': 1},
#  {'bigCityFlag': '1', 'cityCode': '01101', 'cityName': '札幌市中央区', 'prefCode': 1},
#  {'bigCityFlag': '1', 'cityCode': '01102', 'cityName': '札幌市北区', 'prefCode': 1},
#  {'bigCityFlag': '1', 'cityCode': '01103', 'cityName': '札幌市東区', 'prefCode': 1},
#  {'bigCityFlag': '1', 'cityCode': '01104', 'cityName': '札幌市白石区', 'prefCode': 1}]

# print(len(data_json))
# 1922
# CSVの読み込み
df_from_json = pd.read_json(
    'download/city_code_list.json', encoding="shift-jis")
# print(df_from_json.head())
#    prefCode  cityCode cityName  bigCityFlag
# 0         1      1100      札幌市            2
# 1         1      1101   札幌市中央区            1
# 2         1      1102    札幌市北区            1
# 3         1      1103    札幌市東区            1
# 4         1      1104   札幌市白石区            1

# print(df_from_json.shape)
# (1922, 4)


# ***************************
elapsed_time = time.time() - start
print()
print("elapsed_time:{0}".format(elapsed_time) + "[sec]")
print(sys.getrecursionlimit())
# ***************************
