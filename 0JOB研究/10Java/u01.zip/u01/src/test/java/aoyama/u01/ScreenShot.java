/**
 * 共通処理
 * Seleniumで画面キャプチャ処理
 */
package aoyama.u01;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.FileAlreadyExistsException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

/**
 * @author y_aoy
 *
 */
public class ScreenShot {

    private static final String DATA_DIR = "C:\\pleiades\\workspace\\u01";

    /**
     * 指定されたURLにアクセスしスクリーンショットを取得する
     *
     * @param driver WebDriver
     * @param url    アクセス先
     * @throws InterruptedException 割り込みが発生した場合に発生
     * @throws IOException          スクリーンショットのファイル保存に失敗した場合に発生
     */
    public void getScreenShot(WebDriver driver, String url) throws InterruptedException, IOException {

        driver.get(url);

        // 最大化
//      driver.manage().window().maximize();
        // フルスクリーンで表示
        driver.manage().window().fullscreen();

        BigDecimal scrollYAfter = BigDecimal.valueOf(-1);

        int count = 1;
        // スクロールできなくなる(スクリーン位置が同じになる)まで繰り返す
        for (BigDecimal scrollYBefore = this.getScrollY(driver); (scrollYBefore != null
                && !scrollYBefore.equals(scrollYAfter)); scrollYBefore = this.moveScrollY(driver)) {

            File screenFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            this.copy(screenFile, new File(DATA_DIR, "screenshot_" + count + ".png"), true);
            count++;
            scrollYAfter = scrollYBefore;
        }
    }

    /**
     * 現在の縦スクロール位置を取得する。
     *
     * @param driver WebDriver
     * @return スクロール位置
     */
    private BigDecimal getScrollY(WebDriver driver) {
        String scrollY = (String) ((JavascriptExecutor) driver).executeScript("return String(window.pageYOffset);");
        BigDecimal value = null;
        if (scrollY != null && scrollY.matches("^[0-9]+$")) {
            value = new BigDecimal(scrollY);
        }
        return value;
    }

    /**
     * 画面サイズに合わせてスクロールを移動する
     *
     * @param driver WebDriver
     * @return 移動後のスクロール位置
     */
    private BigDecimal moveScrollY(WebDriver driver) {

        // 画面サイズを取得
        int height = driver.manage().window().getSize().height;

        // 見切れて画面確認ができない箇所ができないようにするため、
        // 画面サイズより少し小さい値でスクロールさせる
        String scrollY = (String) ((JavascriptExecutor) driver)
                .executeScript("scrollBy( 0, " + (height - 45) + " ); return String(window.pageYOffset);");
        BigDecimal value = null;
        if (scrollY != null && scrollY.matches("^[0-9]+$")) {
            value = new BigDecimal(scrollY);
        }

        return value;
    }

    /**
     * ファイルをコピーする
     *
     * @param fromFile  コピー元ファイル
     * @param toFile    コピー先ファイル
     * @param overwrite 上書きフラグ(true:上書きする, false:既に存在した場合、IOExceptionが発生)
     * @throws IOException ファイルコピーに失敗した場合に発生
     */
    private void copy(File fromFile, File toFile, boolean overwrite) throws IOException {
        if (fromFile == null) {
            throw new IllegalArgumentException("param[fromFile] is null");
        }
        if (toFile == null) {
            throw new IllegalArgumentException("param[fromFile] is null");
        }
        if (!fromFile.exists()) {
            throw new FileNotFoundException("There is not fromFile[" + fromFile.getAbsolutePath() + "].");
        }
        if (toFile.exists() && !overwrite) {
            throw new FileAlreadyExistsException(toFile.getAbsolutePath());
        }

        final FileInputStream fis = new FileInputStream(fromFile);
        final BufferedInputStream in = new BufferedInputStream(fis);
        final FileOutputStream fos = new FileOutputStream(toFile);
        final BufferedOutputStream out = new BufferedOutputStream(fos);
        byte[] buff = new byte[1024];
        for (int size = in.read(buff); size >= 0; size = in.read(buff)) {
            out.write(buff, 0, size);
        }

        in.close();
        out.close();
    }

    public void takeScreenShot(WebDriver driver
    // , String fname
    ) throws InterruptedException, IOException {

        String file = String.valueOf(System.currentTimeMillis());

        // 最大化
//      driver.manage().window().maximize();
        // フルスクリーンで表示
        driver.manage().window().fullscreen();

        BigDecimal scrollYAfter = BigDecimal.valueOf(-1);

        int count = 1;
        // スクロールできなくなる(スクリーン位置が同じになる)まで繰り返す
        for (BigDecimal scrollYBefore = this.getScrollY(driver); (scrollYBefore != null
                && !scrollYBefore.equals(scrollYAfter)); scrollYBefore = this.moveScrollY(driver)) {

            File screenFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            this.copy(screenFile, new File(DATA_DIR, file + "_" + count + ".png"), true);
            count++;
            scrollYAfter = scrollYBefore;
        }

    }

}
