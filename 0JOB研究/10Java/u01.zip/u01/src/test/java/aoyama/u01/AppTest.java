package aoyama.u01;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

//import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest {
//extends TestCase {

    private WebDriver driver;
    private static String baseUrl;
    private ScreenShot screenShot;

    /**
     * クラスで1回の起動
     */
    @BeforeClass
    public static void Setup() {
        System.out.println("BeforeClass");
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");

    }

    /**
     * テスト毎の起動
     */
    @Before
    public void testBefore() {
        System.out.println("Before");
        baseUrl = "https://www.yahoo.co.jp/";
        driver = new ChromeDriver();
        screenShot = new ScreenShot();
    }

    /**
     * テストごとの後処理
     */
    @After
    public void testAfter() {
        System.out.println("After");
        driver.quit();
        screenShot = null;
    }

    /**
     * クラスの終了処理
     */
    @AfterClass
    public static void testAfterClass() {
        System.out.println("AfterClass");
    }

    /**
     * Rigourous Test :-)
     */
    @Test
    public void testApp() {

        driver.get(baseUrl);
        driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);

    }

    @Test
    public void testApp1() {

        driver.get(baseUrl);

    }

    @Test
    public void testApp2() {

        WebDriverWait wait = new WebDriverWait(driver, 1000);
        try {
            driver.get("https://google.com/ncr");
            driver.findElement(By.name("q")).sendKeys("cheese" + Keys.ENTER);
            WebElement firstResult = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("h3>div")));
            System.out.println(firstResult.getAttribute("textContent"));
        } finally {

        }
    }

    @Test
    public void testApp3() {

        driver.get("https://www.yahoo.co.jp");
        WebElement elment = driver.findElement(By.linkText("ニュース"));
        System.out.println(elment.getText());

    }

    @Test
    public void testApp4() {
        driver.get("https://www.post.japanpost.jp/index.html");
        WebElement elment = driver.findElement(By.xpath("//*[@id=\"select\"]"));
        Select sel = new Select(elment);
        sel.selectByIndex(12);

        try {
            screenShot.takeScreenShot(driver);
        } catch (InterruptedException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        }

        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

    }

    @Test
    public void testApp5() {

        driver.get("https://www.google.co.jp/");

        WebElement elment = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
        elment.sendKeys("1234567890");

        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }

        elment.sendKeys(Keys.BACK_SPACE);
    }

}
