package com.example.tests;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import aoyama.u01.ScreenShot;

public class InputTest {
    private WebDriver driver;
    private String baseUrl;
    private InputPage inputPage;
    private ScreenShot screenShot;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
        driver = new ChromeDriver();
        screenShot = new ScreenShot();
        baseUrl = "http://example.selenium.jp/";
        inputPage = PageFactory.initElements(driver, InputPage.class);
        inputPage.setBaseUrl(baseUrl);
        // 入力画面を開く
        inputPage.open();
        try {
            screenShot.takeScreenShot(driver);
        } catch (InterruptedException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        }
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

    @Test
    public void inputPage_success() throws InterruptedException {
        // お名前="セレニウム男"、宿泊期間=2で画面操作を実行
        ConfirmPage confirmPage = inputPage.inputSuccessData("セレニウム男", 2);
        try {
            screenShot.takeScreenShot(driver);
        } catch (InterruptedException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        }
        // 確認画面に表示されている宿泊開始日の検証
        assertThat(confirmPage.getDateFrom(), is(inputPage.getExpectedDateFrom()));
        // 確認画面に表示されている宿泊終了日の検証
        assertThat(confirmPage.getDateTo(), is(inputPage.getExpectedDateTo()));

    }

    @Test
    public void inputPage_error() throws InterruptedException {
        // デフォルトのままで次へボタンをクリック
        ErrorPage confirmPage = inputPage.inputFailData();
        try {
            screenShot.takeScreenShot(driver);
        } catch (InterruptedException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO 自動生成された catch ブロック
            e1.printStackTrace();
        }
        // エラーメッセージの検証
        assertThat(confirmPage.getErrorMessage(), is("お名前が指定されていません"));
    }
}