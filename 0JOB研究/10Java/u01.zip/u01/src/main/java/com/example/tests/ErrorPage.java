/**
 *
 */
package com.example.tests;

/**
 * @author y_aoy
 *
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ErrorPage {
    private WebDriver driver;

    public ErrorPage(WebDriver driver) {
        this.driver = driver;
    }

    // エラーメッセージを囲むDiv
    @FindBy(id = "errorcheck_result")
    private WebElement errorMessageDiv;

    // エラーメッセージをを返却
    public String getErrorMessage() {
        return errorMessageDiv.getText();
    }
}
