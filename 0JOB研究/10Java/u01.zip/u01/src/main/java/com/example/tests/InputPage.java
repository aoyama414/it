/**
 *
 */
package com.example.tests;

/**
 * @author y_aoy
 *
 */
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InputPage {
    private WebDriver driver;
    private String baseUrl;

    // 入力された宿泊日二対応する確認画面の宿泊日(開始)を格納しておくメンバ
    private String expectedDateFrom;

    public String getExpectedDateFrom() {
        return expectedDateFrom;
    }

    // 入力された宿泊日二対応する確認画面の宿泊日(終了)を格納しておくメンバ
    private String expectedDateTo;

    public String getExpectedDateTo() {
        return expectedDateTo;
    }

    public InputPage(WebDriver driver) {
        this.driver = driver;
    }

    // 宿泊日(年)
    @FindBy(id = "reserve_year")
    private WebElement reserveYearElement;
    // 宿泊日(月)
    @FindBy(id = "reserve_month")
    private WebElement reserveMonthElement;
    // 宿泊日(日)
    @FindBy(id = "reserve_day")
    private WebElement reserveDayElement;
    // 宿泊日期間
    @FindBy(id = "reserve_term")
    private WebElement reserveTermElement;

    // お名前
    @FindBy(id = "guestname")
    private WebElement guestNameElement;
    // 次へボタン
    @FindBy(id = "goto_next")
    private WebElement gotoNextElement;

    public void open() {
        // 入力画面をオープン
        driver.get(baseUrl + "/reserveApp");
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    // 名前と宿泊期間を指定して入力操作を実行
    public ConfirmPage inputSuccessData(String guestName, int reserveTerm) {
        // お名前をセット
        guestNameElement.sendKeys(guestName);

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, reserveTerm);
        // 宿泊日はシステム日付+泊期間を固定でセット
        inputReservDate(calendar, reserveTerm);
        // OKボタンをクリック
        clickGotoNext();

        return PageFactory.initElements(driver, ConfirmPage.class);
    }

    private void clickGotoNext() {
        gotoNextElement.click();
    }

    private void inputReservDate(Calendar calendar, int term) {
        inputReservDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.DATE),
                term);
    }

    private void inputReservDate(int year, int month, int day, int term) {
        reserveYearElement.clear();
        reserveYearElement.sendKeys(Integer.toString(year));
        reserveMonthElement.clear();
        reserveMonthElement.sendKeys(Integer.toString(month));
        reserveDayElement.clear();
        reserveDayElement.sendKeys(Integer.toString(day));
        reserveTermElement.clear();
        reserveTermElement.sendKeys(Integer.toString(term));

        // テストで利用する検証用データをセットしておく
        expectedDateFrom = generateExpectedDateFrom();
        expectedDateTo = generateExpectedDateTo();
    }

    // 入力されている宿泊日をフォーマット(確認画面の表示形式)して返却
    private String generateExpectedDateFrom() {
        Calendar calendar = Calendar.getInstance();
        // 入力されている年月日をcalendarにセット
        setReserveDate(calendar);
        // calendarをフォーマットして返却
        return dateFormat(calendar);
    }

    // 入力されている宿泊日と宿泊日期間から宿泊終了日をフォーマット(確認画面の表示形式)して返却
    private String generateExpectedDateTo() {
        Calendar calendar = Calendar.getInstance();
        System.out.println(calendar.getTime());
        setReserveDate(calendar);
        // 宿泊日期間をプラス
        calendar.add(Calendar.DAY_OF_YEAR, Integer.parseInt(reserveTermElement.getAttribute("value")));
        return dateFormat(calendar);
    }

    private void setReserveDate(Calendar calendar) {
        calendar.set(Integer.parseInt(reserveYearElement.getAttribute("value")),
                Integer.parseInt(reserveMonthElement.getAttribute("value")) - 1,
                Integer.parseInt(reserveDayElement.getAttribute("value")));
    }

    private String dateFormat(Calendar calendar) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy年M月d日");
        System.out.println(calendar.getTime());
        return dateFormat.format(calendar.getTime());
    }


    public ErrorPage inputFailData() {
        // OKボタンをクリック
        clickGotoNext();
        //ErrorPageをリターン
        return PageFactory.initElements(driver, ErrorPage.class);
    }
}
