/**
 *
 */
package com.example.tests;

/**
 * @author y_aoy
 *
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ConfirmPage {
    private WebDriver driver;

    public ConfirmPage(WebDriver driver) {
        this.driver = driver;
    }

    // 宿泊日開始
    @FindBy(id = "datefrom")
    private WebElement dateFromElement;

    // 宿泊日終了
    @FindBy(id = "dateto")
    private WebElement dateToElement;

    // 宿泊日開始の文字列を返却
    public String getDateFrom() {
        return dateFromElement.getText();
    }

    // 宿泊日終了の文字列を返却
    public String getDateTo() {
        return dateToElement.getText();
    }
}
