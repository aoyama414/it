package aoyama.u01;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        System.out.print("Hello ");
        System.out.println("World!");

    }
}
