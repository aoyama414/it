package logic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import entity.Department;
import entity.Employee;

/**
 * 従業員の管理を行うためのマネージャ（DBの代わりとして使用する）
 */
public class EmployeeManager {

    /** Logger */
    private static Logger log = Logger.getLogger(EmployeeManager.class);

    /** Employee Map */
    private static Map<String, Employee> employeeMap;
    /** Department Map */
    private static Map<String, Department> departmentMap;

    public EmployeeManager() {

        log.info("EmployeeManager Constructer in..");
        initdata();
    }

    private void initdata() {
        log.info("init data start..");
        initDepartment();
        initEmployee();
    }

    private void initDepartment() {
        departmentMap = new LinkedHashMap<String, Department>();

        insertDepartment("d01", "営業部");
        insertDepartment("d02", "管理部");
        insertDepartment("d03", "開発部1部");
        insertDepartment("d04", "開発部2部");
    }

    private void insertDepartment(String departmentId, String departmentName) {
        Department department = new Department();
        department.setDepartmentId(departmentId);
        department.setDepartmentName(departmentName);
        departmentMap.put(departmentId, department);
    }

    public static void initEmployee() {
        employeeMap = new TreeMap<String, Employee>();
        insertEmployee("000555", "渡辺", "男", "d01");
        insertEmployee("012345", "伊藤", "男", "d02");
        insertEmployee("111111", "伊藤", "女", "d01");
        insertEmployee("222222", "山本", "女", "d03");
        insertEmployee("333333", "伊藤", "男", "d04");
        insertEmployee("444444", "中村", "女", "d01");
        insertEmployee("555555", "小林", "男", "d03");
        insertEmployee("666666", "斎藤", "男", "d02");
    }

    private static void insertEmployee(String employeeId, String employeeName, String gender, String departmentId) {
        Employee employee = new Employee();
        employee.setEmployeeId(employeeId);
        employee.setEmployeeName(employeeName);
        employee.setGender(gender);
        employee.setDepartmentId(departmentId);
        employee.setDepartment(departmentMap.get(departmentId));
        employeeMap.put(employeeId, employee);
    }

    /**
     * employeeの削除
     * 
     * @param empId
     * @return 削除された場合にtrue、それ以外の場合false
     */
    public static boolean deleteEmployee(String empId) {
        Employee deleted = employeeMap.remove(empId);
        return deleted != null;
    }

    public static List<Department> getDepartmentList() {
        List<Department> departmentList = new ArrayList<Department>(departmentMap.values());
        Collections.sort(departmentList, new DepartmentSorter());
        return departmentList;
    }

    public static List<Employee> getEmployeeList() {
        List<Employee> employeeList = new ArrayList<Employee>(employeeMap.values());
        Collections.sort(employeeList, new EmployeeSorter());
        return employeeList;
    }

    private static class DepartmentSorter implements Comparator<Department> {

        @Override
        public int compare(Department o1, Department o2) {
            return o1.getDepartmentId().compareTo(o2.getDepartmentId());
        }
    }

    private static class EmployeeSorter implements Comparator<Employee> {

        @Override
        public int compare(Employee o1, Employee o2) {
            return o1.getEmployeeId().compareTo(o2.getEmployeeId());
        }
    }

    public static Department getDepartmentById(String belongDepartmentId) {
        return departmentMap.get(belongDepartmentId);
    }

    public static boolean updateEmployee(Employee employee) {
        Employee updatedEmployee = employeeMap.get(employee.getEmployeeId());
        if (updatedEmployee != null) {
            employeeMap.put(employee.getEmployeeId(), employee);
            return true;
        }
        return false;
    }

    public static Employee getEmployeeById(String employeeId) {
        return employeeMap.get(employeeId);
    }

    public static void clearEmployee() {
        employeeMap.clear();
    }

    public static boolean addEmployee(Employee employee) {
        if (employee == null || employeeMap.containsKey(employee.getEmployeeId())) {
            return false;
        }
        insertEmployee(employee.getEmployeeId(), employee.getEmployeeName(), employee.getGender(), employee.getDepartmentId());
        return true;
    }
}
