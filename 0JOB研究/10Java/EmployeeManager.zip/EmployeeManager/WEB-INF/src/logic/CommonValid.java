package logic;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMessage;

/**
 * 共通的な有効性チェック処理を行うクラス
 */
public class CommonValid {

    /**
     * 必須なプロパティの情報設定のチェック
     * 
     * @param input
     *            入力値
     * @param property
     *            対象プロパティ
     * @param errorKey
     *            設定エラーキー
     * @param errors
     *            ActionErrors
     */
    public static void requiredCheck(String input, String property, String errorKey, ActionErrors errors) {

        if (input == null || input.equals("")) {
            errors.add(property, new ActionMessage(errorKey));
        }

    }

    /**
     * 入力された値が数字のみかどうか判定する処理<br>
     * 正負符号、小数点などが含まれている場合は数字ではないと判定する。
     * 
     * @param input
     *            入力文字列
     * @return 入力文字列がすべて数字の場合、true。それ以外の場合、false。
     */
    public static boolean isNumberOnly(String input) {

        if (input == null) {
            return false;
        }

        return input.matches("[0-9]+$");
    }

}
