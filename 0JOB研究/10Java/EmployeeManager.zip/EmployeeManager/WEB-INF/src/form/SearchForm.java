package form;

import java.util.List;

import org.apache.struts.action.ActionForm;

import entity.Employee;

/**
 * 検索フォーム（検索ボタンと検索結果のみのため、保持する情報は検索結果の一覧のみ）
 */
@SuppressWarnings("serial")
public class SearchForm extends ActionForm {

    // 検索結果として表示する従業員一覧
    private List<Employee> employeeList;

    public List<Employee> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(List<Employee> employeeList) {
        this.employeeList = employeeList;
    }

}
