package form;

import java.util.List;

import org.apache.struts.action.ActionForm;

import entity.Department;
import entity.Employee;

/**
 * 従業員情報編集フォーム
 */
@SuppressWarnings("serial")
public class MainForm extends ActionForm {

    /** 従業員ID */
    private String employeeId;
    /** 従業員名 */
    private String employeeName;
    /** 性別 */
    private String gender = "男";
    /** 所属組織 */
    private String belongDepartmentId;
    /** 論理削除フラグ */
    private boolean isInvalid;

    // 組織候補
    private List<Department> departmentList;

    public Employee getInputEmployee() {
        Employee employee = new Employee();
        employee.setEmployeeId(employeeId);
        employee.setEmployeeName(employeeName);
        employee.setGender(gender);
        employee.setDepartmentId(belongDepartmentId);
        if (departmentList != null) {
            for (Department department : departmentList) {
                if (department.getDepartmentId().equals(belongDepartmentId)) {
                    employee.setDepartment(department);
                    break;
                }
            }
        }
        employee.setIsInvalid(isInvalid);
        return employee;
    }

    public void setEmployee(Employee employee) {
        if (employee == null) {
            clearInput();
            return;
        }
        employeeId = employee.getEmployeeId();
        employeeName = employee.getEmployeeName();
        gender = employee.getGender();
        belongDepartmentId = employee.getDepartmentId();
        isInvalid = employee.getIsInvalid();
    }

    public void clearInput() {
        employeeId = null;
        employeeName = null;
        gender = null;
        belongDepartmentId = null;
        isInvalid = false;
    }

    // setter/getter
    public String getEmployeeId() {
        return employeeId;
    }

    public String getBelongDepartmentId() {
        return belongDepartmentId;
    }

    public void setBelongDepartmentId(String belongDepartmentId) {
        this.belongDepartmentId = belongDepartmentId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<Department> getDepartmentList() {
        return departmentList;
    }

    public void setDepartmentList(List<Department> departmentList) {
        this.departmentList = departmentList;
    }

    public boolean getIsInvalid() {
        return isInvalid;
    }

    public void setIsInvalid(boolean isInvalid) {
        this.isInvalid = isInvalid;
    }
}
