package filters;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import logic.EmployeeManager;

import org.apache.log4j.Logger;

public class ServletInitListener implements ServletContextListener {

    /** Logger */
    private static Logger log = Logger.getLogger(ServletInitListener.class);

    public void contextInitialized(ServletContextEvent arg0) {
        log.info("initialize completed");

        final EmployeeManager empManager = new EmployeeManager();
        log.info("create.. =" + empManager.getClass().getName());
    }

    public void contextDestroyed(ServletContextEvent arg0) {
        // do nothing
    }
}
