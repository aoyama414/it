package entity;

import java.io.Serializable;

/**
 * 組織情報
 */
@SuppressWarnings("serial")
public class Department implements Serializable {

    /** 組織ID */
    private String departmentId;
    /** 組織名称 */
    private String departmentName;

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }
}
