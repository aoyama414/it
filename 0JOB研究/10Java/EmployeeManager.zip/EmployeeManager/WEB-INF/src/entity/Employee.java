package entity;

import java.io.Serializable;

/**
 * 従業員情報
 */
@SuppressWarnings("serial")
public class Employee implements Serializable {

    /** 従業員ID */
    private String employeeId;
    /** 名前 */
    private String employeeName;
    /** 性別 */
    private String gender;
    /** 所属組織ID */
    private String departmentId;
    /** 所属組織 */
    private Department department;
    /** 論理削除フラグ */
    private boolean isInvalid;

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public boolean getIsInvalid() {
        return isInvalid;
    }

    public void setIsInvalid(boolean isInvalid) {
        this.isInvalid = isInvalid;
    }
}
