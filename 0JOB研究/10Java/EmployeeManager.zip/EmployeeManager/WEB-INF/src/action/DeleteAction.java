package action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.MainForm;

/**
 * 削除するAction
 */
public class DeleteAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(DeleteAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response)
            throws ClassNotFoundException {

        log.info("DeleteAction execute in..");

        MainForm mainForm = (MainForm) form;

        if (mainForm.getEmployeeId() == null || mainForm.getEmployeeId().equals("")) {
            log.error("empid doesn't exist!!");
            return map.findForward("error");
        }

        String target = (EmployeeManager.deleteEmployee(mainForm.getEmployeeId())) ? "success" : "error";

        return map.findForward(target);

    }

}
