package action;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import entity.Department;
import entity.Employee;
import form.MainForm;

/**
 * 従業員情報を取得して遷移する処理
 */
public class GetEmployeeAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(GetEmployeeAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.info("GetMemberAction In..");

        MainForm mainForm = (MainForm) form;

        String employeeId = request.getParameter("editEmpId");
        log.info("RequestParameter empid:" + employeeId);
        log.info("Form empid:" + mainForm.getEmployeeId());

        if (employeeId == null || employeeId.equals("")) {
            log.error("editEmpId doesn't exist!!");
            return (map.findForward("error"));
        }

        List<Department> departmentList = EmployeeManager.getDepartmentList();
        mainForm.setDepartmentList(departmentList);

        Employee employee = EmployeeManager.getEmployeeById(employeeId);

        if (employee != null) {
            mainForm.setEmployee(employee);
        }

        String target = null;
        if (employee != null) {
            target = "success";
        } else {
            log.error("employee:" + employeeId + " doesn't exist!!");
            target = "error";
        }

        return (map.findForward(target));
    }

}
