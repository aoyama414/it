package action;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import entity.Employee;
import form.SearchForm;

/**
 * 検索処理
 * 
 * @author USER
 */
public class SearchAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(SearchAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.debug("SearchAction execute in..");

        List<Employee> employeelist = EmployeeManager.getEmployeeList();

        ((SearchForm) form).setEmployeeList(employeelist);

        return (map.findForward("success"));

    }
}
