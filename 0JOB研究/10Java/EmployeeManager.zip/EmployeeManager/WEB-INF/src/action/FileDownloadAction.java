package action;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import entity.Employee;

/**
 * 従業員の情報をCSV形式のファイルにし、ダウンロードするアクション
 */
public class FileDownloadAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(FileDownloadAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.info("FileDownloadAction execute in..");

        List<Employee> allEmployeeList = EmployeeManager.getEmployeeList();

        String filename = null;
        try {
            filename = new String("ダウンロードサンプル.csv".getBytes("Windows-31J"), "ISO-8859-1");
        } catch (UnsupportedEncodingException e) {
            log.error(e);
        }

        // HTTPヘッダの出力
        response.setContentType("application/octet-stream");
        response.setHeader("Content-disposition", "attachment; filename=\"" + filename + "\"");

        PrintWriter out = null;
        try {
            out = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "Windows-31J"));
            out.print("従業員ID,名前,性別,所属組織,論理削除フラグ" + "\n");
            for (Employee employee : allEmployeeList) {
                out.print(employee.getEmployeeId());
                out.print(",");
                out.print(employee.getEmployeeName());
                out.print(",");
                out.print(employee.getGender());
                out.print(",");
                out.print(employee.getDepartment().getDepartmentName());
                out.print(",");
                out.print(employee.getIsInvalid());
                out.print("\n");
            }
            out.flush();
            out.close();
        } catch (UnsupportedEncodingException e1) {
            log.error(e1);
        } catch (IOException e1) {
            log.error(e1);
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (Exception e) {
                    log.error("PrintWriter could not close.");
                }
            }
        }

        return null;
    }
}
