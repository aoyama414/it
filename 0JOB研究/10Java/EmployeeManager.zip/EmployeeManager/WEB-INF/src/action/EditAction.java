package action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.CommonValid;
import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import entity.Department;
import entity.Employee;
import form.MainForm;

/**
 * 編集アクション
 */
public class EditAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(EditAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.info("EditAction execute in..");

        MainForm mainForm = (MainForm) form;
        ActionMessages errmsgs = new ActionMessages();

        List<String> errkeylist = check(mainForm);
        for (String str : errkeylist) {
            log.debug("errkey:" + str);
            errmsgs.add(str, new ActionMessage((str)));
            saveErrors(request, errmsgs);
        }
        if (errkeylist.size() != 0) {
            log.info("errkeylist size isn't zero!");

            List<Department> departmentList = EmployeeManager.getDepartmentList();
            mainForm.setDepartmentList(departmentList);

            return map.findForward("validNG");
        }

        Employee updateEmployee = new Employee();
        updateEmployee.setEmployeeId(mainForm.getEmployeeId());
        updateEmployee.setEmployeeName(mainForm.getEmployeeName());
        updateEmployee.setGender(mainForm.getGender());
        updateEmployee.setIsInvalid(mainForm.getIsInvalid());
        Department editDept = EmployeeManager.getDepartmentById(mainForm.getBelongDepartmentId());
        updateEmployee.setDepartment(editDept);

        String target = null;
        if (EmployeeManager.updateEmployee(updateEmployee)) {
            target = "success";
        } else {
            target = "error";
        }

        return map.findForward(target);

    }

    /**
     * フォームの入力内容をチェックする
     * 
     * @param form
     * @return 入力内容に不備があった場合、エラーメッセージを設定したリストを返却。それ以外の場合、何も返却しない。
     */
    private List<String> check(MainForm form) {
        ArrayList<String> resultlist = new ArrayList<String>();

        String employeeId = form.getEmployeeId();
        if (employeeId == null || employeeId.equals("")) {
            resultlist.add("errors.employeeId.required");
        }
        if (!CommonValid.isNumberOnly(employeeId) || employeeId.length() != 6) {
            resultlist.add("errors.employeeId.mustBe6LengthOfNumbers");

        }
        String employeeName = form.getEmployeeName();
        if (employeeName == null || employeeName.equals("")) {
            resultlist.add("errors.employeeName.required");
        }
        if (employeeName.length() > 20) {
            resultlist.add("errors.employeeName.over20chars");
        }
        String gender = form.getGender();
        if (gender == null || gender.equals("")) {
            resultlist.add("errors.gender.required");
        }
        String departmentId = form.getBelongDepartmentId();
        if (departmentId == null || departmentId.equals("")) {
            resultlist.add("errors.departmentId.required");
        }

        log.debug("result size:" + resultlist.size());
        return resultlist;
    }

}
