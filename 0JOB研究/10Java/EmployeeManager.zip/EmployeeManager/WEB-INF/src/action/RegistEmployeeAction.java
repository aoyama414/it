package action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.CommonValid;
import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import entity.Department;
import form.MainForm;

/**
 * 従業員登録アクション
 * 
 * @author USER
 * 
 */
public class RegistEmployeeAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(RegistEmployeeAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.info("RegistAction execute in..");

        MainForm maimForm = (MainForm) form;
        ActionMessages errmsgs = new ActionMessages();

        List<String> errkeylist = check(maimForm);
        for (int i = 0; i < errkeylist.size(); i++) {
            String str = (String) errkeylist.get(i);
            log.debug("errkey:" + str);
            errmsgs.add(str, new ActionMessage((str)));
            saveErrors(request, errmsgs);
        }
        if (errkeylist.size() != 0) {
            log.info("errkeylist size isn't zero!");

            List<Department> deparmentList = EmployeeManager.getDepartmentList();
            maimForm.setDepartmentList(deparmentList);

            return map.findForward("validNG");
        }

        boolean result = EmployeeManager.addEmployee(maimForm.getInputEmployee());

        String target = "success";
        if (result != true) {
            target = "error";
        }

        return map.findForward(target);
    }

    /**
     * フォームの入力内容をチェックする
     * 
     * @param mainForm
     * @return 入力内容に不備があった場合、エラーメッセージを設定したリストを返却。それ以外の場合、何も返却しない。
     */
    private List<String> check(MainForm mainForm) {
        log.info("RegistAction check in..");

        ArrayList<String> result = new ArrayList<String>();

        String employeeId = mainForm.getEmployeeId();
        if (employeeId == null || employeeId.equals("")) {
            result.add("errors.employeeId.required");
        }
        if (!CommonValid.isNumberOnly(employeeId) || employeeId.length() != 6) {
            result.add("errors.employeeId.mustBe6LengthOfNumbers");

        }
        log.info("empid exist. check duplicated start..");
        if (EmployeeManager.getEmployeeById(employeeId) != null) {
            result.add("errors.employeeId.duplicated");
        }

        String employeeName = mainForm.getEmployeeName();
        if (employeeName == null || employeeName.equals("")) {
            result.add("errors.employeeName.required");
        }
        if (employeeName.length() > 20) {
            result.add("errors.employeeName.over20chars");
        }

        String gender = mainForm.getGender();
        if (gender == null || gender.equals("")) {
            result.add("errors.gender.required");
        }

        String departmentId = mainForm.getBelongDepartmentId();
        if (departmentId == null || departmentId.equals("")) {
            result.add("errors.departmentId.required");
        }

        log.info("RegistAction check end. Result size:" + result.size());
        return result;

    }

}
