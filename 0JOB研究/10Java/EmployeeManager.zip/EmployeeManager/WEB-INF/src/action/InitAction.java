package action;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import logic.EmployeeManager;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * 　従業員情報初期化アクション
 */
public class InitAction extends Action {

    /** Logger */
    private static Logger log = Logger.getLogger(InitAction.class);

    public ActionForward execute(ActionMapping map, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws SQLException,
            ClassNotFoundException {

        log.info("InitAction In..");

        String target = "success";

        String initdata = request.getParameter("initdata");

        if (initdata != null && initdata.equals("0")) {
            EmployeeManager.clearEmployee();
        } else {
            EmployeeManager.initEmployee();
        }

        return (map.findForward(target));
    }

}
