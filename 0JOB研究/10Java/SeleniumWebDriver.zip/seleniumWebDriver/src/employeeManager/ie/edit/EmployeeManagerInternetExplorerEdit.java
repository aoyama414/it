package employeeManager.ie.edit;

import org.junit.Test;

import employeeManager.common.edit.EmployeeManagerEdit;
import employeeManager.ie.EmployeeManagerInternetExplorerDriver;

/**
 * IEを使った編集操作テストクラス
 */
public class EmployeeManagerInternetExplorerEdit extends EmployeeManagerInternetExplorerDriver {

	private EmployeeManagerEdit employeeManagerEdit;

	@Override
	public void preTest() {
		super.preTest();
		employeeManagerEdit = new EmployeeManagerEdit("InternetExplorer", getDriver(), getinitialURL());
	}

	// 編集作業のテスト
	@Test
	public void editTest() {
		employeeManagerEdit.editTest();
	}

	// 削除処理のテスト
	@Test
	public void deleteTest() {
		employeeManagerEdit.deleteTest();
	}

	// 確認メッセージのテスト
	@Test
	public void confirtmTest() {
		employeeManagerEdit.confirtmTest();
	}
}
