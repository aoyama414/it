package employeeManager.ie;

import org.openqa.selenium.ie.InternetExplorerDriver;

import employeeManager.EmployeeManagerBase;

/**
 * IEを使ったテスト用ベースクラス
 */
public abstract class EmployeeManagerInternetExplorerDriver extends EmployeeManagerBase {

	@Override
	protected void initDriver() {
		driver = new InternetExplorerDriver();
	}

}
