package employeeManager.chrome.edit.page;

import org.junit.Test;

import employeeManager.chrome.EmployeeManagerChromeDriver;
import employeeManager.common.edit.page.EmployeeManagerEditUsePageObject;

/**
 * Chromeを使った編集操作テストクラス(一部のみ。PageObjectsパターン使用版)
 */
public class EmployeeManagerChromeEditUsePageObject extends EmployeeManagerChromeDriver {

	private EmployeeManagerEditUsePageObject employeeManagerEdit;

	@Override
	protected void setupOptions() {
	}

	@Override
	public void preTest() {
		super.preTest();
		employeeManagerEdit = new EmployeeManagerEditUsePageObject("Chrome", getDriver(), getinitialURL());
	}

	@Test
	public void editInvalidTest_21char_20char() {
		employeeManagerEdit.editInvalidTest_21char_20char();
	}

}
