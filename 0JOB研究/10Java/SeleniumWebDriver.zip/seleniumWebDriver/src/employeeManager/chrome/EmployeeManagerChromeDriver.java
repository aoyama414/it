package employeeManager.chrome;

import java.io.File;
import java.io.IOException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import employeeManager.EmployeeManagerBase;

/**
 * Chromeを使ったテストケース用のベースクラス
 */
public abstract class EmployeeManagerChromeDriver extends EmployeeManagerBase {
	protected static ChromeOptions options;
	protected static ChromeDriverService service;

	@Override
	protected void initDriver() {
		// オプション設定。詳細は以下を参照
		// https://sites.google.com/a/chromium.org/chromedriver/capabilities
		options = new ChromeOptions();
		setupOptions();
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);

		// 作成したプロファイルでChrome(のドライバー)を起動する
		driver = new RemoteWebDriver(service.getUrl(), capabilities);
	}

	@BeforeClass
	public static void createDriverService() throws IOException {
		// NOTE テスト中に何度もWebDriverのquitとnewを繰り返すような場合、コストがかかる。
		// その場合はChromeDriverServiceを起動しておくことで、高速化できる
		// https://sites.google.com/a/chromium.org/chromedriver/getting-started
		// を参照
		service = new ChromeDriverService.Builder().usingDriverExecutable(new File("chromedriver.exe"))
				.usingAnyFreePort().build();
		service.start();
	}

	@AfterClass
	public static void stopDriverService() {
		service.stop();
	}

	abstract protected void setupOptions();
}
