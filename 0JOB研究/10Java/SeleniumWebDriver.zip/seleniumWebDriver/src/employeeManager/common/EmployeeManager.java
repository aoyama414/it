package employeeManager.common;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import util.CaputureUtils;

/**
 * ブラウザに依存しないテストケースを実装するテストクラス用のベースクラス
 */
public abstract class EmployeeManager {

	/** 従業員のデータリフレッシュ用URL */
	public static final String INIT_DATA_URL = "http://localhost:8080/EmployeeManager/initEmployee.do";
	/** 従業員のデータ全削除用URL */
	public static final String ALL_DATA_DELETE_URL = "http://localhost:8080/EmployeeManager/initEmployee.do?initdata=0";

	/** テスト対象のブラウザ名。ログ出力やキャプチャ画像のファイル名への利用を想定 */
	protected String browserName;
	protected WebDriver driver;
	protected String initialURL;

	public EmployeeManager(String browserName, WebDriver driver, String initialURL) {
		this.browserName = browserName;
		this.driver = driver;
		this.initialURL = initialURL;
	}

	public void beforeTestClass() {
		driver.get(INIT_DATA_URL);
	}

	/**
	 * C:\tmp\yyyyMMdd\screenshot\yyyyMMdd_name.pngにスクリーンショットを保存する
	 * 
	 * @param name
	 *            ファイル名末尾に付ける名前
	 * @return スクリーンショットを保存したファイルパス
	 */
	protected String getScreenShot(String name) {
		String filePath = CaputureUtils.getFilePath(getClass().getName(), browserName, name);
		CaputureUtils.getScreenshot((TakesScreenshot) driver, filePath);
		return filePath;
	}
}
