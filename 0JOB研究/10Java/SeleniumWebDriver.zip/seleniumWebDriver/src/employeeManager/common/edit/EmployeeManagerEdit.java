package employeeManager.common.edit;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import employeeManager.common.EmployeeManager;

/**
 * ブラウザに依存しない従業員編集のテストクラス
 */
public class EmployeeManagerEdit extends EmployeeManager {

	public EmployeeManagerEdit(String browserName, WebDriver driver, String initialURL) {
		super(browserName, driver, initialURL);
	}

	// 編集作業のテスト
	public void editTest() {
		// 編集テスト
		editTest1st();
		editTestThird();
		editTestFinal();

		// ユーザ名の入力上限テスト
		editInvalidTest_20char();
		editInvalidTest_21char();
		editInvalidTest_21char_20char();

		driver.get(initialURL);

		// 最終的な一覧画面のキャプチャも取っておく
		String filePath = getScreenShot("editTest");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内容がeditTestにて行った変更内容と合致していることを確認してください。");
	}

	// ユーザ名に20文字(上限値)を入力して更新できることを確認する
	private void editInvalidTest_20char() {
		driver.get(initialURL);
		// 編集画面に遷移
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[2]/td/a")).click();
		// ユーザ名等入力
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input"))
				.sendKeys("テスト変更_X#℡1234567890＋");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト変更_X#℡1234567890＋の情報を変更しました。")));

		// キャプチャも取っておく
		String filePath = getScreenShot("editInvalidTest_20char");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内文言が「テスト変更_X#℡1234567890＋の情報を変更しました。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// ユーザ名に21文字(上限値+1)を入力しエラーとなることを確認する
	private void editInvalidTest_21char() {
		driver.get(initialURL);
		// 編集画面に遷移
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[2]/td/a")).click();
		// ユーザ名等入力
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input"))
				.sendKeys("テスト変更_あ#℡1234567890+1");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// エラーメッセージのアサート
		WebElement errorMsgElem = driver.findElement(By.xpath("//div[@id='editpanel']//ul/li"));
		assertThat(errorMsgElem.getText(), is(containsString("社員名は20文字以内で入力してください。")));

		// キャプチャも取っておく
		String filePath = getScreenShot("editInvalidTest_20char");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内エラー文言が「・社員名は20文字以内で入力してください。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("一覧表示")).click();
	}

	// ユーザ名21文字でのエラーを発生させた後、20文字で入力して変更を成功させる
	private void editInvalidTest_21char_20char() {
		driver.get(initialURL);
		// 編集画面に遷移
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[2]/td/a")).click();
		// ユーザ名等入力
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input"))
				.sendKeys("テスト変更_XX#℡1234567890＋");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// エラーメッセージのアサート
		WebElement errorMsgElem = driver.findElement(By.xpath("//div[@id='editpanel']//ul/li"));
		assertThat(errorMsgElem.getText(), is(containsString("社員名は20文字以内で入力してください。")));

		// キャプチャも取っておく
		String filePath_20over = getScreenShot("editInvalidTest_21char_20char_1st");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath_20over + "のキャプチャ内エラー文言が「・社員名は20文字以内で入力してください。 」となっていることを確認してください。");

		// 20文字で入力
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input"))
				.sendKeys("テスト変更_X#℡1234567890＋");
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト変更_X#℡1234567890＋の情報を変更しました。")));

		// キャプチャも取っておく
		String filePath_20 = getScreenShot("editInvalidTest_21char_20char_2nd");
		logger.info(filePath_20 + "のキャプチャ内文言が「テスト変更_X#℡1234567890＋の情報を変更しました。 」となっていることを確認してください。");
		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// 上から1番目のユーザを編集する
	private void editTest1st() {
		driver.get(initialURL);
		// 上から1番目のユーザの編集画面に遷移する
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr/td/a")).click();
		// 編集
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).sendKeys("テスト変更1");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト変更1の情報を変更しました。")));

		// キャプチャも取っておく
		String filePath = getScreenShot("editTest1st");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内文言が「テスト変更1の情報を変更しました。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// 上から3番目のユーザを編集する
	private void editTestThird() {
		driver.get(initialURL);
		// 上から3番目のユーザの編集画面に遷移する
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[3]/td/a")).click();
		// 編集
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).sendKeys("テスト変更3");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト変更3の情報を変更しました。")));

		// キャプチャも取っておく
		String filePath = getScreenShot("editTestThird");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内文言が「テスト変更3の情報を変更しました。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// 一番下のユーザを編集する
	private void editTestFinal() {
		driver.get(initialURL);
		// 従業員一覧テーブルの要素数を取得
		WebElement table = driver.findElement(By.xpath("//table[@id='emptable']/tbody"));
		String tableText = table.getText();
		int lastIndex = tableText.split("\n").length;

		// 最後のユーザの編集画面へ
		WebElement lastIdElement = driver
				.findElement(By.xpath("//table[@id='emptable']/tbody/tr[" + lastIndex + "]/td/a"));
		lastIdElement.click();
		// 編集
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).sendKeys("テスト変更final");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイログでOKを押す
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト変更finalの情報を変更しました。")));

		// キャプチャも取っておく
		String filePath = getScreenShot("editTestFinal");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内文言が「テスト変更finalの情報を変更しました。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// 削除処理のテスト
	public void deleteTest() {
		deleteTest2nd();
	}

	// 上から2番目のユーザを削除する
	private void deleteTest2nd() {
		driver.get(initialURL);
		String deleteTargetName = driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[2]/td[2]")).getText();
		// 編集画面に移動
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[2]/td/a")).click();
		// 削除ボタンクリック
		driver.findElement(By.xpath("//div[@id='deletepanel']/form/input")).click();
		// 確認ダイアログでOK
		driver.switchTo().alert().accept();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString(deleteTargetName + "の情報を削除しました。")));

		// スクリーンショットも取っておく
		String filePath = getScreenShot("deleteTest2nd");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内文言が「" + deleteTargetName + "の情報を削除しました。 」となっていることを確認してください。");

		// 一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();
	}

	// 確認メッセージのテスト
	public void confirtmTest() {
		driver.get(initialURL);
		// 適当なユーザの編集画面に移る
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[3]/td/a")).click();
		// 編集
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).sendKeys("テスト変更3");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("開発部1部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイアログのメッセージアサート
		Alert alert1st = driver.switchTo().alert();
		Assert.assertEquals(alert1st.getText(), "変更しますか？");
		// 確認ダイアログキャンセル
		alert1st.dismiss();
		// 物理削除ボタンクリック
		driver.findElement(By.xpath("//div[@id='deletepanel']/form/input")).click();
		// 確認ダイアログのメッセージアサート
		Alert alert2nd = driver.switchTo().alert();
		Assert.assertEquals(alert2nd.getText(), "削除しますか？");
		// 確認ダイアログキャンセル
		alert2nd.dismiss();
		// 一覧画面に戻る
		driver.findElement(By.linkText("一覧表示")).click();
	}
}
