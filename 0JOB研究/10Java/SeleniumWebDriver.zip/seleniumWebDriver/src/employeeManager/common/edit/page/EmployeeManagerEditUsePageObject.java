package employeeManager.common.edit.page;

import org.apache.log4j.Logger;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import employeeManager.common.EmployeeManager;
import employeeManager.common.page.EmployeeEditPage;
import employeeManager.common.page.EmployeeEditResultPage;
import employeeManager.common.page.EmployeeSearchPage;
import util.CaputureUtils;

/**
 * PageObjectsパターンを使った編集操作のテストクラス
 */
public class EmployeeManagerEditUsePageObject extends EmployeeManager {

	public EmployeeManagerEditUsePageObject(String browserName, WebDriver driver, String initialURL) {
		super(browserName, driver, initialURL);
	}

	public void editInvalidTest_21char_20char() {
		driver.get(initialURL);
		EmployeeSearchPage searchPage = new EmployeeSearchPage(driver);
		EmployeeEditPage editPage = searchPage.editEmployee(2);
		editPage.setName("テスト変更_XX#℡1234567890＋");
		editPage.selectOrg("開発部1部");
		editPage.selectWoman();
		editPage.setInvalidFlag(true);
		editPage.update();
		String filePath_20over = CaputureUtils.getFilePath(getClass().getName(), browserName,
				"editInvalidTest_21char_20char_1st");
		CaputureUtils.getScreenshot((TakesScreenshot) driver, filePath_20over);

		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath_20over + "のキャプチャ内エラー文言が「・社員名は20文字以内で入力してください。 」となっていることを確認してください。");

		editPage.setName("テスト変更_X#℡1234567890＋");
		EmployeeEditResultPage editResultPage = editPage.update();
		String filePath_20 = CaputureUtils.getFilePath(getClass().getName(), browserName,
				"editInvalidTest_21char_20char_2nd");
		CaputureUtils.getScreenshot((TakesScreenshot) driver, filePath_20);

		logger.info(filePath_20 + "のキャプチャ内文言が「テスト変更_X#℡1234567890＋の情報を変更しました。 」となっていることを確認してください。");
		editResultPage.search();
	}
}
