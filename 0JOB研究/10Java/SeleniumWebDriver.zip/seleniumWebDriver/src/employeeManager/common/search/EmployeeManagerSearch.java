package employeeManager.common.search;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import employeeManager.common.EmployeeManager;

/**
 * ブラウザに依存しない検索、画面遷移のテストクラス
 */
public class EmployeeManagerSearch extends EmployeeManager {

	public EmployeeManagerSearch(String browserName, WebDriver driver, String initialURL) {
		super(browserName, driver, initialURL);
	}

	// 画面遷移テスト
	public void transitionTest() throws InterruptedException {
		transitionToEditView();
		transitionToBackwardForward();
		transitionToRegistView();
	}

	private void transitionToEditView() {
		// 一覧の一番上の従業員情報をクリックした場合の遷移テスト
		selectTest1st();
		// 一覧の上から3番目の従業員情報をクリックした場合の遷移テスト
		selectTestThird();
		// 一覧の一番下の従業員情報をクリックした場合の遷移テスト
		selectTestFinal();
	}

	// 一覧の一番上の従業員情報をクリックした場合の遷移テスト
	private void selectTest1st() {
		driver.get(initialURL);
		WebElement firstIdElement = driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr/td/a"));
		String targetID = firstIdElement.getText();
		firstIdElement.click();
		// 編集画面の従業員IDが一覧画面のものと同じかアサート
		Assert.assertEquals(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr/td[2]")).getText(),
				targetID);
		driver.findElement(By.linkText("一覧表示")).click();
	}

	// 一覧の3番目の従業員情報をクリックした場合の遷移テスト
	private void selectTestThird() {
		driver.get(initialURL);
		WebElement thirdIdElement = driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[3]/td/a"));
		String targetID = thirdIdElement.getText();
		thirdIdElement.click();
		// 編集画面の従業員IDが一覧画面のものと同じかアサート
		Assert.assertEquals(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr/td[2]")).getText(),
				targetID);
		driver.findElement(By.linkText("一覧表示")).click();
	}

	// 一覧の最後の従業員情報をクリックした場合の遷移テスト
	private void selectTestFinal() {
		driver.get(initialURL);
		WebElement employeeTable = driver.findElement(By.xpath("//table[@id='emptable']/tbody"));
		String tableText = employeeTable.getText();
		int lastIndex = tableText.split("\n").length;

		WebElement lastIdElement = driver
				.findElement(By.xpath("//table[@id='emptable']/tbody/tr[" + lastIndex + "]/td/a"));
		String targetID = lastIdElement.getText();
		lastIdElement.click();
		Assert.assertEquals(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr/td[2]")).getText(),
				targetID);
		// 一覧画面に戻る
		driver.findElement(By.linkText("一覧表示")).click();
	}

	// 新規登録画面への遷移
	private void transitionToRegistView() {
		// 新規登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();
		// ブラウザの動作が速すぎると遷移前にアサートされてこけることがあるので明示的に待機
		new WebDriverWait(driver, 5).until(ExpectedConditions.titleIs("名簿　新規登録"));
		// 画面タイトルをアサート
		Assert.assertEquals(driver.getTitle(), "名簿　新規登録");
		// 一覧画面に戻る
		driver.findElement(By.xpath("//div[@id='searchpanel']/a")).click();

	}

	// 戻るボタンのテスト
	private void transitionToBackwardForward() {
		// 適当な行を編集
		driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[4]/td/a")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input")).sendKeys("変更後");
		new Select(driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select")))
				.selectByVisibleText("管理部");
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]")).click();
		driver.findElement(By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input")).click();
		// 変更ボタンクリック
		driver.findElement(By.xpath("//div[@id='editpanel']/form/input[6]")).click();
		// 確認ダイアログOK
		driver.switchTo().alert().accept();
		// 変更結果画面から一覧画面に戻る
		driver.findElement(By.linkText("検索")).click();

		// 一覧画面→変更結果画面
		driver.navigate().back();
		Assert.assertEquals("名簿　変更結果", driver.getTitle());
		// 変更結果画面→編集画面
		driver.navigate().back();
		Assert.assertEquals("名簿　従業員情報変更", driver.getTitle());
		// 編集画面→一覧画面
		driver.navigate().back();
		Assert.assertEquals("名簿　従業員一覧", driver.getTitle());
	}

}
