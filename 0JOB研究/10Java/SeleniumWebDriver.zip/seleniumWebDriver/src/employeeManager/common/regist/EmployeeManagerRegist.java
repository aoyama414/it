package employeeManager.common.regist;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import employeeManager.common.EmployeeManager;

/**
 * ブラウザに依存しない従業員新規登録のテストクラス
 */
public class EmployeeManagerRegist extends EmployeeManager {

	public EmployeeManagerRegist(String browserName, WebDriver driver, String initialURL) {
		super(browserName, driver, initialURL);
	}

	// 登録作業のテスト
	public void registTest() {
		registNormal();
		registAfterError();
		driver.get(initialURL);

		String filePath = getScreenShot("registTest");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath + "のキャプチャ内容がeditTestにて行った変更内容と合致していることを確認してください。");
	}

	private void registNormal() {
		driver.get(initialURL);
		// 新規登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();
		// 編集
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).sendKeys("777777");
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).sendKeys("テスト777");
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[4]/td[2]/input[2]")).click();
		// 登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();

		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("テスト777を登録しました。")));

		// 一覧画面に戻る
		driver.findElement(By.linkText("従業員検索")).click();
	}

	private void registAfterError() {
		driver.get(initialURL);
		// 新規登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();
		// 編集
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).sendKeys("1");
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).sendKeys("aa");
		// 登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();

		// エラーメッセージのアサート
		WebElement errorMsgElem = driver.findElement(By.xpath("//div[@id='registpanel']//ul"));
		assertThat(errorMsgElem.getText(), is(containsString("社員番号は半角数字のみ6桁です。")));

		// キャプチャも取っておく
		String filePath_1 = getScreenShot("registAfterError_1");
		Logger logger = Logger.getLogger(getClass());
		logger.info(filePath_1 + "のキャプチャのエラーメッセージが「・社員番号は半角数字のみ6桁です。」となっていることを確認してください。");

		// 編集
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).sendKeys("8888888");
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input"))
				.sendKeys("123456789012345678901");
		// 登録ボタンクリック
		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();

		// エラーメッセージのアサート
		errorMsgElem = driver.findElement(By.xpath("//div[@id='registpanel']//ul"));
		assertThat(errorMsgElem.getText(), is(containsString("社員番号は半角数字のみ6桁です。")));
		assertThat(errorMsgElem.getText(), is(containsString("社員名は20文字以内で入力してください。")));

		// キャプチャも取っておく
		String filePath_2 = getScreenShot("registAfterError_2");
		logger.info(filePath_2 + "のキャプチャのエラーメッセージが「・社員番号は半角数字のみ6桁です。・社員名は20文字以内で入力してください。」となっていることを確認してください。");

		// 保存できるような値で更新
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr[2]/td[2]/input")).sendKeys("test8");
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).clear();
		driver.findElement(By.xpath("//div[@id='registpanel']/form/table/tbody/tr/td[2]/input")).sendKeys("888888");

		driver.findElement(By.xpath("//div[@id='registpanel']/form/input")).click();
		// メッセージのアサート
		WebElement messageElem = driver.findElement(By.xpath("//center"));
		assertThat(messageElem.getText(), is(containsString("test8を登録しました。")));
	}
}
