package employeeManager.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * 従業員情報の変更結果ページのPageObject
 */
public class EmployeeEditResultPage {
	private WebDriver driver;

	private By searchButton = By.linkText("検索");

	public EmployeeEditResultPage(WebDriver driver) {
		this.driver = driver;
	}

	public EmployeeSearchPage search() {
		driver.findElement(searchButton).click();
		return new EmployeeSearchPage(driver);
	}
}
