package employeeManager.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * 従業員情報変更ページのPageObject
 */
public class EmployeeEditPage {
	private WebDriver driver;

	private By employeeIdLabel = By.xpath("//table[@id='edittable']/tbody/tr[1]/td[2]");
	private By nameTextBox = By.xpath("//table[@id='edittable']/tbody/tr[2]/td[2]/input");
	private By orgCombo = By.xpath("//table[@id='edittable']/tbody/tr[3]/td[2]/select");
	private By manRadio = By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[1]");
	private By womanRadio = By.xpath("//table[@id='edittable']/tbody/tr[4]/td[2]/input[2]");
	private By invalidFlagCheckBox = By.xpath("//table[@id='edittable']/tbody/tr[5]/td[2]/input");
	private By updatebutton = By.xpath("//div[@id='editpanel']/form/input[6]");

	public EmployeeEditPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getEmployeeId() {
		return driver.findElement(employeeIdLabel).getText();
	}

	public EmployeeEditPage setName(String name) {
		driver.findElement(nameTextBox).clear();
		driver.findElement(nameTextBox).sendKeys(name);
		return this;
	}

	public EmployeeEditPage selectOrg(String text) {
		new Select(driver.findElement(orgCombo)).selectByVisibleText(text);
		return this;
	}

	public EmployeeEditPage selectMan() {
		driver.findElement(manRadio).click();
		return this;
	}

	public EmployeeEditPage selectWoman() {
		driver.findElement(womanRadio).click();
		return this;
	}

	public EmployeeEditPage setInvalidFlag(boolean invalidFlag) {
		WebElement invalidFlagElem = driver.findElement(invalidFlagCheckBox);
		boolean nowInvalidFlag = invalidFlagElem.isSelected();
		// 現在のフラグの状態が指定の状態と異なればクリックして値を変える
		if (nowInvalidFlag != invalidFlag) {
			invalidFlagElem.click();
		}
		return this;
	}

	public EmployeeEditResultPage update() {
		driver.findElement(updatebutton).click();
		// 確認ダイアログのOKを押す
		driver.switchTo().alert().accept();
		return new EmployeeEditResultPage(driver);
	}
}
