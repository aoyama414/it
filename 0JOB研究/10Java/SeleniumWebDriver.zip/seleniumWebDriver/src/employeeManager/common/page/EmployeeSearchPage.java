package employeeManager.common.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * 従業員一覧ページ用PageObject
 */
public class EmployeeSearchPage {
	private WebDriver driver;

	public EmployeeSearchPage(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * n番目に表示されている従業員の編集ページに遷移する
	 * 
	 * @param n
	 *            編集対象の行数(1開始)
	 * @return
	 */
	public EmployeeEditPage editEmployee(int n) {
		getEmployeeEditLinkElement(n).click();
		return new EmployeeEditPage(driver);
	}

	private WebElement getEmployeeEditLinkElement(int n) {
		return driver.findElement(By.xpath("//table[@id='emptable']/tbody/tr[" + n + "]/td/a"));
	}
}
