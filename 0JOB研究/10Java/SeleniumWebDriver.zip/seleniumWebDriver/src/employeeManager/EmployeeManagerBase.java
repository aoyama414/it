package employeeManager;

import base.TestBase;

/**
 * 従業員情報管理システムのテスト用のベースクラス
 */
public abstract class EmployeeManagerBase extends TestBase {

	@Override
	protected String getinitialURL() {
		return "http://localhost:8080/EmployeeManager/";
	}
}
