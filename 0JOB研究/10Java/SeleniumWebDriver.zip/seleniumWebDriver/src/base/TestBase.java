package base;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.PropertyConfigurator;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;

/**
 * Seleniumを使ったテスト用のベースクラス
 */
public abstract class TestBase {

	protected static WebDriver driver;

	/** 暗黙的待機を行う秒数 */
	private static final int IMPLICIT_WAIT_SECOND = 5;

	@BeforeClass
	public static void beforeClass() {
		// 設定ファイルを読み込む
		PropertyConfigurator.configure("conf/log4j.properties");
	}

	@Before
	public void preTest() {
		if (driver != null) {
			return;
		}
		initDriver();
		// 高速に動作した場合に要素が現れるより前にテストコードが走ってしまうことがあるので、要素が見つからない場合は待機する
		// NOTE すでに要素が現れていて、値が意図した値と異なる場合は待ってくれないので注意
		driver.manage().timeouts().implicitlyWait(getImplicitWaitSecond(), TimeUnit.SECONDS);
	}

	// NOTE ここを@AfterClassにして同一テストクラス中でドライバを使いまわす事もできる。
	// その場合、一度開いたブラウザを使いまわす事になるので高速ではあるが、画面遷移に制約がある場合などは問題が出るだろう。
	// 今回は@AfterClassにしても問題がないが、今後の変更を考え@Afterで毎回ドライバを初期化している
	@After
	public void postTest() {
		if (driver != null) {
			driver.quit();
			driver = null;
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}

	abstract protected void initDriver();

	abstract protected String getinitialURL();

	/**
	 * 暗黙的待機を行う時間を返す。デフォルトは{@link TestBase#IMPLICIT_WAIT_SECOND}
	 * 
	 * @return
	 */
	protected int getImplicitWaitSecond() {
		return IMPLICIT_WAIT_SECOND;
	}
}
